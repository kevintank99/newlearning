const fetchProperty = require('./fetchers/fetchXMLFacilityInfo')
const fetchXMLHotelInfo = require('./fetchers/fetchXMLHotelInfo')
const fetchAvailabilities = require('./fetchers/fetchAvailabilities')
const fetchXMLRates = require('./fetchers/fetchXMLRates')

module.exports = {
  fetchProperty,
  fetchXMLHotelInfo,
  fetchAvailabilities,
  fetchXMLRates
}
