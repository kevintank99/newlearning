const { RESTDataSource } = require('@apollo/datasource-rest')
const { defaults } = require('./constants')
const { readAvailabilityXML, readRatesXML, readHotelInfoXML, readFacilityInfoXML } = require('./requests')
const {dateToday, dateIsoFormat, dateFrom} = require('../../utils/date')
const { queue } = require('../../utils/logger')
const FormData = require('form-data')

const sBcreateChildrenAgesObj = (childrenAges) =>
childrenAges.reduce((acc, age) => {
  return acc[age] ? { ...acc, [age]: parseInt(acc[age] + 1) } : { ...acc, [age]: 1 }
}, {})

const sBcreateChildrenAgesString = (ages, roomNo) =>
Object.keys(ages).reduce((acc, age) => {
  return `${acc}&child_room${roomNo}_age${age}=${ages[age]}`
}, '')

/**
 * Generate adult_ and children_ - Parameters for offers fetching. Takes rooms array containing adults, children and childAges
 * @param {*} rooms
 */
const occupancyQueryParams = (rooms) => {
  var params = rooms.reduce((acc, room, i) => {
    const ages = room.children?.length ? sBcreateChildrenAgesObj(room.children) : []
    const children = room?.children?.length || 0
    return `${acc}&adult_room${i + 1}=${room.adults}${
      children > 0 ? `&child_room${i + 1}=${children}${sBcreateChildrenAgesString(ages, i + 1)}` : ``
    }`
  }, '')
  return params
}

class AlpinebitsAPI extends RESTDataSource {
  /** API Key to Token Service https://connectivity.seekda.com/json/token_service
     Many of the json services require an additional identification by token: The tokens can be generated with your API-KEY
     and are valid for 60 minutes after generation.
   *
   * @param {Object} options
   * @param {string} [options.hotelId]  hotel code	CHNL_TEST
   * @param {string} [options.apiKey]   api key	b5b03bb0-b9ce-0132-b0ad-0050568825b4
   */
  async fetchToken({ hotelId, apiKey }) {
    return this.get(`https://cloud.seekda.com/w/w-dynamic-shop/hotel:${hotelId}/${apiKey}.json`)
  }

  /**
   *
   * @param {Object}  options
   * @param {string}  options.hotelId    hotel code
   * @param {string}  options.apiUser    default api user is info@mts-italia.it, can only be changed in the protected user config
   * @param {string}  options.apiToken   api password for accessing data
   *
   */
  async fetchAlpinebitFacilityInfo(options) {
    const auth = options.token
    const formData = new FormData()
    formData.append("action", "OTA_HotelDescriptiveInfo:Inventory")
    formData.append("request", readFacilityInfoXML(options))
    const result = this.post('https://worker.mts-online.com/api/alpinebits', {
      body: formData,
      headers: {
        "X-AlpineBits-ClientProtocolVersion": options.version,
        "X-AlpineBits-ClientID": options.userId,
        Authorization: auth
      },
    });
    return result
  }

  /**
   *
   * @param {Object}  options
   * @param {string}  options.hotelId    hotel code
   * @param {string}  options.apiUser    default api user is info@mts-italia.it, can only be changed in the protected user config
   * @param {string}  options.apiToken   api password for accessing data
   *
   */
  async fetchAlpinebitHotelInfo(options) {
    const auth = options.token
    const formData = new FormData()
    formData.append("action", "OTA_HotelDescriptiveInfo:Info")
    formData.append("request", readHotelInfoXML(options))

    const result = this.post('https://worker.mts-online.com/api/alpinebits', {
      body: formData,
      headers: {
        "X-AlpineBits-ClientProtocolVersion": options.version,
        "X-AlpineBits-ClientID": options.userId,
        Authorization: auth
      },
    });
    return result
  }

  async fetchAlpinebitAvailabilities(options) {
    const auth = options.token
    const formData = new FormData()
    formData.append("action", "OTA_HotelAvail:FreeRooms")
    formData.append("request", readAvailabilityXML(options))

    const result = this.post('https://worker.mts-online.com/api/alpinebits', {
      body: formData,
      headers: {
        "X-AlpineBits-ClientProtocolVersion": options.version,
        "X-AlpineBits-ClientID": options.userId,
        Authorization: auth
      },
    });
    return result
  }

  async fetchAlpinebitRates(options) {
    const auth = options.token
    const formData = new FormData()
    formData.append("action", "OTA_HotelRatePlan:BaseRates")
    formData.append("request", readRatesXML(options))

    const result = this.post('https://worker.mts-online.com/api/alpinebits', {
      body: formData,
      headers: {
        "X-AlpineBits-ClientProtocolVersion": options.version,
        "X-AlpineBits-ClientID": options.userId,
        Authorization: auth
      },
    });
    return result
  }
}

module.exports = AlpinebitsAPI
