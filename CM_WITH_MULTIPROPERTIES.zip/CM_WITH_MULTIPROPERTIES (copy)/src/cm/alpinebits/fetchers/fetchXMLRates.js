const parseXML = require('../../../utils/xml').parseXML
const cleanKognitivXML = require('../../../utils/xml').cleanKognitivXML
const { isPositiveNumber } = require('../../../utils/number')
const { dateToday, dateIsoFormat, dateFrom, dateAddDays, dateDiffDaysAfterTimeRange } = require('../../../utils/date')
const { defaults } = require('../constants')

const setOptions = (params) => {

  // let options = {}
  // options.startDate = dateIsoFormat(
  //   params.startDate ? dateFrom(params.startDate) : dateFrom(params.config.startDate) || dateToday(),
  // )
  // options.endDate = dateIsoFormat(
  //   params.endDate
  //     ? dateFrom(params.endDate)
  //     : dateAddDays(
  //         params.config.timerange ? dateDiffDaysAfterTimeRange(params.config.timerange) : defaults.numberOfDays,
  //         dateFrom(options.startDate),
  //       ),
  // )

  let options = {}
  options.startDate = dateIsoFormat(
    params.startDate ? dateFrom(params.startDate) : dateFrom(params.config.startDate || dateToday())
  )
  options.numberOfDays = isPositiveNumber(params.length)
    ? params.length
    : params?.config?.timerange
    ? dateDiffDaysAfterTimeRange(params.config.timerange)
    : defaults.numberOfDays
  options.endDate = dateIsoFormat(dateAddDays(options.numberOfDays - 1, dateFrom(options.startDate)))

  return options
}

const fetchXMLRates = async (dataSources, params) =>
  await dataSources[params.provider.toLowerCase()]
    .fetchAlpinebitRates({ ...params, ...setOptions(params) })
    .then(async (data) => {
      const ratesJSON = await parseXML(data)
      const ratePlans = ratesJSON?.OTA_HotelRatePlanRS?.RatePlans
      const ratesError = ratesJSON?.OTA_HotelRatePlanRS?.Errors
      return ratePlans
        ? { data: ratePlans, error: null }
        : ratesError
        ? { data: null, error: ratesError }
        : { data: null, error: 'Error parsing rates XML' }
    })
    .catch(async (error) => ({ data: null, error }))

module.exports = fetchXMLRates
