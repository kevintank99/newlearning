const parseXML = require('../../../utils/xml').parseXML
const cleanKognitivXML = require('../../../utils/xml').cleanKognitivXML
const { dateToday, dateIsoFormat, dateFrom, dateAddDays } = require('../../../utils/date')
const { defaults } = require('../constants')

const fetchXMLHotelInfo = async (dataSources, params) =>
  await dataSources[params.provider.toLowerCase()]
    .fetchAlpinebitHotelInfo({ ...params })
    .then(async (data) => {
      const hotelInfoJSON = await parseXML(data)
      // return hotelInfoJSON
      const hotelDescriptiveContents = hotelInfoJSON?.OTA_HotelDescriptiveInfoRS?.HotelDescriptiveContents
      const hotelDescriptiveError = hotelInfoJSON?.OTA_HotelDescriptiveInfoRS?.Errors
      const hotelInfo = hotelDescriptiveContents?.[0]?.HotelDescriptiveContent
      return hotelInfo
        ? { data: hotelInfo, error: null }
        : hotelDescriptiveError
        ? { data: null, error: hotelDescriptiveError }
        : { data: null, error: 'Error parsing hotel info XML' }
    })
    .catch(async (error) => ({ data: null, error }))

module.exports = fetchXMLHotelInfo
