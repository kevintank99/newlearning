const attr = (paramName, paramValue) => paramValue ? ` ${paramName}="${paramValue}"` : ''

const readRatesXML = (params) => `<?xml version="1.0" encoding="UTF-8"?>
<OTA_HotelRatePlanRQ xmlns="http://www.opentravel.org/OTA/2003/05"
                     xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                     xsi:schemaLocation="http://www.opentravel.org/OTA/2003/05 OTA_HotelRatePlanRQ.xsd"
                     Version="3.000">
  <RatePlans>
    <RatePlan>
      <DateRange Start="${params.startDate}" End="${params.endDate}" />
      <HotelRef HotelCode="${params.hotelId}" />
    </RatePlan>
  </RatePlans>
</OTA_HotelRatePlanRQ>
`

const readFacilityInfoXML = (params) => `<?xml version="1.0" encoding="UTF-8"?>
<OTA_HotelDescriptiveInfoRQ xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                            xmlns="http://www.opentravel.org/OTA/2003/05"
                            xsi:schemaLocation="http://www.opentravel.org/OTA/2003/05 OTA_HotelDescriptiveInfoRQ.xsd"
                            Version="3.000">
    <HotelDescriptiveInfos>
      <HotelDescriptiveInfo HotelCode="${params.hotelId}" />
    </HotelDescriptiveInfos>
</OTA_HotelDescriptiveInfoRQ>
`

const readHotelInfoXML = (params) => `<?xml version="1.0" encoding="UTF-8"?>
<OTA_HotelDescriptiveInfoRQ xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                            xmlns="http://www.opentravel.org/OTA/2003/05"
                            xsi:schemaLocation="http://www.opentravel.org/OTA/2003/05 OTA_HotelDescriptiveInfoRQ.xsd"
                            Version="3.000">
    <HotelDescriptiveInfos>
      <HotelDescriptiveInfo HotelCode="${params.hotelId}" />
    </HotelDescriptiveInfos>
</OTA_HotelDescriptiveInfoRQ>
`

const readAvailabilityXML = (params) => `<OTA_HotelAvailRQ xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="http://www.opentravel.org/OTA/2003/05" xsi:schemaLocation="http://www.opentravel.org/OTA/2003/05 OTA_HotelAvailRQ.xsd" Version="1.002">
  <AvailRequestSegments>
      <AvailRequestSegment>
          <HotelSearchCriteria>
              <Criterion>
                  <HotelRef HotelCode="${params.hotelId}"/>
                  <StayDateRange Start="${params.startDate}" End="${params.endDate}"/>
                  <RoomStayCandidates>
                      <RoomStayCandidate RoomTypeCode="">
                      </RoomStayCandidate>
                  </RoomStayCandidates>
              </Criterion>
          </HotelSearchCriteria>
    </AvailRequestSegment>
  </AvailRequestSegments>
</OTA_HotelAvailRQ>
`

module.exports = {
  readRatesXML,
  readAvailabilityXML,
  readHotelInfoXML,
  readFacilityInfoXML
}