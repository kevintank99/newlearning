// ========= RESOLVERS FOR KOGNITIV ============

const resolveCm = require('./resolvers/resolveCm')
// const { childAgesResolver: resolveChildAges } = require('./resolvers/resolveChildAges')
// const { seasonsResolver: resolveSeasons } = require('./resolvers/resolveSeasons')
// const { categoriesResolver: resolveCategories } = require('./resolvers/resolveCategories')
const { roomCategoriesResolver: resolveRoomCategories } = require('./resolvers/resolveRoomCategories')
// const { servicesResolver: resolveServices } = require('./resolvers/resolveServices')
// const { picturesResolver: resolvePictures } = require('./resolvers/resolvePictures')
const { roomsResolver: resolveRooms } = require('./resolvers/resolveRooms')
const { ratesResolver: resolveRates } = require('./resolvers/resolveRates')
const { availabilityResolver: resolveAvailability } = require('./resolvers/resolveAvailability')
const { priceListResolver: resolvePriceList } = require('./resolvers/resolvePriceList')
// const { bookingsResolver: resolveBookings } = require('./resolvers/resolveBookings')
const { offersResolver: resolveOffers } = require('./resolvers/resolveOffers')
// const { calendarResolver: resolveCalendar } = require('./resolvers/resolveCalendar')
const { firstBookableRangeResolver: resolveFirstBookableRange } = require('./resolvers/resolveFirstBookableRange')
// const { lastAvailableRoomsResolver: resolveLastAvailableRooms } = require('./resolvers/resolveLastAvailableRooms')
const { roomOffersResolver: resolveRoomOffers } = require('./resolvers/resolveRoomOffers')
const { overviewResolver: resolveOverview } = require('./resolvers/resolveOverview')
// const { mealplansResolver: resolveMealplans } = require('./resolvers/resolveMealplans')
// const { offersForAutoReplyResolver: resolveOffersForAutoReply } = require('./resolvers/resolveOffersForAutoReply')
// const { bookabilityResolver: resolveBookability } = require('./resolvers/resolveBookability')

module.exports = {
  resolveCm,
  // resolveChildAges,
  // resolveSeasons,
  // resolveCategories,
  resolveRoomCategories,
  // resolveServices,
  // resolvePictures,
  resolveRooms,
  resolveRates,
  resolveAvailability,
  resolvePriceList,
  // resolveBookings,
  resolveOffers,
  // resolveCalendar,
  resolveFirstBookableRange,
  // resolveLastAvailableRooms,
  resolveRoomOffers,
  resolveOverview,
  // resolveMealplans,
  // resolveOffersForAutoReply,
  // resolveBookability
}

