const { resolveRates } = require('./resolveRates')
const { mealPlanCodes } = require('../constants')
const { dateToday } = require('../../../utils/date')
const { dateDiffDays } = require('../../../utils/date')
const { dateFrom } = require('../../../utils/date')
const { DEFAULT_MEALPLANCODE } = require('../constants')
const generateCacheKey = require('../../../cache/L1Cache/generateCacheKey')
const { isObject } = require('../../../utils/type')

/**
 * Resolves the minimum stay duration of offer.
 * @param {Object} offer
 * @returns {Number}
 */
const resolveMinimumStay = (offer) => {
  return Math.min(...Object.values(offer.min_los_per_week_day))
}

/**
 * Resolves minimum/maximum price of offer
 * @param {Object} ratesOfOffer
 * @param {*} amountType // per person (7) or per room (25)
 * @param {*} offer
 * @param {*} minStay
 * @param {*} priceType // SINGLE or STD
 * @param {*} occupancy
 * @returns
 */
const resolvePrice = (offerRate, minStay, priceType, stdOccupancy, amountType) => {

  const ratesOfOffer = offerRate?.dayRates
  const roomcode = offerRate?.roomcode
  const ratecode = offerRate?.ratecode
  const mealPlanCode = offerRate?.mealPlanCode

  let minimumRateForStay = 0
  let maximumRateForStay = 0

  for(let i = 0; i < ratesOfOffer.length; i++) {
    let offerTotal = 0
    const ratesForMinStay = ratesOfOffer.slice(i, i + minStay).map((rate) => rate?.adults?.[stdOccupancy])
    if (!ratesForMinStay.every((rate) => rate) || ratesForMinStay.length !== minStay) {
      continue
    }

    for (let j = 0; j < minStay; j++) {
      //Count the room price of the standard occupancy for min stay
      if(amountType == '7') {
        offerTotal += parseInt(ratesForMinStay[j]) * parseInt(stdOccupancy)
      } else {
        offerTotal += parseInt(ratesForMinStay[j])
      }
    }

    minimumRateForStay =
      offerTotal < minimumRateForStay || minimumRateForStay === 0 ? offerTotal : minimumRateForStay
    maximumRateForStay =
      offerTotal > maximumRateForStay || maximumRateForStay === 0 ? offerTotal : maximumRateForStay

  }

  //Price could be based on standard occupancy or per person
  if (priceType == 'SINGLE') {
    return { min: +minimumRateForStay / +stdOccupancy, max: +maximumRateForStay / +stdOccupancy }
  }
  return { min: minimumRateForStay, max: maximumRateForStay }
}

function resolveOfferImages(offerDesc, params) {
  return offerDesc?.images?.map((img) => {
    return {
      url: img?.url,
      description: img?.description?.find((desc) => desc?.language == params?.language)?.title
    }
  })
}

/**
 * Resolves applicable rooms
 * @param {Object} property
 * @param {Object} params
 * @returns {Array}
 */
const resolveRooms = (property, params) =>
  property.facility?.rooms.reduce((acc, r) => {
    const roomCode = (params.roomCode && params.roomCode.split(',')) || [r.code]
    if (roomCode.includes(r.code)) {
      acc.push(r.code)
    }
    return acc
  }, [])

const resolveRoomOffers = async ({ dataSources, db }, { property, token }, params) => {
  const ratesXML = await resolveRates({ dataSources }, { property }, params)
  const rooms = resolveRooms(property, params)
  const roomCodeToRoomDetails = property.facility?.rooms?.reduce((acc, room) => {
    acc[room.code] = room
    return acc
  }, {})

  const availableOffers = []
  Object.entries(ratesXML)?.forEach(([roomcode, ratesData]) => {
    for(let ratecode in ratesData) {
      if(ratesData?.[ratecode]?.ratePlanType == '12' || ratesData?.[ratecode]?.offers?.familyOffer || ratesData?.[ratecode]?.offers?.freeNightOffer) {
        availableOffers.push({
          roomcode,
          ratecode,
          ...ratesData?.[ratecode]
        })
      }
    }
  })

  const roomOffers = []

  for(let i = 0; i < availableOffers.length; i++) {
    const roomsData = roomCodeToRoomDetails[availableOffers[i].roomcode]
    const minStayArr = availableOffers[i].dayRates?.reduce((acc, rate) => {
      if(rate?.minstay) {
        acc.push(rate?.minstay)
      } else if(rate?.adults) {
        acc.push(1)
      }
      return acc
    }, [])

    const minStay = Math.min(...minStayArr)
    const minimumOccupancy = roomsData?.min_occup
    const standardOccupancy = roomsData?.types?.[0]?.std_occup
    const maximumOccupancy = roomsData?.max_occup
    const amountType = availableOffers[i]?.amountType
    const ratePlanID = availableOffers[i]?.ratePlanID
    const ratePlanQualifier = availableOffers[i]?.ratePlanQualifier

    const checkOfferWithSameID = roomOffers.findIndex(offer => offer.ratePlanID == ratePlanID && offer.roomCode == availableOffers[i].roomcode)
    if(checkOfferWithSameID > -1) {
      const prices = resolvePrice(availableOffers[i], minStay, params?.priceType, standardOccupancy, amountType)

      // except rates returns 0
      if (prices.min == 0) continue

      isObject(roomOffers[checkOfferWithSameID].price) || (roomOffers[checkOfferWithSameID].price = {})
      isObject(roomOffers[checkOfferWithSameID].price.mealplans) || (roomOffers[checkOfferWithSameID].price.mealplans = {})
      roomOffers[checkOfferWithSameID].price.mealplans[availableOffers[i]?.mealPlanCode] = {
        ...prices
      }

      // add mealplan codes
      roomOffers[checkOfferWithSameID].mealPlanInfo[availableOffers[i]?.mealPlanCode] = mealPlanCodes[availableOffers[i]?.mealPlanCode][params?.language]

      // check min / max prices
      if(prices?.min) {
        prices.min = (roomOffers[checkOfferWithSameID].price?.min && roomOffers[checkOfferWithSameID].price?.min < prices?.min) ? roomOffers[checkOfferWithSameID].price?.min : prices?.min
      }

      if(prices.max) {
        prices.max = (roomOffers[checkOfferWithSameID].price?.max && roomOffers[checkOfferWithSameID].price?.max > prices?.max) ? roomOffers[checkOfferWithSameID].price?.max : prices?.max
      }

    } else {
      const prices = resolvePrice(availableOffers[i], minStay, params?.priceType, standardOccupancy, amountType)
      
      // except rates returns 0
      if (prices.min == 0) continue
      
      roomOffers.push({
        roomCode: availableOffers[i].roomcode,
        code: availableOffers[i]?.ratecode,
        title: availableOffers[i]?.description?.title?.find((val) => val.language == params.language && val.text_format == 'PlainText')?.content,
        description: availableOffers[i]?.description?.intro?.find((val) => val.language == params.language && val.text_format == 'HTML')?.content,
        images: resolveOfferImages(availableOffers[i]?.description, params),
        minimumOccupancy,
        standardOccupancy,
        maximumOccupancy,
        minStay,
        mealPlanInfo: {
          [availableOffers[i]?.mealPlanCode || DEFAULT_MEALPLANCODE]:
            mealPlanCodes[availableOffers[i]?.mealPlanCode || DEFAULT_MEALPLANCODE][params?.language],
        },
        price: {
          ...prices,
          mealplans: {
            [availableOffers[i]?.mealPlanCode]: { ...prices }   
          }
        },
        ratePlanID: ratePlanID,
        availabilityPeriod: availableOffers[i]?.availabilityPeriod
      })
    }
  }

  return roomOffers
}

const roomOffersResolver = async (parent, params, context, info) => {
  const { cache, ttl } = context
  const { userId, provider, language } = parent.params.options
  const key = generateCacheKey('roomOffers', params, userId, provider, language)
  const cacheHit = await cache?.get(key)
  if (cacheHit) {
    return JSON.parse(cacheHit)
  } else {
    const cacheableValue = await resolveRoomOffers(context, parent.params, { ...parent.params.options, ...params })
    cache?.setEx(key, ttl, JSON.stringify(cacheableValue))
    return cacheableValue
  }

  // const cacheableValue = await resolveRoomOffers(context, parent.params, { ...parent.params.options, ...params })
  // return cacheableValue
}

module.exports = {
  roomOffersResolver, //dynamic call
  resolveRoomOffers, //internal call
}

