const generateCacheKey = require('../../../cache/L1Cache/generateCacheKey')
const { fetchXMLRates } = require('../fetchers')
const { isArray, isObject, isStringValue, isNull, typeOf } = require('../../../utils/type')
const { isPositiveNumber } = require('../../../utils/number')
const { ratePlanTypes, defaults } = require('../constants')
const { resolveAvailability } = require('./resolveAvailability')
const {
  dateToday,
  dateAddDays,
  dateFrom,
  dateDiffDays,
  dateIsoFormat,
  dateDiffDaysAfterTimeRange,
} = require('../../../utils/date')
const { Code } = require('mongodb')
const { compareDesc, max, min } = require('date-fns')

const setOptions = (params) => {
  let options = {}
  options.startDate = isStringValue(params.startDate)
    ? dateFrom(params.startDate)
    : dateFrom(params?.config?.startDate || dateToday())
  
  options.numberOfDays = isPositiveNumber(params.length)
    ? params.length
    : params?.config?.timerange
    ? dateDiffDaysAfterTimeRange(params.config.timerange)
    : defaults.numberOfDays

  options.length = (params?.length) ? params?.length : (params.endDate) ? dateDiffDays(dateFrom(options.startDate), dateFrom(params.endDate)) + 1 : 365
  options.endDate = dateAddDays(options.numberOfDays - 1, options.startDate)

  // let options = {}
  // options.startDate = dateIsoFormat(
  //   params.startDate ? dateFrom(params.startDate) : (params.config.startDate) ? dateFrom(params.config.startDate) : dateToday(),
  // )

  // options.startDate = options.startDate < dateIsoFormat(dateToday()) ? dateIsoFormat(dateToday()) : options.startDate
  // options.length = (params?.length) ? params?.length : dateDiffDays(dateFrom(options.startDate), dateFrom(params.endDate)) + 1 || 365

  // return options

  // options.skipRateAccessCodes = isArray(params.config.skiprateaccess) ? params.config.skiprateaccess : []
  // options.promotionCodes = isObject(params.config.promotioncodes) ? params.config.promotioncodes : {}
  // options.skipRatePlanCodes = isArray(params.config.skiprateplans) ? params.config.skiprateplans : []
  return options
}

async function expandBookingRulesDatewise(bookingRules, roomsData) {
  if(!bookingRules) {
    return
  }
  let dateRanges = {}
  let bookingRulesDatewise = {}

  roomsData?.rooms?.map(room => bookingRulesDatewise[room.code] = {})
  
  for(let i = 0; i < bookingRules.length; i++) {
    let startDate = new Date(bookingRules[i]?.['$']?.Start)
    let endDate = new Date(bookingRules[i]?.['$']?.End)
    let roomCode = bookingRules[i]?.['$']?.Code

    // // Start checks of the overlap date ranges
    // if(!dateRanges.hasOwnProperty(roomCode)) {
    //   dateRanges[roomCode] = []
    // }
    // for(let i=0; i < dateRanges[roomCode].length; i++) {
    //   if(new Date(startDate) >= dateRanges[roomCode][i][0] && new Date(startDate) <= dateRanges[roomCode][i][1]) {
    //     console.log('Invalid start/end date combination' , startDate, endDate, dateRanges[roomCode][i][0], dateRanges[roomCode][i][1])
    //     error = true
    //     errorMsg = 'Invalid start/end date combination'
    //   }
    // }
    // dateRanges[roomCode].push([new Date(startDate), new Date(endDate)])
    // // End checks of the overlap date ranges

    if(roomCode && !bookingRulesDatewise.hasOwnProperty(roomCode)) {
      bookingRulesDatewise[roomCode] = {}
    }

    let rulesDetails = {
      code: bookingRules[i]?.['$']?.Code,
      codeContext: bookingRules[i]?.['$']?.CodeContext,
      lengthsOfStay: bookingRules[i]?.LengthsOfStay?.[0]?.LengthOfStay?.map((stay) => {
        return {
          time: stay?.['$']?.Time,
          timeUnit: stay?.['$']?.TimeUnit,
          minMaxMessageType: stay?.['$']?.MinMaxMessageType,
        }
      }),
      dowRestrictions: bookingRules[i]?.DOW_Restrictions?.map((restriction) => {
        return {
          arrival_DOW: restriction?.ArrivalDaysOfWeek?.[0]?.['$'],
          departure_DOW: restriction?.DepartureDaysOfWeek?.[0]?.['$'],
        }
      }),
      restrictionStatus: bookingRules[i]?.RestrictionStatus?.map((res) => {
        return {
          restriction: res?.['$']?.Restriction,
          status: res?.['$']?.Status
        }
      })
    }

    // date wise rules
    if(roomCode) { // for specefic room
      for(let i = startDate; i <= endDate; i.setDate(i.getDate() + 1)) {
        bookingRulesDatewise[roomCode][i.toISOString().split('T')[0]] = rulesDetails
      }
    } else { // for all rooms
      for(let i = startDate; i <= endDate; i.setDate(i.getDate() + 1)) {
        for(let [key, val] of Object.entries(bookingRulesDatewise)) {
          bookingRulesDatewise[key][i.toISOString().split('T')[0]] = rulesDetails
        }
      }
    }
    
  }
  return bookingRulesDatewise
}

async function resolveRateOffers(offers) {
  return offers?.map((offer) => {
    let offerRules = offer?.OfferRules?.[0]?.OfferRule
    return {
      offerRules: offerRules?.map((rules) => {
        return {
          maxAdvancedBookingOffset: rules?.['$']?.MaxAdvancedBookingOffset,
          minAdvancedBookingOffset: rules?.['$']?.MinAdvancedBookingOffset,
          lengthsOfStay: rules?.LengthsOfStay?.[0]?.LengthOfStay?.map((stay) => {
            return {
              time: stay?.['$']?.Time,
              timeUnit: stay?.['$']?.TimeUnit,
              minMaxMessageType: stay?.['$']?.MinMaxMessageType,
            }
          }),
          dowRestrictions: rules?.DOW_Restrictions?.map((restriction) => {
            return {
              arrival_DOW: restriction?.ArrivalDaysOfWeek?.[0]?.['$'],
              departure_DOW: restriction?.DepartureDaysOfWeek?.[0]?.['$'],
            }
          }),
          occupancy: rules?.Occupancy?.map((occu) => {
            return {
              ageQualCode: occu?.['$']?.AgeQualifyingCode,
              minAge: occu?.['$']?.MinAge,
              maxAge: occu?.['$']?.MaxAge,
              minOccupancy: occu?.['$']?.MinOccupancy,
              maxOccupancy: occu?.['$']?.MaxOccupancy,
            }
          })
        }
      }),
      discount: offer?.Discount?.map((disc) => {
        return {
          percent: disc?.['$']?.Percent,
          nightsRequired: disc?.['$']?.NightsRequired,
          nightsDiscounted: disc?.['$']?.NightsDiscounted,
          discountPattern: disc?.['$']?.DiscountPattern
        }
      }),
      guests: offer?.Guests?.[0]?.Guest?.map((guest) => {
        return {
          AgeQualifyingCode: guest?.['$']?.AgeQualifyingCode,
          MaxAge: guest?.['$']?.MaxAge,
          MinCount: guest?.['$']?.MinCount,
          FirstQualifyingPosition: guest?.['$']?.FirstQualifyingPosition,
          LastQualifyingPosition: guest?.['$']?.LastQualifyingPosition
        }
      })
    }
  })
  
}

const resolveAdditionalGuestAmount = (AdditionalGuestAmount, Rate) => {
  let fromAge = 0,
    toAge = 0

  AdditionalGuestAmount.sort((current, next) =>
    parseInt(current['$'].AgeQualifyingCode) > parseInt(next['$'].AgeQualifyingCode) ? 1 : -1,
  )

  return AdditionalGuestAmount.reduce((acc, { $: { AgeQualifyingCode, Amount } }) => {
    if (!AgeQualifyingCode || AgeQualifyingCode === '10') {
      acc.adults.additional = parseFloat(Amount)
    } else {
      isObject(acc.children) || (acc.children = {})
      toAge = AgeQualifyingCode - 100
      acc.children[`${fromAge} - ${toAge}`] = parseFloat(Amount) //attention it IS POSSIBLE the age ranges do not correspond to the childAges - PMS has different settings than Kognitiv
      fromAge = toAge + 1
    }
    return acc
  }, Rate)
}

const resolveBaseByGuestAmt = (BaseByGuestAmt) => {
  return BaseByGuestAmt.reduce(
    (acc, { $: { NumberOfGuests, AmountAfterTax } }) => {
      NumberOfGuests && (acc.adults[parseInt(NumberOfGuests)] = parseFloat(AmountAfterTax))
      return acc
    },
    { adults: {} },
  )
}

const resolveRateDescription = async (description) => {
  const rateDescription = {}
  description?.forEach((desc) => {
    if(desc?.['$']?.Name == 'title') {
      rateDescription.title = desc?.Text?.map((text) => {
        return {
          language: text?.['$'].Language,
          text_format: text?.['$'].TextFormat,
          content: text?.['_']
        }
      })
    } else if(desc?.['$']?.Name == 'intro') {
      rateDescription.intro = desc?.Text?.map((text) => {
        return {
          language: text?.['$'].Language,
          text_format: text?.['$'].TextFormat,
          content: text?.['_']
        }
      })
    } else if(desc?.['$']?.Name == 'description') {
      rateDescription.description = desc?.Text?.map((text) => {
        return {
          language: text?.['$'].Language,
          text_format: text?.['$'].TextFormat,
          content: text?.['_']
        }
      })
    } else if(desc?.['$']?.Name == 'gallery') {
      const imgDescription = desc?.Text?.reduce((acc, text) => {
        if(text?.['$']?.Language) {
          if(!acc[text?.['$']?.Language]) acc[text?.['$']?.Language] = []
          acc[text?.['$']?.Language].push(text?.['_'])
        } else if(text?.['$'].TextFormat == 'PlainText') {
          if(!acc['copyright']) acc['copyright'] = []
          acc['copyright'].push(text?.['_'])
        }
        return acc
      }, {})

      rateDescription.images = desc?.Image?.map((img, index) => {
        return {
          url: img,
          description: Object.entries(imgDescription)?.map(([key, val]) => {
            if(key != 'copyright') {
              return { 
                language : key,
                title : val[index]
              }
            }
          }),
          copyright: Object.entries(imgDescription)?.map(([key, val]) => {
            if(key == 'copyright') return val[index]
          }),
          attribution_url: desc?.URL?.[index]
        }
      })
    } else if(desc?.['$']?.Name == 'codelist') {
      rateDescription.theme_information = desc?.ListItem
    }
  })

  return rateDescription
}

const resolveXMLRatePlan = async (XMLRatePlan, options, property, availData) => {
  const roomsData = property?.facility?.rooms
  const newRatePlans = {}
  roomsData.forEach(({code}) => {
    isObject(newRatePlans[code]) || (newRatePlans[code] = {})
  })

  XMLRatePlan?.forEach(async (ratePlan, index, arr) => {
    const ratePlanNotifType = ratePlan?.['$']?.RatePlanNotifType
    const ratePlanCode = ratePlan?.['$']?.RatePlanCode
    const currencyCode = ratePlan?.['$']?.CurrencyCode
    const ratePlanType = ratePlan?.['$']?.RatePlanType
    const ratePlanID = ratePlan?.['$']?.RatePlanID
    const ratePlanQualifier = ratePlan?.['$']?.RatePlanQualifier

    // get offer element from parent rateplan if its derived, else get it from current reteplan
    let offers, rateDescription
    if(ratePlanID && ratePlanQualifier == 'false') {
      const parentRatePlan = arr.find(({ $ }) => ($['RatePlanID'] == ratePlanID && $['RatePlanQualifier'] == 'true'))
      offers = await resolveRateOffers(parentRatePlan?.Offers?.[0]?.Offer)
      rateDescription = await resolveRateDescription(parentRatePlan?.Description)
    } else {
      offers = await resolveRateOffers(ratePlan?.Offers?.[0]?.Offer)
      rateDescription = await resolveRateDescription(ratePlan?.Description)
    }

    const rateOffers = {}
    offers?.forEach((offer) => {
      if(offer?.discount && offer?.discount?.[0]?.nightsDiscounted) {
        rateOffers.freeNightOffer = {
          nightsRequired: offer?.discount?.[0]?.nightsRequired,
          nightsDiscounted: offer?.discount?.[0]?.nightsDiscounted,
          discountPattern: offer?.discount?.[0]?.discountPattern
        }
      } else if(offer?.guests) {
        rateOffers.familyOffer = {
          ageQualifyingCode: offer?.guests?.[0]?.AgeQualifyingCode,
          maxAge: offer?.guests?.[0]?.MaxAge,
          minCount: offer?.guests?.[0]?.MinCount,
          firstQualifyingPosition: offer?.guests?.[0]?.FirstQualifyingPosition,
          lastQualifyingPosition: offer?.guests?.[0]?.LastQualifyingPosition
        }
      }
    })

    const bookingRules = ratePlan?.BookingRules?.[0]?.BookingRule
    const rates = ratePlan?.Rates?.[0]?.Rate
    const supplements = ratePlan?.Supplements?.[0]?.Supplement
    const description = ratePlan?.Description?.[0]


    const suppData = supplements?.reduce((acc, supp) => {
      let invType = supp?.['$']?.InvType
      let invCode = supp?.['$']?.InvCode
      let addToBasicRateIndicator = supp?.['$']?.AddToBasicRateIndicator
      let mandatoryIndicator = supp?.['$']?.MandatoryIndicator
      let chargeTypeCode = supp?.['$']?.ChargeTypeCode
  
      let startDate = supp?.['$']?.Start ? new Date(supp?.['$']?.Start) : null
      let endDate = supp?.['$']?.End ? new Date(supp?.['$']?.End) : null
      let amount = supp?.['$']?.Amount

      if(!startDate && !endDate) {
        acc[invCode] = {
          invType: invType,
          invCode: invCode,
          addToBasicRateIndicator: addToBasicRateIndicator,
          mandatoryIndicator: mandatoryIndicator,
          chargeTypeCode: chargeTypeCode,
          description: supp?.Description?.map((desc) => {
            return {
              name: desc?.['$']?.Name,
              text: desc?.Text?.map(t => ({
                language: t?.['$']?.Language,
                content: t?.['_'],
                text_format: t?.['$']?.TextFormat,
              }))
            }
          })
        }
      } else if(startDate && endDate) {
        let prerequisiteInventory = supp?.PrerequisiteInventory
        const roomCode = (prerequisiteInventory?.[0]?.['$']?.InvType == 'ROOMTYPE') ? prerequisiteInventory?.[0]?.['$']?.InvCode : null
  
        // if(!acc[invCode]) acc[invCode] = {}
        if(!acc[invCode]) acc[supp?.['$']?.InvCode] = { invType: supp?.['$']?.InvType, invCode: supp?.['$']?.InvCode }
        if(!acc[invCode]?.amountDatewise) acc[invCode].amountDatewise = {}
  
  
        // supplement amounts datewise
        if(roomCode) { // for specefic room
          if(!acc[invCode].amountDatewise[roomCode]) acc[invCode].amountDatewise[roomCode] = {}
          if(!acc[invCode].amountDatewise[roomCode]['amount']) acc[invCode].amountDatewise[roomCode]['amount'] = []
          acc[invCode].amountDatewise[roomCode]['amount'].push({
            start: dateIsoFormat(startDate),
            end: dateIsoFormat(endDate),
            amount: amount
          })
        } else { // for all rooms
          acc[invCode].amountDatewise[roomCode]['amount'].push({
            start: dateIsoFormat(startDate),
            end: dateIsoFormat(endDate),
            amount: amount
          })
        }
      }
      return acc
    }, {})

    // offer rules
    const offerRules = offers?.find(orule => !isNull(orule?.offerRules))?.offerRules?.[0]
    const oLenOfStay= offerRules?.lengthsOfStay
    const oDOWRes = offerRules?.dowRestrictions
    const oMaxAdvOffset = offerRules?.maxAdvancedBookingOffset
    const oMinAdvOffset = offerRules?.minAdvancedBookingOffset

    const oMinLos = oLenOfStay?.find((stay) => stay?.minMaxMessageType == 'SetMinLOS')?.time
    const oMaxLos = oLenOfStay?.find((stay) => stay?.minMaxMessageType == 'SetMaxLOS')?.time

    // rates data
    let staticRateObj = {}
    rates?.forEach((bRate, index) => {
      let start = bRate?.['$']?.Start
      let end = bRate?.['$']?.End
      let code = bRate?.['$']?.InvTypeCode

      if(code) {
        isObject(newRatePlans[code]) || (newRatePlans[code] = {})
        isObject(newRatePlans[code][ratePlanCode]) || (newRatePlans[code][ratePlanCode] = {})
        newRatePlans[code][ratePlanCode]['offers'] = rateOffers
        newRatePlans[code][ratePlanCode]['ratePlanType'] = ratePlanType
        newRatePlans[code][ratePlanCode]['ratePlanID'] = ratePlanID
        newRatePlans[code][ratePlanCode]['ratePlanQualifier'] = ratePlanQualifier
        isObject(newRatePlans[code][ratePlanCode]['currencyCode']) || (newRatePlans[code][ratePlanCode]['currencyCode'] = currencyCode)
        isObject(newRatePlans[code][ratePlanCode]['mealPlanCode']) || (newRatePlans[code][ratePlanCode]['mealPlanCode'] = '')
        isObject(newRatePlans[code][ratePlanCode]['rateTimeUnit']) || (newRatePlans[code][ratePlanCode]['rateTimeUnit'] = '')
        isObject(newRatePlans[code][ratePlanCode]['unitMultiplier']) || (newRatePlans[code][ratePlanCode]['unitMultiplier'] = '')
        isObject(newRatePlans[code][ratePlanCode]['amountType']) || (newRatePlans[code][ratePlanCode]['amountType'] = '')
        isObject(newRatePlans[code][ratePlanCode]['description']) || (newRatePlans[code][ratePlanCode]['description'] = rateDescription)
        isArray(newRatePlans[code][ratePlanCode]['availabilityPeriod']) || (newRatePlans[code][ratePlanCode]['availabilityPeriod'] = [])
        
        isArray(newRatePlans[code][ratePlanCode]['dayRates']) ||
        (newRatePlans[code][ratePlanCode]['dayRates'] = Array(options.numberOfDays).fill(null))
      }
      
      let adults = {}
      let children = {}

      bRate?.BaseByGuestAmts?.[0]?.BaseByGuestAmt?.map((baseAmt) => {
        let numOfGuests = baseAmt?.['$']?.NumberOfGuests
        let ageQualCode = baseAmt?.['$']?.AgeQualifyingCode
        let price = baseAmt?.['$']?.AmountAfterTax
        if(ageQualCode == '10') {
          adults[numOfGuests] = price
        }
      })

      bRate?.AdditionalGuestAmounts?.[0]?.AdditionalGuestAmount?.map((addAmt) => {
        // let numOfGuests = addAmt?.['$']?.NumberOfGuests
        let ageQualCode = addAmt?.['$']?.AgeQualifyingCode
        let price = addAmt?.['$']?.Amount
        let minAge = addAmt?.['$']?.MinAge || 0
        let maxAge = (addAmt?.['$']?.MaxAge) ? parseInt(addAmt?.['$']?.MaxAge) - 1 : addAmt?.['$']?.MaxAge
        if(ageQualCode == '10') {
          adults["additional"] = price
        } else if(ageQualCode == '8') {
          children[`${minAge}-${maxAge}`] = price
        }
      })

      if((!start || !end) && index == 0) {
        let rateTimeUnit = bRate?.['$']?.RateTimeUnit
        let unitMultiplier = bRate?.['$']?.UnitMultiplier
        let amountType = bRate?.BaseByGuestAmts?.[0]?.BaseByGuestAmt?.[0]?.['$']?.Type
        let mealPlanCode = bRate?.MealsIncluded?.[0]?.['$']?.MealPlanCodes

        staticRateObj = {
          mealPlanCode,
          rateTimeUnit,
          unitMultiplier,
          amountType
        }
      } else {
      //   isObject(newRatePlans[code]) || (newRatePlans[code] = {})
      //   isObject(newRatePlans[code][ratePlanCode]) || (newRatePlans[code][ratePlanCode] = {})
      //   isArray(newRatePlans[code][ratePlanCode]['dayRates']) ||
      // (newRatePlans[code][ratePlanCode]['dayRates'] = Array(options.numberOfDays).fill(null))
        newRatePlans[code][ratePlanCode]['availabilityPeriod'].push({ Start: start, End: end })
      
        const weekdays = { '0': 'Sun', '1': 'Mon', '2': 'Tue', '3': 'Weds', '4': 'Thur', '5': 'Fri', '6': 'Sat' }
        newRatePlans[code][ratePlanCode] = { ...newRatePlans[code][ratePlanCode], ...staticRateObj }

        let dayStartIndex = dateDiffDays(options.startDate, dateFrom(start))
        let dayEndIndex = dateDiffDays(options.startDate, dateFrom(end))
        let dayDate
        while (dayStartIndex <= dayEndIndex) {

          dayDate = dateAddDays(dayStartIndex, options.startDate)
          const oArrival = (oDOWRes?.[0]?.arrival_DOW?.[weekdays[dayDate.getDay()]]) ? oDOWRes?.[0]?.arrival_DOW?.[weekdays[dayDate.getDay()]] : '1'
          const oDept = (oDOWRes?.[0]?.departure_DOW?.[weekdays[dayDate.getDay()]]) ? oDOWRes?.[0]?.departure_DOW?.[weekdays[dayDate.getDay()]] : '1'

          let closedTo = '0'
          if(oArrival == '1' && oDept == '1') {
            closedTo = '0'
          } else if(oArrival == '0' && oDept == '1') {
            closedTo = '1'
          } else if(oArrival == '1' && oDept == '0') {
            closedTo = '2'
          } else if(oArrival == '0' && oDept == '0') {
            closedTo = '3'
          }

          const dayAvailabilitiesForRoom = availData?.availability?.[code]?.dayAvailabilities
          let availability = 0
          if(dayAvailabilitiesForRoom) {
            availability = dayAvailabilitiesForRoom?.find((d) => { 
              if(d?.day == dateIsoFormat(dayDate)) {
                return true
              }
            })?.availability
          }

          isObject(newRatePlans[code][ratePlanCode]['dayRates'][dayStartIndex]) || (newRatePlans[code][ratePlanCode]['dayRates'][dayStartIndex] = {})
          // newRatePlans[code][ratePlanCode]['dayRates'][dayStartIndex]['adults'] = {...adults}
          // newRatePlans[code][ratePlanCode]['dayRates'][dayStartIndex]['children'] = {...children}

          newRatePlans[code][ratePlanCode]['dayRates'][dayStartIndex] = {
            day: dateIsoFormat(dayDate),
            minstay: parseInt(oMinLos || 1),
            minstaythrough: '-',
            maxstay: parseInt(oMaxLos) || '-',
            maxstaythrough: '-',
            arrival: oArrival,
            departure: oDept,
            master: '1',
            closedto: closedTo,
            adults: {...adults},
            children: {...children},
            availability,
          }
          dayStartIndex++
        }

        newRatePlans[code][ratePlanCode] = { 
          ...newRatePlans[code][ratePlanCode],
          supplements: isObject(suppData) ? Object.values(suppData) : []
        }
      }
    })

    // booking rules
    if(bookingRules) {
      bookingRules?.forEach((bRules) => {
        let start = bRules?.['$']?.Start
        let end = bRules?.['$']?.End
        let code = bRules?.['$']?.Code

        const bLenOfStay= bRules?.LengthsOfStay?.[0]?.LengthOfStay
        const bDOWRes = bRules?.DOW_Restrictions
        const bResStatus = bRules?.RestrictionStatus

        const arrivalDOW = bDOWRes?.[0]?.ArrivalDaysOfWeek?.[0]?.['$']
        const departureDOW = bDOWRes?.[0]?.DepartureDaysOfWeek?.[0]?.['$']
        // check master restriction open / close
        const masterRes = (bResStatus?.[0]?.['$']?.Status && bResStatus?.[0]?.['$']?.Status == 'Close') ? '0' : '1'
        const weekdays = { '0': 'Sun', '1': 'Mon', '2': 'Tue', '3': 'Weds', '4': 'Thur', '5': 'Fri', '6': 'Sat' }

        const rateObj = {
          rateCode: ratePlanCode,
          roomCode: code,
          currencyCode,
          ratePlanID,
          ratePlanQualifier
        }
    
        if(code) {
          let bMinLos = bLenOfStay?.find((stay) => stay?.['$']?.MinMaxMessageType == 'SetMinLOS')?.['$']?.Time
          const bMaxLos = bLenOfStay?.find((stay) => stay?.['$']?.MinMaxMessageType == 'SetMaxLOS')?.['$']?.Time
          const bForwardMinLos = bLenOfStay?.find((stay) => stay?.['$']?.MinMaxMessageType == 'SetForwardMinStay')?.['$']?.Time
          const bForwardMaxLos = bLenOfStay?.find((stay) => stay?.['$']?.MinMaxMessageType == 'SetForwardMaxStay')?.['$']?.Time

          if(!bMinLos && bForwardMinLos) bMinLos = bForwardMinLos

          const minstay = Math.max(parseInt(oMinLos ?? 1), parseInt(bMinLos ?? 1))
          const maxstay = Math.min(parseInt(oMaxLos), parseInt(bMaxLos)) || '-'

          let dayStartIndex = dateDiffDays(options.startDate, dateFrom(start))
          let dayEndIndex = dateDiffDays(options.startDate, dateFrom(end))
          let dayDate

          while (dayStartIndex <= dayEndIndex) {
            dayDate = dateAddDays(dayStartIndex, options.startDate)
            const bArrival = (arrivalDOW?.[weekdays[dayDate.getDay()]]) ? arrivalDOW?.[weekdays[dayDate.getDay()]] : '1'
            const bDept = (departureDOW?.[weekdays[dayDate.getDay()]]) ? departureDOW?.[weekdays[dayDate.getDay()]] : '1'

            const oArrival = (oDOWRes?.[0]?.arrival_DOW?.[weekdays[dayDate.getDay()]]) ? oDOWRes?.[0]?.arrival_DOW?.[weekdays[dayDate.getDay()]] : '1'
            const oDept = (oDOWRes?.[0]?.departure_DOW?.[weekdays[dayDate.getDay()]]) ? oDOWRes?.[0]?.departure_DOW?.[weekdays[dayDate.getDay()]] : '1'

            const arrival = (bArrival == '1' && oArrival == '1') ? '1' : '0'
            const departure = (bDept == '1' && oDept == '1') ? '1' : '0'

            let closedTo = '0'
            if(arrival == '1' && departure == '1') {
              closedTo = '0'
            } else if(arrival == '0' && departure == '1') {
              closedTo = '1'
            } else if(arrival == '1' && departure == '0') {
              closedTo = '2'
            } else if(arrival == '0' && departure == '0') {
              closedTo = '3'
            }
            if(masterRes == '0') closedTo = '3'

            const dayAvailabilitiesForRoom = availData?.availability?.[code]?.dayAvailabilities
            let availability = 0
            if(dayAvailabilitiesForRoom) {
              availability = dayAvailabilitiesForRoom?.find((d) => { 
                if(d?.day == dateIsoFormat(dayDate)) {
                  return true
                }
              })?.availability
            }

            if(newRatePlans?.[code]?.[ratePlanCode]) {
              newRatePlans[code][ratePlanCode]['dayRates'][dayStartIndex] = {
                ...newRatePlans?.[code]?.[ratePlanCode]?.['dayRates']?.[dayStartIndex],
                day: dateIsoFormat(dayDate),
                minstay,
                minstaythrough: bForwardMinLos ?? '-',
                maxstay,
                maxstaythrough: bForwardMaxLos ?? '-',
                arrival: arrival,
                departure: departure,
                master: masterRes,
                closedto: closedTo,
                availability
              }
            }
            dayStartIndex++
          }
          
        }
      })
    }

  })

  return newRatePlans
}

const resolveRates = async ({dataSources, db}, { property }, params) => {
  const options = setOptions({ ...params, ...params.options })
  const { data: xmlRates, error: ratesError } = await fetchXMLRates(dataSources, {
    ...params,
    ...params.options,
    ...options
  })
  
  if (ratesError) {
    throw `Rates: ${JSON.stringify(ratesError)}`
  }

  const availData = await resolveAvailability({ property }, params, { dataSources, db })

  const ratePlans = await resolveXMLRatePlan(xmlRates[0].RatePlan, options, property, availData)

  return ratePlans
}

//resolver for dynamic call
const ratesResolver = async (parent, params, context, info) => {
  // const { cache, ttl } = context
  // const { userId, provider, language } = parent.params.options
  // const key = generateCacheKey('rates', params, userId, provider, language)
  // console.log(userId)
  // const cacheHit = await cache?.get(key)
  // if (cacheHit) {
  //   return JSON.parse(cacheHit)
  // } else {
  //   const cacheableValue = await resolveRates(context, parent.params, { ...parent.params.options, ...params })
  //   cache?.setEx(key, ttl, JSON.stringify(cacheableValue))
  //   return cacheableValue
  // }

  const cacheableValue = await resolveRates(context, parent.params, { ...parent.params.options, ...params })
  return cacheableValue
}

module.exports = {
  ratesResolver, //dynamic call
  resolveRates, //internal call
}

