const generateCacheKey = require('../../../cache/L1Cache/generateCacheKey')
const convertToDaysStringAlpinebits = require('../../../utils/convertToDaysStringAlpinebits')
const { strSplit } = require('../../../utils/string')
const {
  DEFAULT_MEALPLANCODE,
} = require('../constants')
const { resolveRates } = require('./resolveRates')

const resolvePrices = (rates, priceType, std_occup, amountType) => {
  return rates
    .map((rate) => {
      if (rate?.adults?.[std_occup]) {
        let price
        if(amountType == '7') {
          price = (parseFloat(rate.adults[std_occup]) * parseInt(std_occup)).toFixed(2) * 1
        } else {
          price = parseFloat(rate.adults[std_occup])
        }
        return priceType === 'SINGLE' ? (price / std_occup).toFixed(2) * 1 : price
      } else if (rate?.adults && rate.adults?.additional) {
        // const maxAdultCount = Math.max(...Object.keys(rate.adults).filter((p) => !isNaN(p)))
        // const total = rate.adults[maxAdultCount.toString()] + (std_occup - maxAdultCount) * rate.adults.additional
        // return priceType === 'SINGLE' ? (total / std_occup).toFixed(2) * 1 : total
      } else {
        return null
      }
    })
    .join('|')
}

/**
 * Resolves offersOverview data and extracts only useful data from it
 * @param {Object} offersOverview
 * @param {String} language
 * @param {String} roomCode
 * @param {Array} rooms
 * @param {Array} offers
 * @returns {object}
 */
const resolveRateplansAndOffers = async (
  { language, priceType = 'STD', roomCode = '', ...params },
  ratesXML,
  roomCodeToRoomDetails
) => {
  const rates = {}
  const roomCodes = roomCode?.split(',')
  const promotionCodes = params?.promotionCodes ? strSplit(',', params?.promotionCodes) : []

  for(let roomcode in ratesXML) {
    // if(!rooms.includes(roomcode)) {
    //   continue
    // }
    const roomData = roomCodeToRoomDetails[roomcode]
    for(let ratecode in ratesXML[roomcode]) {
      const rateOfXML = ratesXML?.[roomcode]?.[ratecode]
      const isPackage = (rateOfXML?.ratePlanType == '12' || rateOfXML?.offers?.familyOffer || rateOfXML?.offers?.freeNightOffer) ?? false
      if (rateOfXML && (!roomCode || roomCodes.includes(roomcode))) {
        const stringsFromXML = rateOfXML.dayRates.reduce(
          (acc, cur, idx) => {
            acc.minstay[idx] = cur?.minstay || '-'
            acc.maxstay[idx] = cur?.maxstay || '-'
            acc.minstaythru[idx] = cur?.minstaythrough || '-'
            acc.maxstaythru[idx] = cur?.maxstaythrough || '-'
            acc.arrival[idx] = cur?.arrival || '-'
            acc.departure[idx] = cur?.departure || '-'
            acc.closedto[idx] = cur?.closedto || '-'
            acc.availability[idx] = cur?.availability || 0
            acc.master[idx] = cur?.master || '-'
            // if(roomCodeToAvailRef[roomcode][idx] < 1) {
            //   acc.minstay[idx] = '0'
            //   acc.maxstay[idx] = '0'
            //   acc.minstaythru[idx] = '0'
            //   acc.maxstaythru[idx] = '0'
            // }
            return acc
          },
          {
            minstay: Array(rateOfXML.dayRates.length),
            maxstay: Array(rateOfXML.dayRates.length),
            minstaythru: Array(rateOfXML.dayRates.length),
            maxstaythru: Array(rateOfXML.dayRates.length),
            arrival: Array(rateOfXML.dayRates.length),
            departure: Array(rateOfXML.dayRates.length),
            closedto: Array(rateOfXML.dayRates.length),
            availability: Array(rateOfXML.dayRates.length),
            master: Array(rateOfXML.dayRates.length)
          },
        )
  
        const [days, min_los, min_stay_thru, max_los, max_stay_thru, closed_to] = await Promise.all([
          convertToDaysStringAlpinebits(stringsFromXML),
          stringsFromXML?.minstay,
          stringsFromXML?.minstaythru,
          stringsFromXML?.maxstay,
          stringsFromXML?.maxstaythru,
          stringsFromXML?.closedto,
        ])

        const rateplanObj = {
          room_code: roomcode,
          rate_code: ratecode,
          isPackage: isPackage,
          title: rateOfXML?.title,
          description: rateOfXML?.description,
          meal_plan_code: rateOfXML['mealPlanCode'] || DEFAULT_MEALPLANCODE,
          availabilities: stringsFromXML?.availability?.join('|'),
          days: days.join('|'),
          min_los: min_los.join('|'),
          min_stay_thru: min_stay_thru.join('|'),
          max_los: max_los.join('|'),
          max_stay_thru: max_stay_thru.join('|'),
          closed_to: closed_to.join('|'),
          prices: resolvePrices(rateOfXML.dayRates, priceType, roomData.types[0].std_occup, rateOfXML?.amountType),
        }
  
        if (!rates[roomcode]) {
          rates[roomcode] = {
            roomCode: roomcode,
            rateplans: rateplanObj.isPackage ? [] : [rateplanObj],
            offers: rateplanObj.isPackage ? [rateplanObj] : [],
          }
        } else {
          if (rateplanObj.isPackage) {
            rates[roomcode].offers.push(rateplanObj)
          } else {
            rates[roomcode].rateplans.push(rateplanObj)
          }
        }
      }

    }
  }
  return Object.values(rates || {})
}

const resolveOverview = async ({ dataSources, db }, { property }, params) => {
  const ratesXML = await resolveRates({ db, dataSources }, { property }, params)

  const roomCodeToRoomDetails = property.facility?.rooms?.reduce((acc, room) => {
    acc[room.code] = room
    return acc
  }, {})

  return resolveRateplansAndOffers(params, ratesXML, roomCodeToRoomDetails)
}

//resolver for dynamic call
const overviewResolver = async (parent, params, context, info) => {
  const { cache, ttl } = context
  const { userId, provider, language } = parent.params.options
  const key = generateCacheKey('overview', params, userId, provider, language)
  const cacheHit = await cache?.get(key)
  if (cacheHit) {
    return JSON.parse(cacheHit)
  } else {
    const cacheableValue = await resolveOverview(context, parent.params, { ...parent.params.options, ...params })
    cache?.setEx(key, ttl, JSON.stringify(cacheableValue))
    return cacheableValue
  }
}

module.exports = {
  overviewResolver, //dynamic call
  resolveOverview, //internal call
}
