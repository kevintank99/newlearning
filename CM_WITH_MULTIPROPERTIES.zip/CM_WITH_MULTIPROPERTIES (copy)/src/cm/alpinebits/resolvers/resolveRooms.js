// const { resolveRoomCategories } = require('./resolveRoomCategories')
const {
  bedTypes,
  bedTypeAmenityCodes,
  roomTypes,
  roomTypesCamping,
  hotelOnlyRoomAmenities,
  roomAmenities,
} = require('../constants')
const generateCacheKey = require('../../../cache/L1Cache/generateCacheKey')

const resolveCategories = (roomCode, options) => {
  const roomCategories = options?.config?.rooms?.categories ? Object.entries(options?.config?.rooms?.categories) : []
  return roomCategories.reduce((acc, [categoryCode, values]) => {
    return values?.codes?.find((rCode) => rCode == roomCode)
      ? [
          ...acc,
          {
            code: categoryCode,
            title: values?.title?.[options?.language],
          },
        ]
      : acc
  }, [])
}

const resolveDescriptions = (descriptions, options) => {
  return descriptions?.reduce((acc, { info_code, text_items }) => {
    if(info_code == '1') { // description
      acc.description = text_items?.[0]?.descriptions?.find(desc => desc?.language?.toLowerCase() == options.language)?.content
    } else if(info_code == '25') { //title
      acc.title = text_items?.[0]?.descriptions?.find(desc => desc?.language?.toLowerCase() == options.language)?.content
    }
    return acc
  }, { title: null, description: null })
}

const resolveImageTitle = (descriptions, options) => {
  return descriptions?.reduce((acc, { language, content }) => {
    return language.toLowerCase() == options.language ? { title: content } : acc
  }, '')
}

/**
 * Resolve room images and split them into regular gallery and floorplans
 * set options.rooms.floorplans.skipgallery = false to override splitting
 * @param {*} descriptions
 * @param {*} options
 */
const resolveImages = (descriptions, options) => {
  return descriptions
    ? descriptions?.reduce(
        (acc, { image_items }) => {
          return image_items?.reduce((acc, { category, image_formats, descriptions }) => {
            const image = { url: image_formats[0].url?.[0], ...resolveImageTitle(descriptions, options) }
            category == 21 && (options?.rooms?.floorplans?.skipgallery || true) //by default, do not include floor plans in gallery
              ? acc.floorplans.push(image)
              : acc?.images?.push(image)
            return acc
          }, {images: [], floorplans: []})
        },
        { images: [], floorplans: [] },
      )
    : {}
}

/**
 * Resolve Room Amenities respecting camping types to ignore beds and add custom ones
 * @param {array} amenities
 * @param {object} options
 */
const resolveAmenities = (amenities, options, camping) => {
  //TODO: add custom room amenities from config
  return amenities?.reduce((acc, { code, quantity }) => {
    acc.push({
      code,
      title: roomAmenities?.[`RAT_${code}`]?.[options.language]
    })
    return acc
  }, [])
}

/**
 * Determine the room type and camping category
 * @param {string} roomCode
 * @param {string} roomTypeCode
 * @param {object} options
 */
const resolveType = (roomCode, roomTypeCode, options) => {
  const code =
    options.config?.rooms?.type && options.config.rooms.type[roomCode]
      ? options.config.rooms.type[roomCode]
      : roomTypeCode
  return {
    code,
    name: roomTypes[code][options.language],
    camping: roomTypesCamping.indexOf(code) > -1,
  }
}

/**
 * Resolve the maximum age under which children are considered
 * @param {array} childArray
 */
const resolveMaxChildAge = (childArray) => {
  return childArray.reduce((acc, child) => {
    const ageQualifyingCode = child.age_qualifying_code - 100

    if (!acc['maxChildAge']) {
      acc['maxChildAge'] = ageQualifyingCode
    } else {
      if (parseInt(ageQualifyingCode) > parseInt(acc['maxChildAge'])) {
        acc['maxChildAge'] = ageQualifyingCode
      }
    }

    return acc
  }, {})
}

const resolveRooms = async (propertyData, options) => {
  // const roomCategories = resolveRoomCategories(propertyData, options)
  const rooms = propertyData.facility?.rooms || []

  return rooms.map(
    ({
      code,
      title,
      descriptions,
      min_occup,
      max_occup,
      min_child_occup,
      max_child_occup,
      min_adult_occup,
      max_adult_occup,
      types,
      amenities,
      quantity,
    }) => {
      const { size, non_smoking, bed_code, std_num_beds, max_rollaways, std_occup } = types[0] //attention: the standard occupancy is in the bed type
      const type = resolveType(code, types[0].type, options)
      return {
        code,
        title,
        ...resolveDescriptions(descriptions, options),
        size,
        categories: resolveCategories(code, options),
        nonSmoking: non_smoking,
        quantity,
        occupancy: {
          std: std_occup,
          min: min_occup,
          max: max_occup,
          range: min_occup == max_occup ? min_occup : `${min_occup} - ${max_occup}`,
          minChildren: min_child_occup ?? 0,
          maxChildren: Math.min(
            max_child_occup ?? max_occup - (min_adult_occup ?? 1),
            max_occup - (min_adult_occup ?? 1),
          ),
          minAdults: min_adult_occup ?? 1,
          maxAdults: Math.min(max_adult_occup ?? max_occup, max_occup - (min_child_occup ?? 0)), //Always consider the minimum because of following use case where min child is there so you cannot fit in all the max adults
        },
        beds: type.camping
          ? null
          : {
              //camping types do not have a bed
              stdNum: std_num_beds,
              maxRollaways: max_rollaways,
              type: {
                code: bed_code,
                name:
                  bedTypes?.[bed_code]?.[options.language] || bedTypeAmenityCodes?.[bed_code]?.[options.language] || '',
              },
            },
        type,
        amenities: resolveAmenities(amenities, options, type.camping),
        ...resolveImages(descriptions, options),
        ...resolveMaxChildAge(propertyData.ext?.children || []),
      }
    },
  )
}

// //resolver for dynamic call
// const roomsResolver = async (parent, params, context, info) => {
//   const { cache, ttl } = context
//   const { userId, provider, language } = parent.params.options
//   const key = generateCacheKey('rooms', params, userId, provider, language)
//   const cacheHit = await cache?.get(key)
//   if (cacheHit) {
//     return JSON.parse(cacheHit)
//   } else {
//     console.log('parent - ', parent)
//     const cacheableValue = await resolveRooms(parent.params.property, { ...parent.params.options, ...params })
//     cache?.setEx(key, ttl, JSON.stringify(cacheableValue))
//     return cacheableValue
//   }
// }

//resolver for dynamic call
const roomsResolver = async (parent, params, context, info) => {
  const cacheableValue = await resolveRooms(parent.params.property, { ...parent.params.options, ...params })
  return cacheableValue
}

module.exports = {
  roomsResolver,
  resolveRooms,
}

