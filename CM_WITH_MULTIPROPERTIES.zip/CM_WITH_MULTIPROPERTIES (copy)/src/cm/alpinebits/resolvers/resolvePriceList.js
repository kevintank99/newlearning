const { isStringValue } = require('../../../utils/type')
const { dateToday, dateDiffDays, dateFrom } = require('../../../utils/date')
const { DEFAULT_MEALPLANCODE, roomTypes } = require('../constants')
const { resolveRates } = require('./resolveRates')

const setOptions = (params) => {
  let options = {}
  options.checkin = isStringValue(params.start) ? params.start : dateToday()
  options.checkout = isStringValue(params.end) ? params.end : dateToday()
  options.roomCodes = isStringValue(params.roomCode) ? params.roomCode : ''
  options.rooms = [
    {
      adults: params.adults,
      children: params.children,
    },
  ]
  // options.promotionCode = isStringValue(params.promotionCode) ? params.promotionCode : ''
  return options
}

function resolveOccupancy(roomDetails) {
  return {
    min: roomDetails?.min_occup,
    max: roomDetails?.max_occup,
    standard: roomDetails?.types?.[0]?.std_occup,
  }
}

function resolveMinDayRateAdults(dayRates, occupancy, amountType, unitMultiplier, pricetype) {
  const minOccup = parseInt(occupancy.min)
  const maxOccup = parseInt(occupancy.max)
  const stdOccup = parseInt(occupancy.standard)

  // min adult price for all occupancy
  let minRateRange = {}
  for(let i = minOccup; i <= maxOccup; i++) {
    minRateRange[i] = Math.min(...dayRates.reduce((acc, dRate) => {
      if(dRate?.adults?.[i]) {
        if(amountType == '7') {
          // price based on the amount type 7 (per person)
          acc.push(dRate?.adults?.[i] * i / unitMultiplier) 
        } else {
          // price based on the amount type 25 (per room) - default
          acc.push(dRate?.adults?.[i] / unitMultiplier)
        }
      } else if(dRate?.adults?.additional && dRate?.adults?.[stdOccup] && i > stdOccup) { // set the price for occupancy > std
        if(amountType == '7') {
          acc.push((parseInt(dRate?.adults?.[stdOccup]) * stdOccup + (i - stdOccup) * parseInt(dRate?.adults?.additional)) / unitMultiplier)
        } else {
          acc.push((parseInt(dRate?.adults?.[stdOccup]) + (i - stdOccup) * parseInt(dRate?.adults?.additional)) / unitMultiplier)
        }
      }
      return acc
    }, []))
  }

  // min adult price for std occupancy
  let minAdultRateForStdOccu = Math.min(...dayRates.reduce((acc, dRate) => {
    if(dRate?.adults?.[stdOccup]) {
      acc.push(dRate?.adults?.[stdOccup])
    }
    return acc
  }, []))

  if(amountType == '7') {
    minAdultRateForStdOccu = minAdultRateForStdOccu * stdOccup / unitMultiplier
  } else {
    minAdultRateForStdOccu = minAdultRateForStdOccu / unitMultiplier
  }
  const priceSingleMin = (minAdultRateForStdOccu / stdOccup).toFixed(2) * 1

  return {
    amount: (pricetype == 'SINGLE') ? priceSingleMin : minAdultRateForStdOccu,
    single: priceSingleMin,
    std: minAdultRateForStdOccu,
    rate: minRateRange,
    guests: stdOccup
  }
}

function resolveMaxDayRateAdults(dayRates, occupancy, amountType, unitMultiplier, pricetype) {
  const minOccup = parseInt(occupancy.min)
  const maxOccup = parseInt(occupancy.max)
  const stdOccup = parseInt(occupancy.standard)

  // max adult price for all occupancy
  let maxRateRange = {}
  for(let i = minOccup; i <= maxOccup; i++) {
    maxRateRange[i] = Math.max(...dayRates.reduce((acc, dRate) => {
      if(dRate?.adults?.[i]) {
        if(amountType == '7') {
          // price based on the amount type 7 (per person)
          acc.push(dRate?.adults?.[i] * i / unitMultiplier)
        } else {
          // price based on the amount type 25 (per room) - default
          acc.push(dRate?.adults?.[i] / unitMultiplier)
        }
      } else if(dRate?.adults?.additional && dRate?.adults?.[stdOccup] && i > stdOccup) { // set the price for occupancy > std
        if(amountType == '7') {
          acc.push((parseInt(dRate?.adults?.[stdOccup]) * stdOccup + (i - stdOccup) * parseInt(dRate?.adults?.additional)) / unitMultiplier)
        } else {
          acc.push((parseInt(dRate?.adults?.[stdOccup]) + (i - stdOccup) * parseInt(dRate?.adults?.additional)) / unitMultiplier)
        }
      }
      return acc
    }, []))

    // if(amountType == '7') {
    //   maxRateRange[i] = maxRateRange[i] * i / unitMultiplier
    // } else {
    //   maxRateRange[i] = maxRateRange[i] / unitMultiplier
    // }
  }

  // max adult price for std occupancy
  let maxAdultRateForStdOccu = Math.max(...dayRates.reduce((acc, dRate) => {
    if(dRate?.adults?.[stdOccup]) {
      acc.push(dRate?.adults?.[stdOccup])
    }
    return acc
  }, []))

  if(amountType == '7') {
    maxAdultRateForStdOccu = maxAdultRateForStdOccu * stdOccup / unitMultiplier
  } else {
    maxAdultRateForStdOccu = maxAdultRateForStdOccu / unitMultiplier
  }
  const priceSingleMax = (maxAdultRateForStdOccu / stdOccup).toFixed(2) * 1
  
  return {
    amount: (pricetype == 'SINGLE') ? priceSingleMax : maxAdultRateForStdOccu,
    single: priceSingleMax,
    std: maxAdultRateForStdOccu,
    rate: maxRateRange,
    guests: stdOccup
  }
}

function resolveMinMaxRateChildren(dayRates) {
  const childRates = dayRates.reduce((acc, dRate) => {
    if(dRate?.children) {
      // acc.push(dRate?.children)
      Object.entries(dRate?.children)?.forEach(([ageRange, price]) => {
        if(!acc[ageRange]) {
          acc[ageRange] = []
        }
        acc[ageRange].push(price)
      })
    }
    return acc
  }, {})

  const minPriceChildren = {}
  const maxPriceChildren = {}
  for(let key in childRates) {
    minPriceChildren[key] = Math.min(...childRates[key])
    maxPriceChildren[key] = Math.max(...childRates[key])
  }
  
  return {
    min: minPriceChildren,
    max: maxPriceChildren
  }
}

function resolveRatePrices(dayRates, occupancy, amountType, unitMultiplier, params) {
  return {
    adults: {
      min: resolveMinDayRateAdults(dayRates, occupancy, amountType, unitMultiplier, params?.pricetype),
      max: resolveMaxDayRateAdults(dayRates, occupancy, amountType, unitMultiplier, params?.pricetype)
    },
    children: resolveMinMaxRateChildren(dayRates)
  }
}

function resolveRatePlans(ratesData, occupancy, params) {
  const ratesOffersPrices = { rateplans: [], offers: [] }
  Object.entries(ratesData)?.forEach(([ratecode, rateplan]) => {
    let rateObj = {
      code: ratecode,
      ratePlanType: rateplan?.ratePlanType,
      mealplancode: rateplan?.mealPlanCode,
      unitMultiplier: rateplan?.unitMultiplier,
      amountType: (rateplan?.amountType == '7') ? 'PER_PERSON' : 'PER_ROOM',
      price: resolveRatePrices(rateplan?.dayRates, occupancy, rateplan?.amountType, rateplan?.unitMultiplier, params)
    }
    if(rateplan?.ratePlanType == '12') {
      ratesOffersPrices.offers.push(rateObj)
    } else {
      ratesOffersPrices.rateplans.push(rateObj)
    }
  })
  return ratesOffersPrices
}

function resolveRoomPrices(ratePlansPrices) {
  let roomPrices = {
    adults: { min: {}, max: {} },
    children: { min: {},  max: {} }
  }

  ratePlansPrices?.forEach(({ price }, index) => {
    const adultMin = price.adults.min
    const adultMax = price.adults.max
    const childrenMin = price.children.min
    const childrenMax = price.children.max
    if(index == 0) {
      roomPrices.adults = { ...price?.adults }
      roomPrices.children = { ...price?.children }
    } else {
      roomPrices.adults.min = {
        amount: Math.min(adultMin?.amount, roomPrices.adults.min?.amount),
        single: Math.min(adultMin?.single, roomPrices.adults.min?.single),
        std: Math.min(adultMin?.std, roomPrices.adults.min?.std),
        rate: {...roomPrices.adults.min.rate},
        guests: roomPrices.adults.min?.guests
      }
      roomPrices.adults.max = {
        amount: Math.max(adultMax?.amount, roomPrices.adults.max?.amount),
        single: Math.max(adultMax?.single, roomPrices.adults.max?.single),
        std: Math.max(adultMax?.std, roomPrices.adults.max?.std),
        rate: {...roomPrices.adults.max.rate},
        guests: roomPrices.adults.max?.guests
      }
      for(let key in adultMin?.rate) {
        roomPrices.adults.min.rate[key] = Math.min(roomPrices.adults.min.rate?.[key], adultMin.rate?.[key])
        roomPrices.adults.max.rate[key] = Math.max(roomPrices.adults.max.rate?.[key], adultMax.rate?.[key])
      }
      for(let key in childrenMin) {
        roomPrices.children.min[key] = Math.min(roomPrices.children.min?.[key], childrenMin[key])
        roomPrices.children.max[key] = Math.max(roomPrices.children.max?.[key], childrenMax[key])
      }
    }
  })
  return roomPrices
}

// resolver for internal call
const resolvePriceList = async ({ dataSources }, { property, token }, params) => {
  let rates =  await resolveRates({ dataSources }, { property }, params)

  let roomCode = params?.roomCode
  if(roomCode && rates?.[roomCode]) {
    rates = { [roomCode] : (rates?.[roomCode]) ? (rates?.[roomCode]) : {} }
  }

  const roomCodeToRoomDetails = property.facility?.rooms?.reduce((acc, room) => {
    acc[room.code] = room
    return acc
  }, {})

  const roomsJson = []
  Object.entries(rates).forEach(([roomcode, ratesData]) => {
    const occupancy = resolveOccupancy(roomCodeToRoomDetails[roomcode])
    const ratePlansPrices = resolveRatePlans(ratesData, occupancy, params)
    const roomPrices = resolveRoomPrices([...ratePlansPrices.rateplans, ...ratePlansPrices.offers], params)
    let roomObj = {
      roomcode,
      ...ratePlansPrices,
      price: {
        type: (params?.pricetype == 'SINGLE') ? 'single' : 'standard',
        ...roomPrices
      },
    }
    roomsJson.push(roomObj)
  })

  return roomsJson
}

//resolver for dynamic call
const priceListResolver = async (parent, params, context, info) => {
  return resolvePriceList(context, parent.params, { ...parent.params.options, ...params })
}

module.exports = {
  priceListResolver, //dynamic call
  resolvePriceList, //internal call
}

