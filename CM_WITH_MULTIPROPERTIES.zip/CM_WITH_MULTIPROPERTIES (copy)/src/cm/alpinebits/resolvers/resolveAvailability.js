
const generateCacheKey = require('../../../cache/L1Cache/generateCacheKey')
const { fetchAvailabilities } = require('../fetchers')
const { isArray, isObject, isStringValue, isNull } = require('../../../utils/type')
const { isPositiveNumber } = require('../../../utils/number')
const { ratePlanTypes, defaults } = require('../constants')
const {
  dateToday,
  dateAddDays,
  dateFrom,
  dateDiffDays,
  dateIsoFormat,
  dateDiffDaysAfterTimeRange,
} = require('../../../utils/date')

const setOptions = (params) => {
  let options = {}
  options.startDate = isStringValue(params.startDate)
    ? dateFrom(params.startDate)
    : dateFrom(params.config.startDate || dateToday())
  options.numberOfDays = isPositiveNumber(params.length)
    ? params.length
    : params?.config?.timerange
    ? dateDiffDaysAfterTimeRange(params.config.timerange)
    : defaults.numberOfDays
  options.endDate = dateAddDays(options.numberOfDays, dateFrom(options.startDate))
  return options
}

const resolveXMLAvailability = async (xmlAvailData, options, property) => {
  const roomsData = property?.facility?.rooms
  // const availability = []
  // roomsData.forEach(({code}) => {
  //   isObject(newRatePlans[code]) || (newRatePlans[code] = {})
  // })

  const availabilityData = xmlAvailData?.reduce((acc, { RoomTypes, TimeSpan }) => {
    let roomcode = RoomTypes?.[0]?.['RoomType']?.[0]?.['$']?.RoomTypeCode
    let availability = RoomTypes?.[0]?.['RoomType']?.[0]?.['$']?.Availability
    let start = TimeSpan?.[0]?.['$']?.Start
    let end = TimeSpan?.[0]?.['$']?.End

    isObject(acc[roomcode]) || (acc[roomcode] = {})
    isArray(acc[roomcode]['dayAvailabilities']) ||
      (acc[roomcode]['dayAvailabilities'] = Array(options.numberOfDays).fill(null))

    let dayStartIndex = dateDiffDays(options.startDate, dateFrom(start))
    let dayEndIndex = dateDiffDays(options.startDate, dateFrom(end))
    let dayDate

    while(dayStartIndex <= dayEndIndex) {
      dayDate = dateAddDays(dayStartIndex, options.startDate)
      
      acc[roomcode]['dayAvailabilities'][dayStartIndex] = {
        day: dateIsoFormat(dayDate),
        availability
      }
      dayStartIndex++
    }

    return acc
  }, {})

  // console.log('availanb - ', availabilityData)

  return availabilityData
}

const resolveAvailability = async (propertyData, params, { dataSources }) => {

  const options = setOptions({ ...params, ...params.options })
  const { data: availData, error: availError } = await fetchAvailabilities(dataSources, {
    ...params,
    ...params.options,
    ...options
  })
  if (availError) {
    throw `Availability: ${JSON.stringify(availError)}`
  }

  const availability = await resolveXMLAvailability(availData?.[0]?.RoomStay, options, propertyData)

  return {
    availability
  }  
}

//resolver for dynamic call
const availabilityResolver = async (parent, params, context, info) => {
  const { cache, ttl } = context
  const { userId, provider, language } = parent.params.options
  const key = generateCacheKey('availability', params, userId, provider, language)
  const cacheHit = await cache?.get(key)
  if (cacheHit) {
    return JSON.parse(cacheHit)
  } else {
    const cacheableValue = await resolveAvailability(parent.params.property, { ...parent.params.options, ...params }, context)
    cache?.setEx(key, ttl, JSON.stringify(cacheableValue))
    return cacheableValue
  }
}

module.exports = {
  availabilityResolver,
  resolveAvailability,
}
