// const generateCacheKey = require('../../../cache/L1Cache/generateCacheKey')

const resolveRoomCategories = (propertyData, options) => {

  const roomCategories = options?.config?.rooms?.categories ? Object.entries(options?.config?.rooms?.categories) : []
  return roomCategories.reduce((acc, [categoryCode, values]) => {
    if(values?.codes?.length && values?.codes?.length > 1) {
      acc.push({
        code: categoryCode,
        title: values?.title?.[options?.language],
      })
    }
    return acc
  }, [])
}

//resolver for dynamic call
const roomCategoriesResolver = async (parent, params, context, info) => {
  // const { cache, ttl } = context
  // const { userId, provider, language } = parent.params.options
  // const key = generateCacheKey('roomCategories', params, userId, provider, language)
  // const cacheHit = await cache?.get(key)
  // if (cacheHit) {
  //   return JSON.parse(cacheHit)
  // } else {
  //   const cacheableValue = resolveRoomCategories(parent.params.property, { ...parent.params.options, ...params })
  //   cache?.setEx(key, ttl, JSON.stringify(cacheableValue))
  //   return cacheableValue
  // }
  const cacheableValue = resolveRoomCategories(parent.params.property, { ...parent.params.options, ...params })
  return cacheableValue
}

module.exports = {
  roomCategoriesResolver,
  resolveRoomCategories,
}
