const { fetchOffers } = require('../fetchers')
const { isStringValue } = require('../../../utils/type')
const { dateToday, dateDiffDays, dateFrom } = require('../../../utils/date')
const { DEFAULT_MEALPLANCODE } = require('../constants')
const { strSplit } = require('../../../utils/string')
const { resolveRates } = require('./resolveRates')
const { min } = require('date-fns')

const setOptions = (params) => {
  let options = {}
  options.checkin = isStringValue(params.start) ? params.start : dateToday()
  options.checkout = isStringValue(params.end) ? params.end : dateToday()
  options.roomCodes = isStringValue(params.roomCode) ? params.roomCode : ''
  options.rooms = [
    {
      adults: params.adults,
      children: params.children,
    },
  ]
  // options.promotionCode = isStringValue(params.promotionCode) ? params.promotionCode : ''
  return options
}

/**
 * Creates an array of room codes which support the required occupancy
 * @param {array} occupancy
 * @param {object} property
 * @param {array} roomCodes
 * @returns {array}
 */
const resolveRoomsWithSupOcc = (occupancy, property, roomCodes = '') => {
  roomCodes = roomCodes ? strSplit(',', roomCodes) : ''
  return occupancy.map(({ adults, children }) => {
    adults = Number(adults)
    children = children && children.length ? children.map(Number) : []
    return property.facility?.rooms.reduce((acc, room) => {
      if (
        adults + children.length >= room.min_occup &&
        adults + children.length <= room.max_occup &&
        adults >= (room.min_adult_occup ?? Number.MIN_SAFE_INTEGER) &&
        adults <= (room.max_adult_occup ?? Number.MAX_SAFE_INTEGER) &&
        children.length >= (room.min_child_occup ?? Number.MIN_SAFE_INTEGER) &&
        children.length <= (room.max_child_occup ?? Number.MAX_SAFE_INTEGER) &&
        (!roomCodes || roomCodes.includes(room.code))
      ) {
        acc = acc.concat(`${acc ? ',' : ''}${room.code}`)
      }
      return acc
    }, '')
  })
}


function calculateTotalCost(rate, stayLength, numOfGuests, effAdults, effChildren, stdOccup, freeNightOffer, roomcode) {
  // console.log('rate --- ', rate)
  const rateObj = {}
  const pricing_details = {}
  let totalCost = 0
  for(let j = 0; j <= stayLength; j++) {
    // console.log('dayratesss -- ', rate?.dayRates[j])
    // console.log('stayLen', stayLength)

    // console.log('maxstay - ', rate?.dayRates[j]?.maxstay)
    if(stayLength < parseInt(rate?.dayRates[j]?.minstay)) {
      rateObj.message = `stay is restricted (length of stay (${stayLength}) is below minimum (${rate?.dayRates[j]?.minstay}))`
      console.log('master close ', rate?.rateCode)
    } else if(stayLength > parseInt(rate?.dayRates[j]?.maxstay)) {
      rateObj.message = `stay is restricted (length of stay (${stayLength}) exceeds maximum (${rate?.dayRates[j]?.maxstay}))`
      console.log('master close ', rate?.rateCode)
    } else if(rate?.dayRates[j]?.master == '0') { // check master close/open
      rateObj.message = `master close`
      console.log('master close ', rate?.rateCode)
      break
    } else if(j == 0 && (rate?.dayRates[j]?.closedto == '1' || rate?.dayRates[j]?.closedto == '3')) { // check arrival
      rateObj.message = `arrival close`
      console.log('arrival close ', rate?.roomCode, rate?.rateCode)
      break
    } else if(j == stayLength && (rate?.dayRates[j]?.closedto == '2' || rate?.dayRates[j]?.closedto == '3')) { // check departure
      rateObj.message = `departure close`
      console.log('departure close ', rate?.roomCode, rate?.rateCode)
      break
    } else {
      // console.log('valid DOW restrictions - ', rcode, rate?.rateCode)
      if(j != stayLength) {
        let dayCost = 0
        if(rate?.dayRates[j]?.adults?.[numOfGuests]) {
          if(rate?.amountType == '7') {
            // console.log('numOfGuests - ', numOfGuests, effAdults, stdOccup, Number(rate?.dayRates[j]?.adults?.[numOfGuests]))
            if(effAdults > stdOccup) {
              if(!rate?.dayRates[j]?.adults?.['additional']) {
                rateObj.message = `no price set for additional guests`
                console.log('no price set for additional guests ', rcode, rate?.rateCode)
                break
              }
              dayCost += (Number(rate?.dayRates[j]?.adults?.[numOfGuests]) * stdOccup) + (effAdults - stdOccup) * (Number(rate?.dayRates[j]?.adults?.['additional'])) // additional guest amt
            } else {
              dayCost += (Number(rate?.dayRates[j]?.adults?.[numOfGuests]) * effAdults)
            }
          } else if(rate?.amountType == '25') {
            if(effAdults > stdOccup) { // for additional adults
              if(!rate?.dayRates[j]?.adults?.['additional']) {
                rateObj.message = `no price set for additional guests`
                console.log('no price set for additional guests ', rcode, rate?.rateCode)
                break
                // return errMsg
              } else {
                dayCost += (Number(rate?.dayRates[j]?.adults?.[numOfGuests]) * stdOccup) + (effAdults - stdOccup) * (Number(rate?.dayRates[j]?.adults?.['additional'])) // additional guest amt
              }
            } else {
              dayCost += Number(rate?.dayRates[j]?.adults?.[numOfGuests])
            }
          }
          // children prices
          if(effChildren.length) {
            effChildren.forEach((cAge) => {
              let childPrice = 0
              
              if(Object.keys(rate?.dayRates[j]?.children).length) {
                Object.keys(rate?.dayRates[j]?.children).forEach((range) => {
                  const ageRange = range.split('-')
                  if(cAge >= ageRange[0] && cAge < ageRange[1]) {
                    childPrice = parseInt(rate?.dayRates[j]?.children?.[range])
                  }
                })
              }
              if(!childPrice) {
                rateObj.message = `no price set for child age - ${cAge}`
                // dayCost = 0
                console.log(`no price set for child age - ${cAge}`)
              }
              dayCost += childPrice
            })
          }
        } else {
          rateObj.message = `no matching rates for the stay`
          console.log('no matching rates for the stay - ', numOfGuests)
        }

        pricing_details[rate?.dayRates[j]?.day] = dayCost

        if(freeNightOffer && (stayLength >= parseInt(freeNightOffer?.nightsRequired))) {
          if(freeNightOffer?.discountPattern) { // freenight based on pattern
            const disPatArr = freeNightOffer?.discountPattern?.split('')
            if(disPatArr[j] == '1') {
              dayCost = 0
              pricing_details[rate?.dayRates[j]?.day] = 0
            }
          } else {
            const freeNights = parseInt(freeNightOffer?.nightsDiscounted)
            if(j >= stayLength - freeNights) {
              dayCost = 0
              pricing_details[rate?.dayRates[j]?.day] = 0
            }
          }
        }
        totalCost += dayCost
      }
      
    }
  }
  totalCost = (rateObj?.message) ? 0 : totalCost
  return {
    ...rateObj,
    total: totalCost,
    items: [{'pricing_details': pricing_details}]
  }
}

// resolver for internal call
const resolveOffers = async ({ dataSources }, { property, token }, params) => {
  
  const options = setOptions({ ...params, property })

  params.startDate = params.start
  params.endDate = params.end
  params.length = dateDiffDays(dateFrom(params.startDate), dateFrom(params.endDate)) + 1

  const rates =  await resolveRates({ dataSources }, { property }, params)

  const roomsWithSupOcc = resolveRoomsWithSupOcc(options.rooms, property, params.roomCode)

  const roomCodeToRoomDetails = property.facility?.rooms?.reduce((acc, room) => {
    acc[room.code] = room
    return acc
  }, {})

  const ratesData = []
  const alternativeRooms = new Set()

  roomsWithSupOcc.forEach((rooms, index) => {
    let nAdults = parseInt(options.rooms[index]?.adults)
    let childrenArr = options.rooms[index]?.children.sort((a, b) => parseInt(a) - parseInt(b))
    let nChildren = childrenArr.length

    rooms.split(',').forEach((rcode) => {
      const rData = roomCodeToRoomDetails[rcode]
      const minOccup = parseInt(rData?.min_occup)
      const stdOccup = parseInt(rData?.types[0]?.std_occup)
      const maxOccup = parseInt(rData?.max_occup)
      const minChildOccup = parseInt(rData?.min_child_occup ?? 0)
      const maxChildOccup = parseInt(rData?.max_child_occup ?? 0)

      const minFullPay = (!maxChildOccup) ? stdOccup : Math.min((maxOccup - maxChildOccup), stdOccup)

      const roomRatePlans = Object.entries(rates?.[rcode])

      roomRatePlans?.forEach(([rateCode, rateDetail]) => {
        let effAdults = nAdults
        let effChildren = [...childrenArr]
        let numfree = 0

        const effGuests = parseInt(effAdults + effChildren.length)
        /** transform kids to adults as long as there are any left in an attempt
        to reach the minimum number of guests that pay the full rate. */
        for(let i = 0; i < childrenArr.length; i++) {
          if(effAdults < minFullPay) {
            effChildren.splice(effChildren.length - 1, 1)
            effAdults += 1
          }
        }

        const freeNightOffer = rateDetail?.offers?.freeNightOffer
        const familyOffer = rateDetail?.offers?.familyOffer

        // check family offers
        if(familyOffer && effChildren.length > 0 && familyOffer?.ageQualifyingCode == '8') {
          let freeChild = effChildren.filter(cAge => cAge < parseInt(familyOffer?.maxAge))

          if(freeChild.length >= familyOffer?.minCount) {
            effChildren.splice(effChildren.indexOf(Math.min(...freeChild)), 1)
            numfree++
          }
        }

        const rateObj = {
          checkin: options.checkin,
          checkout: options.checkout,
          room_code: rcode,
          primary_item_code: rateCode,
          meal_plan_code: rateDetail?.mealPlanCode
        }

        let stayLength = dateDiffDays(new Date(options.checkin), new Date(options.checkout))
        let numOfGuests = effAdults
        if(rateDetail?.amountType == '7') {
          numOfGuests = Math.min((effAdults + effChildren.length + numfree), stdOccup)
        } else if(rateDetail?.amountType == '25') {
          numOfGuests = Math.min(effAdults, stdOccup)
        }

        const costDetails = calculateTotalCost(rateDetail, stayLength, numOfGuests, effAdults, effChildren, stdOccup, freeNightOffer, rcode)
        ratesData.push({...rateObj, ...costDetails})

      })
    })
  })
  
  return {
    // rateplans: Object.values(mealplanToRateplans),
    // offers: Object.values(mealplanToOffers),
    allRateplans: ratesData,
    // allOffers,
    alternativeRooms: [...alternativeRooms],
    // alternativeOffers: [...alternativeOffers],
  }
}

//resolver for dynamic call
const offersResolver = async (parent, params, context, info) => {
  return resolveOffers(context, parent.params, { ...parent.params.options, ...params })
}

module.exports = {
  offersResolver, //dynamic call
  resolveOffers, //internal call
}
