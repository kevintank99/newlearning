const { defaults } = require('../constants')
const { findValueByPath } = require('../../../utils/object')
const generateCacheKey = require('../../../cache/L1Cache/generateCacheKey')
const { fetchProperty, fetchXMLHotelInfo } = require('../fetchers')

const resolveDescriptionTextItems = (description) => 
  description?.Text?.map(t => ({
    language: t?.['$']?.Language,
    content: t?.['$']?.['_']
  }))


/**
 * Resolves video items such as languages, formats, etc
 * @param {array} videoItems 
 * @returns array
 */
 const resolveVideoItems = (videoItems) =>
 videoItems?.[0]?.VideoItem?.map(({ $, VideoFormat, Description }) => {
   return {
     category: $?.Category,
     language: $?.Language,
     caption: $?.Caption,
     version: $?.Version,
     descriptions: Description?.map(d => ({
       language: d?.['$']?.Language,
       caption: d?.['$']?.Caption,
       content: d?.['_'],
       texts: resolveDescriptionTextItems(d) //To-Do: Haven't got any example value here
     })),
     formats: VideoFormat?.map(v => ({
       url: v?.URL?.[0]
     }))
   }
 })

/**
* Resolves image items such as height, width, format, etc
* @param {array} imageItems 
* @returns array
*/
const resolveImageItems = (imageItems) =>
 imageItems?.[0]?.ImageItem?.map(({ $, ImageFormat, Description }) => {
   return {
     category: $.Category,
     image_formats: ImageFormat?.map(image => ({
       height: image?.['$']?.Height,
       width: image?.['$']?.Width,
       format: image?.['$']?.Format,
       title: image?.['$']?.Title,
       file_size: image?.['$']?.FileSize,
       url: image?.URL
     })),
     descriptions: Description?.map(d => ({
       language: d?.['$']?.Language,
       caption: d?.['$']?.Caption, //To-Do: Look into this
       content: d?.['_'],
       texts: resolveDescriptionTextItems(d) //To-Do: Also this
     }))
   }
 })

/**
* Resolves text items such as title, descriptions, etc in multiple languages
* @param {array} textItems 
* @returns array
*/
const resolveTextItems = (textItems) =>
 textItems?.[0]?.TextItem?.map(({$, Description}) => {
   let language = null, title = null
   if($){
     ({ Language: language, Title: title } = $)
   }
   //To-Do: Rework here currently setting data
   const descriptions = Description?.map((d) => ({
     language: d?.['$']?.Language,
     caption: d?.['$']?.Caption,
    //  content: d,
     content: d?.['_'],
     text_format: d?.['$']?.TextFormat,
     texts: resolveDescriptionTextItems(d)
   }))
   return {
     language,
     title,
     descriptions,
     plain_descriptions: Description?.map((d) => d?.['_'])
   }
 })

 const resolveExcludedOccupancy = (guestRoomExclusions) =>
 guestRoomExclusions?.[0]?.GuestRoomExclusion?.map(room => ({
   excluded_adult_count: room?.['$']?.AdultOccupancy,
   excluded_children_count: room?.ExcludedChildOccupancies?.[0]?.ExcludedChildOccupancy?.length,
   excluded_child_ages: room?.ExcludedChildOccupancies?.[0]?.ExcludedChildOccupancy?.reduce((acc,occup) => {
     if(occup?.['$']?.AllAges === "true"){
       acc.push("0 - 20") //To-Do: Here static value is set when all ages of children is excluded we can further extend this by using hotel specific max child age
       return acc
     } else {
       acc.push(resolveExcludedChildAgeGroups(occup?.ExcludedAgeGroups))
       return acc
     }
   }, [])
 }))

/**
* Resolves multimedia description which contains text items, image items and video items
* @param {array} description 
* @returns array
*/
const resolveDescriptions = (description) =>
 description?.[0]?.MultimediaDescription?.map(({ $, TextItems, ImageItems, VideoItems }) => {
   let AdditionalDetailCode = null,
   InfoCode = null
   if($){
     ({ AdditionalDetailCode = null, InfoCode = null } = $)
   }
   return {
     info_code: InfoCode,
     detail_code: AdditionalDetailCode,
     text_items: resolveTextItems(TextItems),
     image_items: resolveImageItems(ImageItems),
     video_items: resolveVideoItems(VideoItems)
   }
 }) || []

/**
* Resolves hotel's basic info such as name, images, content, description, etc
* @param {array} hotelInfo 
* @returns array
*/
const resolveHotelInfo = (hotelInfo) => {
  if(hotelInfo) {
    return {
      when_built: hotelInfo?.[0]?.['$']?.WhenBuilt,
      hotel_status: hotelInfo?.[0]?.['$']?.HotelStatusCode,
      tax_id: hotelInfo?.[0]?.['$']?.TaxID,
      status: hotelInfo?.[0]?.['$']?.Status,
      name: {
        short_name: hotelInfo?.[0]?.HotelName?.[0]?.['$']?.['HotelShortName'],
        content: hotelInfo?.[0]?.HotelName?.[0]?.['_'] || hotelInfo?.[0]?.HotelName?.[0]
      },
      category_codes: {
        primary_property_type: hotelInfo?.[0]?.CategoryCodes,
        code: hotelInfo?.[0]?.CategoryCodes?.[0].HotelCategory?.[0]?.['$']?.Code,
        code_detail: hotelInfo?.[0]?.CategoryCodes?.[0].HotelCategory?.[0]?.['$']?.CodeDetail,
      },
      segment_categories: hotelInfo?.[0]?.CategoryCodes?.[0]?.SegmentCategory?.reduce((acc, { $: { Code } }) => {
        acc.push({
          code: Code
        })
        return acc
      }, []),
      descriptions: {
        renovation: hotelInfo?.[0]?.Descriptions?.[0]?.Renovation?.[0]?.['$']?.RenovationCompletionDate,
        mm_descriptions: resolveDescriptions(hotelInfo?.[0]?.Descriptions?.[0]?.MultimediaDescriptions),
      },
      position: {
          altitude: hotelInfo?.[0]?.Position?.[0]?.['$']?.Altitude,
          latitude: hotelInfo?.[0]?.Position?.[0]?.['$']?.Latitude,
          longitude: hotelInfo?.[0]?.Position?.[0]?.['$']?.Longitude
      },
      services: hotelInfo?.[0]?.Services?.[0]?.Service?.map(({ $, MultimediaDescriptions }) => {
        return {
          code: $?.Code,
          business_code: $?.BusinessServiceCode,
          code_detail: $?.CodeDetail,
          descriptions: resolveDescriptions(MultimediaDescriptions),
          id: $?.ID
        }
      })
    }
  }
}


const resolveRoomTypes = (roomTypes) =>
roomTypes?.map(({$}) => ({
  bed_code: $?.BedTypecode,
  type_code: $?.RoomTypeCode,
  quantity: $?.Quantity,
  type: $?.RoomClassificationCode,
  type_ext: $?.RoomType,
  non_smoking: $?.NonSmoking,
  promo_code: $?.PromoCode,
  size: $?.Size,
  std_num_beds: $?.StandardNumBeds,
  std_occup: $?.StandardOccupancy,
  max_rollaways: $?.MaxRollaways,
}))

const resolveAmenities = (amenities) =>
amenities?.[0]?.Amenity?.map(({$}) => ({
  code: $?.RoomAmenityCode,
  quantity: $?.Quantity,
}))

const getRoomQuantity = (rooms, roomCode) => {
  let quantity = []
  rooms.forEach(room => {
      let roomID = room?.TypeRoom?.[0]?.['$']?.RoomID
      if (room?.['$']?.Code == roomCode && typeof roomID != 'undefined') {
        quantity.push(`${roomID}`)
      }
  })
  return quantity
}

const resolveFacilityRooms = (rooms) => {
  let roomsCategory = rooms?.filter((room) => !room?.TypeRoom?.[0]?.['$']?.RoomID)
  return roomsCategory?.map((room) => ({
    type_name: room?.['$']?.RoomTypeName,
    max_child_occup: room?.['$']?.MaxChildOccupancy,
    max_adult_occup: room?.['$']?.MaxAdultOccupancy,
    min_adult_occup: room?.['$']?.MinAdultOccupancy,
    min_child_occup: room?.['$']?.MinChildOccupancy,
    number_of_bedrooms: room?.TypeRoom?.[0]?.['$']?.NbrOfBedrooms,
    code: room?.['$']?.Code,
    room_ids: getRoomQuantity(rooms, room?.['$']?.Code),
    quantity: getRoomQuantity(rooms, room?.['$']?.Code).length,
    max_occup: room?.['$']?.MaxOccupancy,
    min_occup: room?.['$']?.MinOccupancy,
    types: resolveRoomTypes(room?.TypeRoom),
    amenities: resolveAmenities(room?.Amenities),
    descriptions: resolveDescriptions(room?.MultimediaDescriptions),
    occupancy_exclusions: resolveExcludedOccupancy(room?.GuestRoomExclusions)
  }))
}

const resolveFacilityInfo = (facilityInfo) => 
 ({
   rooms: resolveFacilityRooms(facilityInfo?.[0]?.GuestRooms?.[0]?.GuestRoom)
 })

  const resolvePenalties = (penalties) => 
  penalties?.map(penalty => ({
      code: penalty?.['$']?.Code,
      deadline: {
          abs_deadline: penalty?.Deadline?.[0]?.['$']?.AbsoluteDeadline,
          offset_time: penalty?.Deadline?.[0]?.['$']?.OffsetTimeUnit,
          offset_mult: penalty?.Deadline?.[0]?.['$']?.OffsetUnitMultiplier,
          offset_drop_time: penalty?.Deadline?.[0]?.['$']?.OffsetDropTime
      },
      amount_percent: {
          basis_type: penalty?.AmountPercent?.[0]?.['$']?.BasisType,
          num_nights: penalty?.AmountPercent?.[0]?.['$']?.NmbrOfNights,
          percent: penalty?.AmountPercent?.[0]?.['$']?.Percent,
          amount: penalty?.AmountPercent?.[0]?.['$']?.Amount,
          currency: penalty?.AmountPercent?.[0]?.['$']?.Currency
      },
      descriptions: penalty?.PenaltyDescription?.map(description => ({
          name: description?.['$']?.Name,
          texts: resolveDescriptionTextItems(description)
      }))
  }))

  const resolveGuarantees = (guarantees) => 
  guarantees?.[0]?.GuaranteePayment?.map(guarantee => ({
    accepted_payments: guarantee?.AcceptedPayments?.[0]?.AcceptedPayment,
    payment_code: guarantee?.['$']?.PaymentCode,
    guarantee_code: guarantee?.['$']?.GuaranteeCode,
    contract: guarantee?.['$']?.Contract,
    contract_source: guarantee?.['$']?.ContractCode,
    amount_percent: {
        percent: guarantee?.AmountPercent?.[0]?.['$']?.Percent,
        num_nights: guarantee?.AmountPercent?.[0]?.['$']?.NmbrOfNights,
        basis_type: guarantee?.AmountPercent?.[0]?.['$']?.BasisType,
        amount: guarantee?.AmountPercent?.[0]?.['$']?.Amount
    },
    deadline: guarantee?.Deadline?.[0]?.['$'],
    on_hold: {
        duration: guarantee?.OnHold?.[0]?.['$']?.Duration,
        minimum_lead_time: guarantee?.OnHold?.[0]?.['$']?.MinimumLeadTime,
        availability_threshold: guarantee?.OnHold?.[0]?.['$']?.AvailabilityThreshold,
        reminder_mail_offset: guarantee?.OnHold?.[0]?.['$']?.ReminderMailOffset,
        promotion_percent: guarantee?.OnHold?.[0]?.['$']?.PromotionPercent,
        promotion_amount: guarantee?.OnHold?.[0]?.['$']?.PromotionAmount,
    },
    descriptions: guarantee?.Description?.map(description => ({
        texts: resolveDescriptionTextItems(description)
    }))
  }))

  const resolvePolicies = (policies) => {
    let policy = policies?.[0]?.Policy?.reduce((acc, val) => {
      return { ...acc, ...val }
    }, {})

    let obj = {
      cancellation: {
        description: policy?.CancelPolicy?.[0]?.CancelPenalty?.[0]?.PenaltyDescription?.[0]?.Text?.map(t => ({
          language: t?.['$']?.Language,
          content: t?.['_'],
          text_format: t?.['$']?.TextFormat,
        }))
      },
      checkout_charge: {
        amount: policy?.CheckoutCharges?.[0]?.CheckoutCharge?.[0]?.['$']?.Amount,
        currency_code: policy?.CheckoutCharges?.[0]?.CheckoutCharge?.[0]?.['$']?.CurrencyCode,
        decimal_places: policy?.CheckoutCharges?.[0]?.CheckoutCharge?.[0]?.['$']?.DecimalPlaces,
        description: policy?.CheckoutCharges?.[0]?.CheckoutCharge?.[0]?.Description?.[0]?.Text?.map(t => ({
          language: t?.['$']?.Language,
          content: t?.['_'],
          text_format: t?.['$']?.TextFormat,
        }))
      },
      pets: {
        maxPetQuantity: policy?.PetsPolicies?.[0]?.PetsPolicy?.[0]?.['$']?.MaxPetQuantity,
        nonRefundableFee: policy?.PetsPolicies?.[0]?.PetsPolicy?.[0]?.['$']?.NonRefundableFee,
        chargeCode: policy?.PetsPolicies?.[0]?.PetsPolicy?.[0]?.['$']?.ChargeCode,
        currency_code: policy?.PetsPolicies?.[0]?.PetsPolicy?.[0]?.['$']?.CurrencyCode,
        decimal_places: policy?.PetsPolicies?.[0]?.PetsPolicy?.[0]?.['$']?.DecimalPlaces,
        description: policy?.PetsPolicies?.[0]?.PetsPolicy?.[0]?.Description?.[0]?.Text?.map(t => ({
          language: t?.['$']?.Language,
          content: t?.['_'],
          text_format: t?.['$']?.TextFormat,
        }))
      },
      tax: {
        chargeFrequency: policy?.TaxPolicies?.[0]?.TaxPolicy?.[0]?.['$']?.ChargeFrequency,
        chargeUnit: policy?.TaxPolicies?.[0]?.TaxPolicy?.[0]?.['$']?.ChargeUnit,
        amount: policy?.TaxPolicies?.[0]?.TaxPolicy?.[0]?.['$']?.Amount,
        currency_code: policy?.TaxPolicies?.[0]?.TaxPolicy?.[0]?.['$']?.CurrencyCode,
        code: policy?.TaxPolicies?.[0]?.TaxPolicy?.[0]?.['$']?.Code,
        description: policy?.TaxPolicies?.[0]?.TaxPolicy?.[0]?.TaxDescription?.[0]?.Text?.map(t => ({
          language: t?.['$']?.Language,
          content: t?.['_'],
          text_format: t?.['$']?.TextFormat,
        }))
      },
      guarantee: {
        guarantees: resolveGuarantees(policy?.GuaranteePaymentPolicy)
      },
      stay_requirement: policy?.StayRequirements?.[0]?.StayRequirement?.map((stayReq) => stayReq?.['$'])
    }
    return obj
  }

  const resolveContacts = (ContactInfos) => {
    return {
      location: ContactInfos?.[0]?.ContactInfo?.[0]?.['$']?.Location,
      address: ContactInfos?.[0]?.ContactInfo?.[0]?.['Addresses']?.[0]?.Address?.map((add) => {
        return {
          language: add?.['$']?.Language,
          AddressLine: add?.['AddressLine']?.[0],
          CityName: add?.['CityName']?.[0],
          PostalCode: add?.['PostalCode']?.[0],
        }
      }),
      urls: ContactInfos?.[0]?.ContactInfo?.[0]?.['URLs']?.[0]?.['URL']?.map((url) => {
        return {
          url: url?.['_'],
          ID: url?.['$']?.['ID']
        }
      }),
    }
  }
  
  const resolveExtensions = () => {
    return {}
  }

  const resolveAffiliation = (AffiliationInfo) => {
    return  {
      awards: AffiliationInfo?.[0]?.Awards?.map((award) => {
        return {
          rating: award?.Award?.[0]?.['$']?.Rating,
          provider: award?.Award?.[0]?.['$']?.Provider,
          officialAppointmentInd: award?.Award?.[0]?.['$']?.OfficialAppointmentInd,
        }
      })
    }
  }


const prepareForDb = async (hotelInfo) => {
    // return hotelInfo
    return hotelInfo.reduce((acc, {HotelInfo, FacilityInfo, Policies, ContactInfos, AffiliationInfo, TPA_Extensions}) => ({
    //   hotelCode: params.options.hotelId,
    //   userId: params.options.userId,
      ...acc,
      hotelCode: hotelInfo?.[0]?.['$']?.HotelCode,
      hotelName: hotelInfo?.[0]?.['$']?.HotelName,
      hotelCityCode: hotelInfo?.[0]?.['$']?.HotelCityCode,
      areaID: hotelInfo?.[0]?.['$']?.AreaID,
      info: resolveHotelInfo(HotelInfo),
      facility: resolveFacilityInfo(FacilityInfo),
      policies: resolvePolicies(Policies),
      contacts: resolveContacts(ContactInfos),
      affiliation: resolveAffiliation(AffiliationInfo),
      ext: resolveExtensions(TPA_Extensions)
    }),{})
}

const resolveCm = async (params, { dataSources, db }) => {

  const [config ] = await Promise.all([
    db.findOne('smts', { user_id: params.userId }),
    // db.findOne('hotelinfo', { userId: params.userId, language: options.language }),
    // db.findOne('token', { userId: params.userId }),
  ])

  const options = {
    language: params.language ? params.language : defaults.language,
    provider: params.provider,
    hotelId: findValueByPath(config, 'alpinebits.hotelid'),
    version: findValueByPath(config, 'alpinebits.version'),
    token: findValueByPath(config, 'alpinebits.token'),
  }

  const { data: xmlHotelInfo, error: hotelInfoError } = await fetchXMLHotelInfo(dataSources, {
    ...params,
    ...params.options,
    ...options
  })
  
  if (hotelInfoError) {
    throw `HotelInfo: ${JSON.stringify(hotelInfoError)}`
  }

  const property = await prepareForDb(xmlHotelInfo);
  
  return {
    params: {
      options: {
        ...options,
        userId: findValueByPath(config, 'user_id'),
        config,
      },
      property
    },
  }
}

const cmResolver = async (_, params, context) => {
  const { cache, ttl } = context
  const { userId, provider, language } = params
  const key = generateCacheKey('cm', params, userId, provider, language)
  const cacheHit = await cache?.get(key)

  if (cacheHit) {
    return JSON.parse(cacheHit)
  } else {
    const cacheableValue = await resolveCm(params, context)
    cache?.setEx(key, ttl, JSON.stringify(cacheableValue))
    return cacheableValue
  }
}

module.exports = cmResolver
