const fetchToken = require('./fetchers/fetchToken')
const fetchProperty = require('./fetchers/fetchProperty')
const fetchXMLRates = require('./fetchers/fetchXMLRates')
const fetchXMLHotelInfo = require('./fetchers/fetchXMLHotelInfo')
const fetchOffersOverview = require('./fetchers/fetchOffersOverview')
const fetchRatesAverage = require('./fetchers/fetchRatesAverage')
const fetchBookability = require('./fetchers/fetchBookability')
const fetchServices = require('./fetchers/fetchJSONServices')
const fetchXMLServices = require('./fetchers/fetchXMLServices')
const fetchXMLBookings = require('./fetchers/fetchXMLBookings')
const fetchOffers = require('./fetchers/fetchOffers')

module.exports = {
  fetchToken,
  fetchProperty,
  fetchXMLRates,
  fetchXMLHotelInfo,
  fetchOffersOverview,
  fetchRatesAverage,
  fetchBookability,
  fetchServices,
  fetchXMLServices,
  fetchXMLBookings,
  fetchOffers,
}
