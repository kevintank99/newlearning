const attr = (paramName, paramValue) => paramValue ? ` ${paramName}="${paramValue}"` : ''

//read bookings / single or list
const readBookingsXML = (params) => `<ota:OTA_ReadRQ xmlns:ota="http://www.opentravel.org/OTA/2003/05" Version="1.01" MaxResponses="100">
<ota:POS>
<ota:Source TerminalID="46.4.4.204">
<ota:RequestorID URL="mailto:${params.apiUser}" ID="N/A" Type="10" MessagePassword="${params.apiToken}"/>
  <ota:BookingChannel Type="7">
    <ota:CompanyName Code="MTS"/>
  </ota:BookingChannel>
</ota:Source>
</ota:POS>
${params.reservationId ? `<ota:UniqueID Type="14" ID="${params.reservationId}"/>` : ''}
<ota:ReadRequests>
<ota:HotelReadRequest HotelCode="${params.hotelId}">
${params.startDate || params.endDate ? `<ota:SelectionCriteria DateType="LastUpdateDate"${attr('Start', params.startDate)}${attr('End', params.endDate)} />` : ''}
</ota:HotelReadRequest>
</ota:ReadRequests>
</ota:OTA_ReadRQ>`

const readServicesXML = (params) => `<seekda:ServiceReadRQ xmlns:ota="http://www.opentravel.org/OTA/2003/05"
  xmlns:seekda="http://connect.seekda.com/2009/04" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
  xsi:schemaLocation="http://connect.seekda.com/2009/04 ../../IBE/OTA2008A/seekda_ProprietaryExtensions.xsd">
  <ota:POS>
    <ota:Source TerminalID="46.4.4.204">
      <ota:RequestorID ID="n/a" Type="1" URL="mailto:${params.apiUser}" MessagePassword="${params.apiToken}"></ota:RequestorID>
      <ota:BookingChannel Type="7">
        <ota:CompanyName Code="MTS"/>
      </ota:BookingChannel>
    </ota:Source>
  </ota:POS>
  <seekda:ServiceReadRequests>
    <seekda:ServiceReadRequest seekda:HotelCode="${params.hotelId}"${attr('seekda:ServiceCode', params.code)}${attr('seekda:Start', params.start)}${attr('seekda:End', params.end)} />
  </seekda:ServiceReadRequests>
</seekda:ServiceReadRQ>`

const readRatesXML = (params) => `<ota:OTA_HotelRatePlanRQ xmlns:ota="http://www.opentravel.org/OTA/2003/05" xmlns="http://www.opentravel.org/OTA/2009/04" xmlns:seekda="http://connect.seekda.com/2009/04">
<ota:POS>
  <ota:Source TerminalID="46.4.4.204">
    <ota:RequestorID URL="mailto:${params.apiUser}" ID="N/A" Type="10" MessagePassword="${params.apiToken}"/>
    <ota:BookingChannel Type="7">
      <ota:CompanyName Code="IBE"/>
    </ota:BookingChannel>
    <ota:TPA_Extensions>
      <seekda:RatePlanParameters seekda:IncludeAvailabilities="true" seekda:ShowLOSSettings="true" />
    </ota:TPA_Extensions>
  </ota:Source>
</ota:POS>
<ota:RatePlans>
    <ota:RatePlan>
        <ota:DateRange Start="${params.startDate}" End="${params.endDate}" />
        <ota:RatePlanCandidates>
            <ota:RatePlanCandidate RatePlanType="5" />
            <ota:RatePlanCandidate RatePlanType="11" />
            <ota:RatePlanCandidate RatePlanType="511" />
        </ota:RatePlanCandidates>
        <ota:HotelRef HotelCode="${params.hotelId}" />
    </ota:RatePlan>
</ota:RatePlans>
</ota:OTA_HotelRatePlanRQ>
`

module.exports = {
  readBookingsXML,
  readServicesXML,
  readRatesXML
}