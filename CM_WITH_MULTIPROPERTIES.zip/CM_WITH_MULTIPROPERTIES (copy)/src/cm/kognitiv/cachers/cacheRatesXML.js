const { fetchXMLRates } = require('../fetchers')
const { ratePlanTypes, defaults } = require('../constants')
const { isArray, isObject, isStringValue, isValue } = require('../../../utils/type')
const { isPositiveNumber } = require('../../../utils/number')
const {
  dateToday,
  dateAddDays,
  dateFrom,
  dateDiffDays,
  dateIsoFormat,
  dateDiffDaysAfterTimeRange,
} = require('../../../utils/date')

const setOptions = (params) => {
  let options = {}
  options.startDate = isStringValue(params.start)
    ? dateFrom(params.start)
    : dateFrom(params.config.startDate || dateToday())
  options.numberOfDays = isPositiveNumber(params.length)
    ? params.length
    : params?.config?.timerange
    ? dateDiffDaysAfterTimeRange(params.config.timerange)
    : defaults.numberOfDays
  options.endDate = dateAddDays(options.numberOfDays, dateToday())
  options.skipRateAccessCodes = isArray(params.config.skiprateaccess) ? params.config.skiprateaccess : []
  options.promotionCodes = isObject(params.config.promotioncodes) ? params.config.promotioncodes : {}
  options.skipRatePlanCodes = isArray(params.config.skiprateplans) ? params.config.skiprateplans : []
  return options
}

const resolveBaseByGuestAmt = (BaseByGuestAmt) => {
  return BaseByGuestAmt.reduce(
    (acc, { $: { NumberOfGuests, AmountAfterTax } }) => {
      NumberOfGuests && (acc.adults[parseInt(NumberOfGuests)] = parseFloat(AmountAfterTax))
      return acc
    },
    { adults: {} },
  )
}

const resolveAdditionalGuestAmount = (AdditionalGuestAmount, Rate) => {
  let fromAge = 0,
    toAge = 0

  AdditionalGuestAmount.sort((current, next) =>
    parseInt(current['$'].AgeQualifyingCode) > parseInt(next['$'].AgeQualifyingCode) ? 1 : -1,
  )

  return AdditionalGuestAmount.reduce((acc, { $: { AgeQualifyingCode, Amount } }) => {
    if (!AgeQualifyingCode || AgeQualifyingCode === '10') {
      acc.adults.additional = parseFloat(Amount)
    } else {
      isObject(acc.children) || (acc.children = {})
      toAge = AgeQualifyingCode - 100
      acc.children[`${fromAge} - ${toAge}`] = parseFloat(Amount) //attention it IS POSSIBLE the age ranges do not correspond to the childAges - PMS has different settings than Kognitiv
      fromAge = toAge + 1
    }
    return acc
  }, Rate)
}

const resolveXMLRate = (RatePlanCode, RatePlanType, XMLRate, Rates, options, promotionCode) => {
  return XMLRate.reduce((acc, { $, AdditionalGuestAmounts, BaseByGuestAmts }) => {
    if (!BaseByGuestAmts || !$) {
      return acc //Rate node without guest amounts only contains restrictionstatus or mealplan, ignore
    }
    let {
      InvTypeCode,
      Start,
      End,
      MinLOS: minstay = '1',
      DynamicMinLOS: dynamicminstay = '-',
      MinLOSThru: minstaythrough = '-',
      MaxLOS: maxstay = '-',
      MaxLOSThru: maxstaythrough = '-',
      AvailableRooms: availability,
    } = $
    isObject(acc[InvTypeCode]) || (acc[InvTypeCode] = {})
    isObject(acc[InvTypeCode][RatePlanCode]) || (acc[InvTypeCode][RatePlanCode] = {})
    if (promotionCode) {
      acc[InvTypeCode][RatePlanCode]['promotionCode'] = promotionCode
    }
    if (RatePlanType == ratePlanTypes.FIXED_RATE_OFFERS) {
      isArray(acc[InvTypeCode][RatePlanCode]['availableOnly']) || (acc[InvTypeCode][RatePlanCode]['availableOnly'] = [])
      acc[InvTypeCode][RatePlanCode]['availableOnly'].push({
        Start,
        End,
      })
    }
    acc[InvTypeCode][RatePlanCode]['ratePlanType'] = RatePlanType
    isArray(acc[InvTypeCode][RatePlanCode]['dayRates']) ||
      (acc[InvTypeCode][RatePlanCode]['dayRates'] = Array(options.numberOfDays).fill(null))
    let dailyRate = isArray(AdditionalGuestAmounts)
      ? resolveAdditionalGuestAmount(
          AdditionalGuestAmounts[0].AdditionalGuestAmount,
          resolveBaseByGuestAmt(BaseByGuestAmts[0].BaseByGuestAmt),
        )
      : resolveBaseByGuestAmt(BaseByGuestAmts[0].BaseByGuestAmt)
    let dayStartIndex = dateDiffDays(options.startDate, dateFrom(Start))
    let dayEndIndex = dateDiffDays(options.startDate, dateFrom(End))
    let day = Math.max(0, dayStartIndex) - 1 //skip all days in the past
    let dayDate
    while (++day <= dayEndIndex) {
      dayDate = dateIsoFormat(dateAddDays(day, options.startDate))
      acc[InvTypeCode][RatePlanCode]['dayRates'][day] = {
        day: dayDate,
        ...dailyRate,
        minstay,
        dynamicminstay,
        minstaythrough,
        maxstay,
        maxstaythrough,
        availability,
      }
    }
    return acc
  }, Rates)
}

const resolveAdjustGuestAmount = (AdditionalGuestAmount) => {
  let fromAge = 0,
    toAge = 0

  AdditionalGuestAmount.sort((current, next) =>
    parseInt(current['$'].AgeQualifyingCode) > parseInt(next['$'].AgeQualifyingCode) ? 1 : -1,
  )

  return AdditionalGuestAmount.reduce((acc, { $: { AgeQualifyingCode, Amount } }) => {
    if (!AgeQualifyingCode || AgeQualifyingCode === '10') {
      acc.adults = parseFloat(Amount) //adjusted (added) amount for adult only, applies to adults and additional guest
    } else {
      isObject(acc.children) || (acc.children = {})
      toAge = AgeQualifyingCode - 100
      acc.children[`${fromAge} - ${toAge}`] = parseFloat(Amount) //adjusted (added) amount for children only, depending on age
      fromAge = toAge + 1
    }
    return acc
  }, {})
}

const adjustDailyRates = (
  dailyRates,
  ratePeriods,
  supplement,
  discount,
  options,
  InvTypeCode,
  RatePlanCode,
  isExtendable,
  minStayPerWeekDay,
  maxStayPerWeekDay,
) => {
  let adjustedRates = Array(options.numberOfDays).fill(null)
  ratePeriods.map(({ Start, End }) => {
    let dayStartIndex = dateDiffDays(options.startDate, dateFrom(Start))
    let dayEndIndex = dateDiffDays(options.startDate, dateFrom(End))
    let day = Math.max(0, dayStartIndex) - 1
    let dayDate
    while (++day <= dayEndIndex) {
      dayDate = dateIsoFormat(dateAddDays(day, options.startDate))
      const minstay = minStayPerWeekDay[dateFrom(dayDate).getDay()] || null
      const maxstay = isExtendable ? maxStayPerWeekDay[dateFrom(dayDate).getDay()] || null : minstay
      isObject(dailyRates[day]) &&
        (adjustedRates[day] = adjustDailyRateAndAvailability(
          dailyRates[day],
          supplement,
          discount,
          dayDate,
          minstay,
          maxstay,
        ))
    }
  })
  return adjustedRates
}

const adjustDailyRateAndAvailability = (dailyRate, supplement, discount, Day, minstay, maxstay) => {
  const rate = { day: Day }

  //Don't add global supplement in additional guests and child ages,
  //as it is anyways going to be calculated while doing total based on required occupancy
  if (discount || supplement.global || supplement.adults) {
    rate.adults = {}
    for (let guests in dailyRate.adults) {
      if (guests === 'additional') {
        rate.adults[guests] = +(
          dailyRate.adults[guests] -
          (dailyRate.adults[guests] * discount) / 100 +
          (supplement.adults ?? 0)
        ).toFixed(2)
      } else {
        rate.adults[guests] = +(
          dailyRate.adults[guests] -
          (dailyRate.adults[guests] * discount) / 100 +
          supplement.global +
          (supplement.adults ?? 0) * parseInt(guests)
        ).toFixed(2)
      }
    }
  } else {
    //Added condition because there could be possibility of no adjustment in amount of adults price in that case we will continue with existing rateplan price
    rate.adults = {}
    for (let guests in dailyRate.adults) {
      rate.adults[guests] = dailyRate.adults[guests]
    }
  }

  if (dailyRate.children && (discount || supplement.global || supplement.children)) {
    rate.children = {}
    for (let age in dailyRate.children) {
      rate.children[age] = +(
        dailyRate.children[age] -
        (dailyRate.children[age] * discount) / 100 +
        (supplement.children && supplement.children[age] ? supplement.children[age] : 0)
      ).toFixed(2)
    }
  }

  rate.availability = dailyRate.availability
  rate.minstay = minstay || '-'
  rate.maxstay = maxstay || '-'
  return rate
}

const resolveXMLDailyBasedRate = (RatePlanCode, XMLRate, XMLBookingRules, dailyRates, Rates, options, RatePlanType) => {
  const ratePeriods = resolveXMLBookingRules(XMLBookingRules, options)
  const ratePlanAdjust = resolveXMLRatePlanAdjust(XMLRate, options)
  const disallowExtendingPackage = XMLBookingRules?.find(({ $ }) => $ && 'DisallowExtendingPackage' in $)
  return ratePlanAdjust.reduce(
    (acc, { InvTypeCode, BaseRatePlanCode, supplement, discount, minStayPerWeekDay, maxStayPerWeekDay }) => {
      if (!isArray(dailyRates?.[InvTypeCode]?.[BaseRatePlanCode]?.['dayRates'])) {
        return acc
      }
      isObject(acc[InvTypeCode]) || (acc[InvTypeCode] = {})
      isObject(acc[InvTypeCode][RatePlanCode]) || (acc[InvTypeCode][RatePlanCode] = {})
      acc[InvTypeCode][RatePlanCode]['availableOnly'] = ratePeriods
      acc[InvTypeCode][RatePlanCode]['ratePlanType'] = RatePlanType
      acc[InvTypeCode][RatePlanCode]['baseRateCode'] = BaseRatePlanCode
      acc[InvTypeCode][RatePlanCode]['isExtendable'] =
        disallowExtendingPackage?.$?.DisallowExtendingPackage === 'true' ? false : true
      isArray(acc[InvTypeCode][RatePlanCode]['dayRates']) ||
        (acc[InvTypeCode][RatePlanCode]['dayRates'] = Array(options.numberOfDays).fill(null))
      acc[InvTypeCode][RatePlanCode]['dayRates'] = adjustDailyRates(
        dailyRates[InvTypeCode][BaseRatePlanCode]['dayRates'],
        ratePeriods,
        supplement,
        discount,
        options,
        InvTypeCode,
        RatePlanCode,
        acc[InvTypeCode][RatePlanCode]['isExtendable'],
        minStayPerWeekDay,
        maxStayPerWeekDay,
      )
      return acc
    },
    Rates,
  )
}

/**
 * Get the dates a daily based offer is valid
 * @param {Object} XMLBookingRules
 * @param {Object} options
 */
const resolveXMLBookingRules = (XMLBookingRules, options) => {
  //first search for bookingrules, dates in which the offer and thus the adjusting is valid
  let bookingRules =
    XMLBookingRules?.reduce((acc, { $ }) => {
      $ && $.Start && $.End && dateFrom($.End) >= options.startDate && acc.push($)
      return acc
    }, []) || []
  //with no bookingrules in place, offer is valid for the whole period
  if (isArray(XMLBookingRules) && !XMLBookingRules.some(({ $ }) => $ && 'Start' in $)) {
    bookingRules.push({ Start: dateIsoFormat(options.startDate), End: dateIsoFormat(options.endDate) })
  }
  return bookingRules
}

const resolveXMLRatePlanAdjust = (XMLRate, options) => {
  return XMLRate.reduce((acc, { $, AdditionalGuestAmounts }) => {
    if (!$ || skipRatePlan(null, $.BaseRatePlanCode, null, options)) {
      //no attributes on rate node / invtypecode missing: contains GuaranteePolicies, CancelPolicies etc. OR the duration - no adjust information, or BaseRatePlan is in config skiprateplans
      return acc
    }

    let {
      InvTypeCode,
      BaseRatePlanCode,
      AdjustedAmount,
      AdjustedPercentage,
      Mon,
      Tue,
      Weds,
      Thur,
      Fri,
      Sat,
      Sun,
      Duration,
      MaxDuration,
    } = $
    AdjustedAmount = isStringValue(AdjustedAmount) ? parseFloat(AdjustedAmount) : 0
    AdjustedPercentage = isStringValue(AdjustedPercentage) ? parseFloat(AdjustedPercentage) : 0
    if (InvTypeCode) {
      acc.push({
        InvTypeCode,
        BaseRatePlanCode,
        supplement: {
          global: AdjustedAmount, //global adjusted amount; adds to children, adults and additional
          ...(AdditionalGuestAmounts ? resolveAdjustGuestAmount(AdditionalGuestAmounts[0].AdditionalGuestAmount) : {}),
        },
        discount: AdjustedPercentage, //global adjusted percentage; detracts from children, adults and additional
      })
    } else {
      acc.forEach((ele) => {
        ele.minStayPerWeekDay = {
          ...ele.minStayPerWeekDay,
          ...(Sun ? { 0: Duration?.match(/[0-9]+/g)?.[0] } : {}),
          ...(Mon ? { 1: Duration?.match(/[0-9]+/g)?.[0] } : {}),
          ...(Tue ? { 2: Duration?.match(/[0-9]+/g)?.[0] } : {}),
          ...(Weds ? { 3: Duration?.match(/[0-9]+/g)?.[0] } : {}),
          ...(Thur ? { 4: Duration?.match(/[0-9]+/g)?.[0] } : {}),
          ...(Fri ? { 5: Duration?.match(/[0-9]+/g)?.[0] } : {}),
          ...(Sat ? { 6: Duration?.match(/[0-9]+/g)?.[0] } : {}),
        }
        ele.maxStayPerWeekDay = {
          ...ele.maxStayPerWeekDay,
          ...(Sun ? { 0: MaxDuration?.match(/[0-9]+/g)?.[0] } : {}),
          ...(Mon ? { 1: MaxDuration?.match(/[0-9]+/g)?.[0] } : {}),
          ...(Tue ? { 2: MaxDuration?.match(/[0-9]+/g)?.[0] } : {}),
          ...(Weds ? { 3: MaxDuration?.match(/[0-9]+/g)?.[0] } : {}),
          ...(Thur ? { 4: MaxDuration?.match(/[0-9]+/g)?.[0] } : {}),
          ...(Fri ? { 5: MaxDuration?.match(/[0-9]+/g)?.[0] } : {}),
          ...(Sat ? { 6: MaxDuration?.match(/[0-9]+/g)?.[0] } : {}),
        }
      })
    }
    return acc
  }, [])
}

const skipRatePlan = (RateAccessCode, RatePlanCode, RatePlanClosed, options) => {
  return (
    (RateAccessCode &&
      options.skipRateAccessCodes?.indexOf(RateAccessCode) > -1 &&
      !options.promotionCodes?.[RateAccessCode]) || //skip RatePlan by RateAccessCode
    (RatePlanCode && options.skipRatePlanCodes?.indexOf(RatePlanCode) > -1) || //skip RatePlan by Code
    (RatePlanClosed ?? 'false') === 'true'
  ) //RatePlan marked as "closed"
}

const resolveXMLRatePlan = (XMLRatePlan, options) => {
  //first retrieve the already calculated rates: daily rates and fixed rate offers
  const dailyRates = XMLRatePlan?.reduce(
    (acc, { $: { RatePlanCode, RatePlanType, RatePlanClosed, RateAccessCode } = {}, Rates } = {}) => {
      if (
        (RatePlanType == ratePlanTypes.ROOMS_DAILY || RatePlanType == ratePlanTypes.FIXED_RATE_OFFERS) &&
        !skipRatePlan(RateAccessCode, RatePlanCode, RatePlanClosed, options)
      ) {
        acc = resolveXMLRate(
          RatePlanCode,
          RatePlanType,
          Rates[0].Rate,
          acc,
          options,
          options.promotionCodes[RateAccessCode],
        )
      }
      return acc
    },
    {},
  )

  //then calculate the daily rates based offers by adjusting the daily rates
  return XMLRatePlan?.reduce(
    (acc, { $: { RatePlanCode, RatePlanType, RatePlanClosed, RateAccessCode } = {}, BookingRules, Rates } = {}) => {
      if (
        RatePlanType == ratePlanTypes.DAILY_BASED_OFFERS &&
        !skipRatePlan(RateAccessCode, RatePlanCode, RatePlanClosed, options)
      ) {
        acc = resolveXMLDailyBasedRate(
          RatePlanCode,
          Rates[0].Rate,
          BookingRules?.[0]?.BookingRule,
          dailyRates,
          acc,
          options,
          RatePlanType,
        )
      }
      return acc
    },
    dailyRates,
  )
}

const prepareForDb = async (dataSources, { token, ...params }, db) => {
  const options = setOptions({ ...params, ...params.options })
  const { data: xmlRates, error: ratesError } = await fetchXMLRates(dataSources, {
    ...params,
    ...params.options,
    ...options,
    accessToken: token,
  })
  if (ratesError) {
    throw `Error in fetching RatesXML API`
  }
  const rates = resolveXMLRatePlan(xmlRates[0].RatePlan, options)
  return Object.entries(rates).reduce((acc, [roomCode, ratesOfRoom]) => {
    acc.push({
      hotelCode: params.options.hotelId,
      userId: params.options.userId,
      roomCode,
      lastUpdated: Date.now(),
      rates: ratesOfRoom,
    })
    return acc
  }, [])
}

const cacheResponse = async ({ dataSources, db }, params) => {
  const logs = {
    success: false,
    error: false,
    message: null,
    reason: null,
  }
  try {
    //fetch and resolve data
    const rates = await prepareForDb(dataSources, params, db)
    if (isValue(rates)) {
      //clear stale data
      await db.delete('ratesXML', { userId: params.options.userId })
      //revalidate cache in db
      for (let ratesOfRoom of rates) {
        await db.insertOne('ratesXML', ratesOfRoom)
      }
      //logs
      logs.success = true
      logs.message = `RatesXML API cached successfully for ${params.options.hotelId}`
    } else {
      logs.error = true
      logs.message = "no data found for RatesXML API"
    }
  } catch (e) {
    logs.error = true
    logs.message = `Error in caching RatesXML API for ${params.options.hotelId}`
    logs.reason = e.message || e
  }
  return logs
}

const cacheRatesXML = async (parent, params, context, info) => {
  return cacheResponse(context, { ...parent.params, ...params })
}

module.exports = cacheRatesXML
