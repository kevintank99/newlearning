const { fetchOffersOverview } = require('../fetchers')
const {isValue} = require('../../../utils/type');
const cacheResponse = async ({ dataSources, db }, params) => {
  const { languages } = params?.options
  const logs = {
    success: false,
    error: false,
    message: null,
    reason: null,
  }

  try {
    //fetch and resolve data
    const cache = await Promise.all(
      languages.map((language) =>
        fetchOffersOverview(dataSources, { ...params.options, language, accessToken: params.token }),
      ),
    )
    if (cache.some(({ error }) => error)) {
      throw 'Error in fetching OffersOverviewJSON API'
    }
    if (isValue(cache)) {
      //clear stale data
      await db.delete('offersoverview', { userId: params.options.userId })
      //revalidate cache in db
      for (let { data } of cache) {
        await db.insertOne('offersoverview', data)
      }
      //logs
      logs.success = true
      logs.message = `OffersOverviewJSON API cached successfully for ${params.options.hotelId}`
    } else {
      logs.error = true
      logs.message = "no data found forOffersOverviewJSON API"
    }
  } catch (e) {
    logs.error = true
    logs.message = `Error in caching OffersOverviewJSON API for ${params.options.hotelId}`
    logs.reason = e.message || e
  }
  return logs
}

const cacheOffersOverviewJSON = async (parent, params, context, info) => {
  return cacheResponse(context, { ...parent.params, ...params })
}

module.exports = cacheOffersOverviewJSON
