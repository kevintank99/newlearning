const { fetchXMLServices } = require('../fetchers')
const path = require('path')
const { dateToday, dateFrom, dateAddDays, dateIsoFormat, dateDiffDays } = require('../../../utils/date')
const {isValue} = require('../../../utils/type');
const resolveVideoItems = (videoItems) => {
  return videoItems?.[0]?.VideoItem.reduce((acc, { VideoFormat }) => {
    let url = VideoFormat?.[0]?.URL?.[0]
    acc.push({
      url,
      fileName: url ? path.basename(url) : null,
    })
    return acc
  }, new Array())
}

const resolveImageItems = (imageItems) => {
  return imageItems?.[0]?.ImageItem.reduce((acc, { ImageFormat }) => {
    let url = ImageFormat?.[0]?.URL?.[0]
    acc.push({
      url,
      fileName: url ? path.basename(url) : null,
    })
    return acc
  }, new Array())
}

/**
 * Resolve a XML structured description node (part of textItem) to flat text set in options.language
 * @param {object} description
 * @param {object} options
 */
const resolveDescription = (description) => {
  return description
    ? description.reduce((acc, { _, $ }) => {
        return {
          ...acc,
          [$.Language.toLowerCase()]: _,
        }
      }, {})
    : {}
}

/**
 * Resolve a XML structured text item into a flat object respecting options.language
 * @param {object} textItem
 * @param {object} options
 */
const resolveTextItem = (textItem) =>
  textItem?.reduce((acc, { $, Description }) => {
    return {
      ...acc,
      [$.Title.toLowerCase()]: resolveDescription(Description),
    }
  }, {})

const resolveMultiMediaDescriptions = (multimediaDescription) =>
  multimediaDescription?.reduce((acc, { TextItems, ImageItems, VideoItems }) => {
    if (TextItems) {
      acc = {
        ...acc,
        ...resolveTextItem(TextItems?.[0]?.TextItem),
      }
    } else if (ImageItems) {
      acc = {
        ...acc,
        images: resolveImageItems(ImageItems),
      }
    } else if (VideoItems) {
      acc = {
        ...acc,
        videos: resolveVideoItems(VideoItems),
      }
    }
    return acc
  }, {})

/**
 * Creates availability strings of services
 * @param {array} ServiceRate
 * @returns {object}
 */
const resolveAvailabilityOfServices = (ServiceRate) => {
  const minlos = Array(365).fill(null)
  const maxlos = Array(365).fill(null)
  const prices = Array(365).fill(null)
  const dates = []

  const dateToAvailabilityMap = ServiceRate?.reduce((acc, { $, BaseByGuestAmts }) => {
    const startDate = $?.Start ? dateFrom($.Start) : dateToday()
    const endDate = $?.End ? dateAddDays(1, dateFrom($.End)) : dateAddDays(365, dateToday())

    dates.push({
      start: dateIsoFormat(startDate),
      end: dateIsoFormat($?.End ? dateFrom($.End) : dateAddDays(365, dateToday())),
    })

    for (startDate; startDate < endDate; startDate.setDate(startDate.getDate() + 1)) {
      acc[dateIsoFormat(startDate)] = {
        minlos: $?.MinLOS || 1,
        maxlos: $?.MaxLOS || dateDiffDays(startDate, endDate),
        price: parseFloat(BaseByGuestAmts?.[0]?.BaseByGuestAmt?.[0]?.$?.AmountAfterTax),
      }
    }
    return acc
  }, {})

  for (let i = 0, dt = dateToday(); i < 365; i++, dt.setDate(dt.getDate() + 1)) {
    const dateKey = dateIsoFormat(dateFrom(dt))
    if (dateToAvailabilityMap?.[dateKey]) {
      minlos[i] = dateToAvailabilityMap[dateKey]['minlos']
      maxlos[i] = dateToAvailabilityMap[dateKey]['maxlos']
      prices[i] = dateToAvailabilityMap[dateKey]['price']
    } else {
      minlos[i] = 0
      maxlos[i] = 0
      prices[i] = 0
    }
  }

  return {
    availability: {
      minlos: minlos.join('|'),
      maxlos: maxlos.join('|'),
      prices: prices.join('|'),
      dates,
    },
  }
}

/**
 * Resolve Services from XML
 * @param {object} XMLServices
 * @param {object} options
 */
const resolveXMLServices = (XMLServices) => {
  const services = XMLServices
    ? XMLServices?.[0]?.Service?.reduce((acc, { $, MultimediaDescriptions, ServiceConstraints, ServiceRates }) => {
        let categories = $?.Category ? $.Category.split(',') : []
        const { availability } = resolveAvailabilityOfServices(ServiceRates?.[0]?.ServiceRate)
        if (availability.minlos.split('|').every((ele) => ele === '0')) {
          return acc
        }
        acc.push({
          code: $?.ServiceCode,
          auto_add: $?.AutoAdd,
          eu_package: $?.EUPackage,
          enabled: $?.Enabled,
          prepayment_type: $?.PrepaymentType,
          cancellation_refund_type: $?.CancellationRefundType,
          sort: parseInt($?.Sort),
          net_rate: $?.NetRate,
          currency_code: $?.CurrencyCode,
          ...resolveMultiMediaDescriptions(MultimediaDescriptions?.[0]?.MultimediaDescription),
          global_limit_per_booking: ServiceConstraints?.[0]?.Availability[0]?.$?.GlobalLimitPerBooking,
          upon_request: ServiceConstraints?.[0]?.Availability?.[0]?.$?.UponRequest,
          category_codes: categories,
          category_code: $?.Category,
          tax_group_code: $?.TaxGroupCode,
          price_base: ServiceRates?.[0]?.$?.PriceBase,
          limit_type: ServiceRates?.[0]?.$?.LimitType,
          availability,
        })
        return acc
      }, new Array())
    : {}
  return services
}

const prepareForDb = async (dataSources, { token, ...params }) => {
  const { data: xmlServices, error: servicesError } = await fetchXMLServices(dataSources, {
    ...params,
    ...params.options,
    accessToken: token,
  })
  if (servicesError) throw `Error in fetching ServicesXML API`
  return {
    hotelCode: params.options.hotelId,
    userId: params.options.userId,
    services: resolveXMLServices(xmlServices),
  }
}

const cacheResponse = async ({ dataSources, db }, params) => {
  const logs = {
    success: false,
    error: false,
    message: null,
    reason: null,
  }
  try {
    //fetch and resolve data
    const cache = await prepareForDb(dataSources, params)
    if (isValue(cache)) {
      //clear stale data
      await db.delete('servicesXML', { userId: params.options.userId })
      //revalidate cache in db
      await db.insertOne('servicesXML', cache)
      //logs
      logs.success = true
      logs.message = `ServicesXML API cached successfully for ${params.options.hotelId}`
    } else {
      logs.error = true
      logs.message = "no data found for ServicesXML API"
    }
  } catch (e) {
    logs.error = true
    logs.message = `Error in caching ServicesXML API for ${params.options.hotelId}`
    logs.reason = e.message || e
  }
  return logs
}

const cacheServicesXML = async (parent, params, context, info) => {
  return cacheResponse(context, { ...parent.params, ...params })
}

module.exports = cacheServicesXML
