const { fetchToken } = require('../fetchers')
const { findValueByPath } = require('../../../utils/object')
const { isObject } = require('../../../utils/type')
const { isArray } = require('../../../utils/type')
const { defaults } = require('../constants')

const cacheCm = async (_source, params, { dataSources, db }) => {
  const configJSON = await db.findOne('smts', { user_id: params.userId })

  const options = {
    ...params,
    config: isObject(configJSON) && configJSON,
    language: params.language ? params.language : defaults.language,
    hotelId: findValueByPath(configJSON, 'seekda.hotelid'),
    userId: findValueByPath(configJSON, 'user_id'),
    apiKey: findValueByPath(configJSON, 'seekda.apikey'),
    apiUser: findValueByPath(configJSON, 'seekda.user') || defaults.apiUser, //default api user is info@mts-italia.it, can only be changed in the protected user config
    apiToken: findValueByPath(configJSON, 'seekda.token') || defaults.apiToken, //default api password for accessing data
    languages: isArray(params.languages)
      ? params.languages
      : findValueByPath(configJSON, 'languages') || defaults.cacheLanguages,
  }

  // Fetch data from the datasource (fetch token) - needed for nearly all the requests
  const { data: token, error: tokenError } = await fetchToken(dataSources, options)

  tokenError && console.log(`Token: ${tokenError}`)
  if(token) {
    //clear stale data
    await db.delete('token', { userId: options.userId })
    //revalidate cache in db
    await db.insertOne('token', { hotelCode: options.hotelId, userId: options.userId, token })
  }

  return {
    params: {
      options,
      token,
    },
  }
}

module.exports = cacheCm
