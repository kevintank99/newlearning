const { fetchRatesAverage } = require('../fetchers')
const {isValue} = require('../../../utils/type');
const cacheResponse = async ({ dataSources, db }, params) => {
  const { languages } = params?.options
  const logs = {
    success: false,
    error: false,
    message: null,
    reason: null,
  }

  try {
    //fetch data
    const cache = await Promise.all(
      languages.map((language) =>
        fetchRatesAverage(dataSources, { ...params.options, packages: true, language, accessToken: params.token }),
      ),
    )
    if (cache.some(({ error }) => error)) {
      throw 'Error in fetching RatesAverageJSON API'
    }
    if (isValue(cache)) {
      //clear stale data
      await db.delete('ratesaverage', { userId: params.options.userId })
      //revalidate cache in db
      for (let { data } of cache) {
        await db.insertOne('ratesaverage', data)
      }
      //logs
      logs.success = true
      logs.message = `RatesAverageJSON API cached successfully for ${params.options.hotelId}`
    } else {
      logs.error = true
      logs.message = "no data found RatesAverageJSON API"
    }
  } catch (e) {
    logs.error = true
    logs.message = `Error in caching RatesAverageJSON API for ${params.options.hotelId}`
    logs.reason = e.message || e
  }
  return logs
}

const cacheRatesAverageJSON = async (parent, params, context, info) => {
  return cacheResponse(context, { ...parent.params, ...params })
}

module.exports = cacheRatesAverageJSON
