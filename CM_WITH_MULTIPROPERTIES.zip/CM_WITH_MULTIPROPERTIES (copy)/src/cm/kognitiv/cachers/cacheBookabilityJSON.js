const { fetchBookability } = require('../fetchers')
const {isValue} = require('../../../utils/type');
const cacheResponse = async ({ dataSources, db }, params) => {
  const logs = {
    success: false,
    error: false,
    message: null,
    reason: null,
  }
  try {
    //fetch data
    const { data: bookability, error: errorBookability } = await fetchBookability(dataSources, {
      ...params.options,
      ...params,
      accessToken: params.token,
    })
    if (errorBookability) {
      throw "Error in fetching BookabilityJSON API"
    }
    if (isValue(bookability)) {
      //clear stale data
      await db.delete('bookability', { userId: params.options.userId })
      //revalidate cache in db
      await db.insertOne('bookability', bookability)
      //logs
      logs.success = true
      logs.message = `BookabilityJSON API cached successfully for ${params.options.hotelId}`
    } else {
      logs.error = true
      logs.message = "no data found for BookabilityJSON API"
    }
  } catch (e) {
    logs.error = true
    logs.message = `Error in caching BookabilityJSON API for ${params.options.hotelId}`
    logs.reason = e.message || e
  }

  return logs
}

const cacheBookabilityJSON = async (parent, params, context, info) => {
  return cacheResponse(context, { ...parent.params, ...params })
}

module.exports = cacheBookabilityJSON
