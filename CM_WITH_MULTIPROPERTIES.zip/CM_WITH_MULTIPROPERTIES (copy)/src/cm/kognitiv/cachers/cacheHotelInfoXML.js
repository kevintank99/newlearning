const { fetchXMLHotelInfo } = require('../fetchers')
const {isValue} = require('../../../utils/type');
const resolveDescriptionTextItems = (description) =>
  description?.Text?.map((t) => ({
    language: t?.['$']?.Language,
    content: t?.['$']?.['_'],
  }))

/**
 * Resolves video items such as languages, formats, etc
 * @param {array} videoItems
 * @returns array
 */
const resolveVideoItems = (videoItems) =>
  videoItems?.[0]?.VideoItem?.map(({ $, VideoFormat, Description }) => {
    return {
      category: $?.Category,
      language: $?.Language,
      caption: $?.Caption,
      version: $?.Version,
      descriptions: Description?.map((d) => ({
        language: d?.['$']?.Language,
        caption: d?.['$']?.Caption,
        content: d?.['_'],
        texts: resolveDescriptionTextItems(d), //To-Do: Haven't got any example value here
      })),
      formats: VideoFormat?.map((v) => ({
        url: v?.URL?.[0],
      })),
    }
  })

/**
 * Resolves image items such as height, width, format, etc
 * @param {array} imageItems
 * @returns array
 */
const resolveImageItems = (imageItems) =>
  imageItems?.[0]?.ImageItem?.map(({ $, ImageFormat, Description }) => {
    return {
      category: $.Category,
      image_formats: ImageFormat?.map((image) => ({
        height: image?.['$']?.Height,
        width: image?.['$']?.Width,
        format: image?.['$']?.Format,
        title: image?.['$']?.Title,
        file_size: image?.['$']?.FileSize,
        url: image?.URL,
      })),
      descriptions: Description?.map((d) => ({
        language: d?.['$']?.Language,
        caption: d?.['$']?.Caption, //To-Do: Look into this
        content: d?.['_'],
        texts: resolveDescriptionTextItems(d), //To-Do: Also this
      })),
    }
  })

/**
 * Resolves text items such as title, descriptions, etc in multiple languages
 * @param {array} textItems
 * @returns array
 */
const resolveTextItems = (textItems) =>
  textItems?.[0]?.TextItem?.map(({ $, Description }) => {
    let language = null,
      title = null
    if ($) {
      ;({ Language: language, Title: title } = $)
    }
    //To-Do: Rework here currently setting data
    const descriptions = Description?.map((d) => ({
      language: d?.['$']?.Language,
      caption: d?.['$']?.Caption,
      content: d,
      texts: resolveDescriptionTextItems(d),
    }))
    return {
      language,
      title,
      descriptions,
      plain_descriptions: Description,
    }
  })

/**
 * Resolves multimedia description which contains text items, image items and video items
 * @param {array} description
 * @returns array
 */
const resolveDescriptions = (description) =>
  description?.[0]?.MultimediaDescription?.map(({ $, TextItems, ImageItems, VideoItems }) => {
    let AdditionalDetailCode = null,
      InfoCode = null
    if ($) {
      ;({ AdditionalDetailCode = null, InfoCode = null } = $)
    }
    return {
      info_code: InfoCode,
      detail_code: AdditionalDetailCode,
      text_items: resolveTextItems(TextItems),
      image_items: resolveImageItems(ImageItems),
      video_items: resolveVideoItems(VideoItems),
    }
  }) || []

/**
 * Resolves hotel's basic info such as name, images, content, description, etc
 * @param {array} hotelInfo
 * @returns array
 */
const resolveHotelInfo = (hotelInfo) => ({
  when_built: hotelInfo?.[0]?.['$']?.WhenBuilt,
  hotel_status: hotelInfo?.[0]?.['$']?.HotelStatus,
  tax_id: hotelInfo?.[0]?.['$']?.TaxID,
  status: hotelInfo?.[0]?.['$']?.Status,
  name: {
    short_name: hotelInfo?.[0]?.HotelName?.[0]?.['$']?.['HotelShortName'],
    content: hotelInfo?.[0]?.HotelName?.[0]?.['_'] || hotelInfo?.[0]?.HotelName?.[0],
  },
  category_codes: {
    primary_property_type: hotelInfo?.[0]?.CategoryCodes?.[0]?.['$']?.PrimaryPropertyType,
  },
  segment_categories: hotelInfo?.[0]?.CategoryCodes?.[0]?.SegmentCategory?.reduce((acc, { $: { Code } }) => {
    acc.push({
      code: Code,
    })
    return acc
  }, []),
  descriptions: {
    renovation: hotelInfo?.[0]?.Descriptions?.[0]?.Renovation?.[0]?.['$']?.RenovationCompletionDate,
    mm_descriptions: resolveDescriptions(hotelInfo?.[0]?.Descriptions?.[0]?.MultimediaDescriptions),
  },
  position: {
    latitude: hotelInfo?.[0]?.Position?.[0]?.['$']?.Latitude,
    longitude: hotelInfo?.[0]?.Position?.[0]?.['$']?.Longitude,
  },
  services: hotelInfo?.[0]?.Services?.[0]?.Service.map(({ $, MultimediaDescriptions }) => {
    return {
      code: $?.Code,
      business_code: $?.BusinessServiceCode,
      code_detail: $?.CodeDetail,
      descriptions: resolveDescriptions(MultimediaDescriptions),
      id: $?.ID,
    }
  }),
})

const resolveRoomTypes = (roomTypes) =>
  roomTypes?.map(({ $ }) => ({
    bed_code: $?.BedTypecode,
    type_code: $?.RoomTypeCode,
    quantity: $?.Quantity,
    type: $?.RoomType,
    non_smoking: $?.NonSmoking,
    promo_code: $?.PromoCode,
    size: $?.Size,
    std_num_beds: $?.StandardNumBeds,
    std_occup: $?.StandardOccupancy,
    max_rollaways: $?.MaxRollaways,
  }))

const resolveAmenities = (amenities) =>
  amenities?.[0]?.Amenity?.map(({ $ }) => ({
    code: $?.RoomAmenityCode,
    quantity: $?.Quantity,
  }))

const resolveExcludedChildAgeGroups = (ageGroups) => {
  let fromAge = 0,
    toAge = 0

  return ageGroups?.[0]?.ExcludedAgeGroup?.reduce((acc, { $ }) => {
    if (!$ || !$?.AgeGroupQualifying) {
      return acc
    }
    toAge = parseInt($.AgeGroupQualifying) - 100
    acc.push(`${fromAge} - ${toAge}`)
    fromAge = toAge + 1
    return acc
  }, []).join(', ')
}

const resolveExcludedOccupancy = (guestRoomExclusions) =>
  guestRoomExclusions?.[0]?.GuestRoomExclusion?.map((room) => ({
    excluded_adult_count: room?.['$']?.AdultOccupancy,
    excluded_children_count: room?.ExcludedChildOccupancies?.[0]?.ExcludedChildOccupancy?.length,
    excluded_child_ages: room?.ExcludedChildOccupancies?.[0]?.ExcludedChildOccupancy?.reduce((acc, occup) => {
      if (occup?.['$']?.AllAges === 'true') {
        acc.push('0 - 20') //To-Do: Here static value is set when all ages of children is excluded we can further extend this by using hotel specific max child age
        return acc
      } else {
        acc.push(resolveExcludedChildAgeGroups(occup?.ExcludedAgeGroups))
        return acc
      }
    }, []),
  }))

const resolveFacilityRooms = (rooms) =>
  rooms?.map((room) => ({
    type_name: room?.['$']?.RoomTypeName,
    max_child_occup: room?.['$']?.MaxChildOccupancy,
    max_adult_occup: room?.['$']?.MaxAdultOccupancy,
    min_adult_occup: room?.['$']?.MinAdultOccupancy,
    min_child_occup: room?.['$']?.MinChildOccupancy,
    number_of_bedrooms: room?.TypeRoom?.[0]?.['$']?.NbrOfBedrooms,
    code: room?.['$']?.Code,
    quantity: room?.['$']?.Quantity,
    max_occup: room?.['$']?.MaxOccupancy,
    min_occup: room?.['$']?.MinOccupancy,
    types: resolveRoomTypes(room?.TypeRoom),
    amenities: resolveAmenities(room?.Amenities),
    descriptions: resolveDescriptions(room?.MultimediaDescriptions),
    occupancy_exclusions: resolveExcludedOccupancy(room?.GuestRoomExclusions),
  }))

const resolveFacilityInfo = (facilityInfo) => ({
  rooms: resolveFacilityRooms(facilityInfo?.[0]?.GuestRooms?.[0]?.GuestRoom),
})

const resolveGuarantees = (guarantees) =>
  guarantees?.[0]?.GuaranteePayment?.map((guarantee) => ({
    payment_code: guarantee?.['$']?.PaymentCode,
    guarantee_code: guarantee?.['$']?.GuaranteeCode,
    contract: guarantee?.['$']?.Contract,
    contract_source: guarantee?.['$']?.ContractCode,
    amount_percent: {
      percent: guarantee?.AmountPercent?.[0]?.['$']?.Percent,
      num_nights: guarantee?.AmountPercent?.[0]?.['$']?.NmbrOfNights,
      basis_type: guarantee?.AmountPercent?.[0]?.['$']?.BasisType,
      amount: guarantee?.AmountPercent?.[0]?.['$']?.Amount,
    },
    on_hold: {
      duration: guarantee?.OnHold?.[0]?.['$']?.Duration,
      minimum_lead_time: guarantee?.OnHold?.[0]?.['$']?.MinimumLeadTime,
      availability_threshold: guarantee?.OnHold?.[0]?.['$']?.AvailabilityThreshold,
      reminder_mail_offset: guarantee?.OnHold?.[0]?.['$']?.ReminderMailOffset,
      promotion_percent: guarantee?.OnHold?.[0]?.['$']?.PromotionPercent,
      promotion_amount: guarantee?.OnHold?.[0]?.['$']?.PromotionAmount,
    },
    descriptions: guarantee?.Description?.map((description) => ({
      texts: resolveDescriptionTextItems(description),
    })),
  }))

const resolvePenalties = (penalties) =>
  penalties?.map((penalty) => ({
    code: penalty?.['$']?.Code,
    deadline: {
      abs_deadline: penalty?.Deadline?.[0]?.['$']?.AbsoluteDeadline,
      offset_time: penalty?.Deadline?.[0]?.['$']?.OffsetTimeUnit,
      offset_mult: penalty?.Deadline?.[0]?.['$']?.OffsetUnitMultiplier,
      offset_drop_time: penalty?.Deadline?.[0]?.['$']?.OffsetDropTime,
    },
    amount_percent: {
      basis_type: penalty?.AmountPercent?.[0]?.['$']?.BasisType,
      num_nights: penalty?.AmountPercent?.[0]?.['$']?.NmbrOfNights,
      percent: penalty?.AmountPercent?.[0]?.['$']?.Percent,
      amount: penalty?.AmountPercent?.[0]?.['$']?.Amount,
      currency: penalty?.AmountPercent?.[0]?.['$']?.Currency,
    },
    descriptions: penalty?.PenaltyDescription?.map((description) => ({
      name: description?.['$']?.Name,
      texts: resolveDescriptionTextItems(description),
    })),
  }))

const resolvePolicies = (policies) =>
  policies?.[0]?.Policy.map((policy) => ({
    code: policy?.['$']?.Code,
    cancellation: {
      penalties: resolvePenalties(policy?.CancelPolicy?.[0]?.CancelPenalty),
    },
    guarantee: {
      code: policy?.GuaranteePaymentPolicy?.[0]?.['$']?.Code,
      guarantees: resolveGuarantees(policy?.GuaranteePaymentPolicy),
    },
    tax: {
      amount: policy?.TaxPolicies?.[0]?.TaxPolicy?.[0]?.['$']?.Amount,
      currency: policy?.TaxPolicies?.[0]?.TaxPolicy?.[0]?.['$']?.Currency,
      code: policy?.TaxPolicies?.[0]?.TaxPolicy?.[0]?.['$']?.Code,
      type: policy?.TaxPolicies?.[0]?.TaxPolicy?.[0]?.['$']?.Type,
      base: policy?.TaxPolicies?.[0]?.TaxPolicy?.[0]?.['$']?.Base,
      base_amount_type: policy?.TaxPolicies?.[0]?.TaxPolicy?.[0]?.['$']?.BaseAmountType,
      percent: policy?.TaxPolicies?.[0]?.TaxPolicy?.[0]?.['$']?.Percent,
      minApplicableAge: policy?.TaxPolicies?.[0]?.TaxPolicy?.[0]?.['$']?.minApplicableAge,
      maxApplicableAge: policy?.TaxPolicies?.[0]?.TaxPolicy?.[0]?.['$']?.maxApplicableAge,
      effectiveDate: policy?.TaxPolicies?.[0]?.TaxPolicy?.[0]?.['$']?.EffectiveDate,
      expireDate: policy?.TaxPolicies?.[0]?.TaxPolicy?.[0]?.['$']?.ExpireDate,
      descriptions: policy?.TaxDescription?.map((description) => ({
        name: description?.['$']?.Name,
        texts: resolveDescriptionTextItems(description),
      })),
    },
    pet: {
      code: policy?.PetsPolicies?.[0]?.PetsPolicy?.[0]?.['$']?.PetsPolicyCode,
      fee: policy?.PetsPolicies?.[0]?.PetsPolicy?.[0]?.['$']?.NonRefundableFee,
      currency: policy?.PetsPolicies?.[0]?.PetsPolicy?.[0]?.['$']?.Currency,
      descriptions: policy?.PetsPolicies?.[0]?.PetsPolicy?.[0]?.Description?.map((description) => ({
        language: description?.['$']?.Language,
        caption: description?.['$']?.Caption,
        content: description?.['$']?.Content,
        texts: resolveDescriptionTextItems(description),
      })),
    },
    checkout_charge: {
      code: policy?.CheckoutCharges?.[0]?.CheckoutCharge?.[0]?.['$']?.Code,
      amount: policy?.CheckoutCharges?.[0]?.CheckoutCharge?.[0]?.['$']?.Amount,
      charging_type: policy?.CheckoutCharges?.[0]?.CheckoutCharge?.[0]?.['$']?.TypeOfCharging,
      type: policy?.CheckoutCharges?.[0]?.CheckoutCharge?.[0]?.['$']?.Type,
      descriptions: policy?.CheckoutCharges?.[0]?.CheckoutCharge?.[0]?.Description?.map((description) => ({
        language: description?.['$']?.Language,
        caption: description?.['$']?.Caption,
        content: description?.['$']?.Content,
        texts: resolveDescriptionTextItems(description),
      })),
    },
    taxes: policy?.TaxPolicies?.[0]?.TaxPolicy?.map((tax) => ({
      amount: tax?.['$']?.Amount,
      currency: tax?.['$']?.Currency,
      code: tax?.['$']?.Code,
      type: tax?.['$']?.Type,
      base: tax?.['$']?.Base,
      base_amount_type: tax?.['$']?.BaseAmountType,
      percent: tax?.['$']?.Percent,
      minApplicableAge: tax?.['$']?.minApplicableAge,
      maxApplicableAge: tax?.['$']?.maxApplicableAge,
      effectiveDate: tax?.['$']?.EffectiveDate,
      expireDate: tax?.['$']?.ExpireDate,
      descriptions: tax?.TaxDescription?.map((description) => ({
        name: description?.['$']?.Name,
        texts: resolveDescriptionTextItems(description),
      })),
    })),
    pets: policy?.PetsPolicies?.[0]?.PetsPolicy?.map((pets) => ({
      code: pets?.['$']?.PetsPolicyCode,
      fee: pets?.['$']?.NonRefundableFee,
      currency: pets?.['$']?.Currency,
      descriptions: pets?.Description?.map((description) => ({
        language: description?.['$']?.Language,
        caption: description?.['$']?.Caption,
        content: description?.['$']?.Content,
        texts: resolveDescriptionTextItems(description),
      })),
    })),
  }))

const resolveContacts = () => {
  return {}
}

const resolveExtensions = () => {
  return {}
}

const prepareForDb = async (dataSources, params) => {
  const { data: hotelInfo, error } = await fetchXMLHotelInfo(dataSources, params.options)
  if (error) throw 'Error in fetching HotelInfoXML API'
  return hotelInfo.reduce(
    (acc, { HotelInfo, FacilityInfo, Policies, ContactInfos, TPA_Extensions }) => ({
      hotelCode: params.options.hotelId,
      userId: params.options.userId,
      ...acc,
      info: resolveHotelInfo(HotelInfo),
      facility: resolveFacilityInfo(FacilityInfo),
      policies: resolvePolicies(Policies),
      contacts: resolveContacts(ContactInfos),
      ext: resolveExtensions(TPA_Extensions),
    }),
    {},
  )
}

const cacheResponse = async ({ dataSources, db }, params) => {
  const logs = {
    success: false,
    error: false,
    message: null,
    reason: null,
  }
  try {
    // fetch and resolve data
    const cache = await prepareForDb(dataSources, params)
    if (isValue(cache)) {
      //clear stale data
      await db.delete('hotelinfoXML', { userId: params.options.userId })
      //revalidate cache in db
      await db.insertOne('hotelinfoXML', cache)
      //logs
      logs.success = true
      logs.message = `HotelInfoXML API cached successfully for ${params.options.hotelId}`
    } else {
      logs.error = true
      logs.message = "no data found for HotelInfoXML APII"
    }
  } catch (e) {
    logs.error = true
    logs.message = `Error in caching HotelInfoXML for ${params.options.hotelId}`
    logs.reason = e.message || e
  }
  return logs
}

const cacheHotelInfoJSON = async (parent, params, context, info) => {
  return cacheResponse(context, { ...parent.params, ...params })
}

module.exports = cacheHotelInfoJSON
