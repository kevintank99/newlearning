const cacheCm = require('./cachers/cacheCm')
const cacheHotelInfoJSON = require('./cachers/cacheHotelInfoJSON')
const cacheOffersOverviewJSON = require('./cachers/cacheOffersOverviewJSON')
const cacheHotelInfoXML = require('./cachers/cacheHotelInfoXML')
const cacheRatesXML = require('./cachers/cacheRatesXML')
const cacheRatesAverageJSON = require('./cachers/cacheRatesAverageJSON')
const cacheBookabilityJSON = require('./cachers/cacheBookabilityJSON')
const cacheServicesJSON = require('./cachers/cacheServicesJSON')
const cacheServicesXML = require('./cachers/cacheServicesXML')

module.exports = {
  cacheCm,
  cacheHotelInfoJSON,
  cacheOffersOverviewJSON,
  cacheHotelInfoXML,
  cacheRatesXML,
  cacheRatesAverageJSON,
  cacheBookabilityJSON,
  cacheServicesJSON,
  cacheServicesXML,
}
