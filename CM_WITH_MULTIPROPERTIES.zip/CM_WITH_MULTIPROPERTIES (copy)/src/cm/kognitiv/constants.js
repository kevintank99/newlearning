
//default values to fall back to unless they are overwritten by client configuration
const defaults = {
  timePeriod: 365, //for how many days to retrieve the data from by default
  channelId: 'MTS', //MTS Channel and user/password.
  // when bookings have to be retrieved this user MUST be inserted as PMS in the Kognitiv hotels or another user has to be provided
  apiUser: 'info@mts-italia.it',
  apiToken: 'AF57UT3STM4Z',
  language: 'en', //default fallback language
  currency: 'EUR', //default fallback currency
  numberOfDays: 365,
  numberOfMonths: 12,
  cacheLanguages: ['de', 'en', 'it', 'fr', 'nl'],
}

// types of beds available
const bedTypes = require('./constants/Primary_Bed_Types.json')

// == include the following data only if required, eg. for semantic data ==

// const additionalDetailCode = require('./constants/Additional_Detail_Code.json');
// const addressTypes = require('./constants/Adress_Types.json');
// const adviceTexts = require('./constants/Advice_Texts.json');
// const animalCategories = require('./constants/Animal_Categories.json');
const bedTypeAmenityCodes = require('./constants/Bed_Type_Amenity_Codes.json');
// const bedType = require('./constants/Bed_Type.json');
// const contactDetails = require('./constants/Contact_Details.json');
// const countryCodes = require('./constants/Country_Codes.json');
// const creditCards = require('./constants/Credit_Cards.json');
// const feeTaxTypes = require('./constants/Fee_Tax_Types.json');
// const feeTypes = require('./constants/Fee_Types.json');
// const hotelAmenitiesCategories = require('./constants/Hotel_Amenities_Categories.json');
// const hotelAmenities = require('./constants/Hotel_Amenities.json');
// const infoCodes = require('./constants/Info_Codes.json');
const mealPlanCodes = require('./constants/Meal_Plan_Codes.json'); //meal plan code to description mapping in multiple languages
// const paymentCodes = require('./constants/Payment_Codes.json');
// const phoneTypes = require('./constants/Phone_Types.json');

const pictureTopics = require('./constants/Picture_Categories.json'); //renamed "category" to "topic" to make the difference with internal "categories" obvious

// const primaryBedTypes = require('./constants/Primary_Bed_Types.json');
// const segmentCategories = require('./constants/Segment_Categories.json');
// const unitOfArea = require('./constants/Unit_of_Area.json');

//types of property
const propertyTypes = require('./constants/Property_Types.json');

//list of known room amenities
const roomAmenities = require('./constants/Room_Amenities.json');
const roomAmenitiesCustom = require('./constants/Room_Amenities_Custom.json');
//extend kognitiv room amenities with any custom amenity or overwrite them
Object.assign(roomAmenities, require('./constants/Room_Amenities.json'));

//list of known room types
const roomTypes = require('./constants/Room_Types.json');
//extend kognitiv room types with custom room types for camping and others
Object.assign(roomTypes, require('./constants/Room_Types_Custom.json'));

const roomTypesCamping = [21, 22] //pitch and caravan are camping "room" types without any bed
const hotelOnlyRoomAmenities = ['RAT_58', 'RAT_33', 'RAT_102'] //amenities which apply only to hotel rooms (not camping)
const ratePlanTypes = {
  ROOMS_DAILY: 5,
  FIXED_RATE_OFFERS: 11,
  DAILY_BASED_OFFERS: 511
}
const decodeStrings = require('./constants/Decode_Strings.json')

const DEFAULT_MEALPLANCODE = '3'

const DEFAULT_CACHE_LIMIT = 86400; //24 hour

module.exports = {
  defaults,
  bedTypes,
  bedTypeAmenityCodes,
  roomTypes,
  roomTypesCamping,
  propertyTypes,
  ratePlanTypes,
  roomAmenities,
  roomAmenitiesCustom,
  hotelOnlyRoomAmenities,
  pictureTopics,
  mealPlanCodes,
  decodeStrings,
  DEFAULT_MEALPLANCODE,
  DEFAULT_CACHE_LIMIT,
}
