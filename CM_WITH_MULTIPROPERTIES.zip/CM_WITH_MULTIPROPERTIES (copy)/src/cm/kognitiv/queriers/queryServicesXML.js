const mergeServicesXML = async (db, userIds) => {
  const multiplePropertyServicesXML = await Promise.all(
    userIds.map((userId) =>
      db.findOne('servicesXML', {
        userId,
      }),
    ),
  )

  const mergedServicesXML = {
    services: [],
  }

  for (let servicesXML of multiplePropertyServicesXML) {
    mergedServicesXML.services.push(...servicesXML.services)
  }

  return mergedServicesXML
}

const queryServicesXML = async (db, config) => {
  if (config?.chainedProperties) {
    return mergeServicesXML(db, Object.keys(config?.chainedProperties))
  } else {
    return db.findOne('servicesXML', {
      userId: config.user_id,
    })
  }
}

module.exports = queryServicesXML
