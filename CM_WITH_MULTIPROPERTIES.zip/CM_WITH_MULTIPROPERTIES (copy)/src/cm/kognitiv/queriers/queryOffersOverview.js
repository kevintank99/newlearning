const mergeOffersOverview = async (db, userIds, language) => {
  const multiplePropertyOffersOverview = await Promise.all(
    userIds.map((userId) =>
      db.findOne('offersoverview', {
        userId,
        language,
      }),
    ),
  )

  const mergedOverview = {
    overview: {
      entities: [],
      mealPlans: {},
    },
  }

  for (let offersOverview of multiplePropertyOffersOverview) {
    // console.log("offersOverview.........", offersOverview.overview.currency)
    mergedOverview.overview.entities.push(...offersOverview.overview.entities)
    mergedOverview.overview.mealPlans = {
      ...mergedOverview.overview.mealPlans,
      ...offersOverview.overview.mealPlans,
    }
    mergedOverview.overview.currency = offersOverview.overview.currency
  }
  return mergedOverview
}

const queryOffersOverview = async (db, config, language) => {
  if (config?.chainedProperties) {
    return mergeOffersOverview(db, Object.keys(config?.chainedProperties), language)
  } else {
    return db.findOne('offersoverview', {
      userId: config.user_id,
      language,
    })
  }
}

module.exports = queryOffersOverview
