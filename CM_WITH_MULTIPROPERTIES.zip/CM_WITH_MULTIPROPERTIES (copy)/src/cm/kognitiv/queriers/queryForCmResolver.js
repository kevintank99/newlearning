const addHotelCode = async(data,hotelCode,key)=>{
  data?.forEach(element => {
    element.hotelCode = hotelCode
    element.keyType = key
  });
  return data
}

const mergeHotelDetails = async (multiplePropertyHotelInfo)=>{
  const mergedHotelInfo = {
    info: {
      amenities: [],
      name: [],
      descriptions: {
        mm_descriptions: [],
      },
      nameOfchainedProperties : [],
    },
    facility: {
      rooms: [],
    },
    ext: {
      seasons: [],
      classifications: [],
      children: [],
    },
    contacts : []
  }
  for (let hotelInfo of multiplePropertyHotelInfo) {
    if(hotelInfo){
      mergedHotelInfo.info.amenities.push(...(await addHotelCode(hotelInfo?.info?.amenities,hotelInfo?.hotelCode,'amenities')))
      mergedHotelInfo.info.descriptions.mm_descriptions.push(...(await addHotelCode(hotelInfo?.info?.descriptions?.mm_descriptions,hotelInfo?.hotelCode,'mm_descriptions')))
      mergedHotelInfo.facility.rooms.push(...(await addHotelCode(hotelInfo?.facility?.rooms,hotelInfo?.hotelCode,'rooms')))
      mergedHotelInfo.ext.seasons.push(...(hotelInfo?.ext?.seasons))
      mergedHotelInfo.ext.classifications.push(...(hotelInfo?.ext?.classifications))
      mergedHotelInfo.ext.children.push(...(await addHotelCode(hotelInfo?.ext?.children,hotelInfo?.hotelCode,'children')))
      mergedHotelInfo.contacts.push(...(await addHotelCode(hotelInfo.contacts,hotelInfo?.hotelCode, 'contacts')))
      mergedHotelInfo.info.name.push({...hotelInfo.info.name,hotelCode:hotelInfo?.hotelCode,keyType:'name'})
    }
  }
  return mergedHotelInfo
}

const bindSingleHotelInfo = async (hotelInfo)=>{
  const singlePropertyHotelInfo = [hotelInfo];
  return await mergeHotelDetails(singlePropertyHotelInfo)
}



const mergeHotelInfo = async (db, userIds, language) => {
  const multiplePropertyHotelInfo = await Promise.all(
    userIds.map((userId) => db.findOne('hotelinfo', { userId, language })),
  )
  return await mergeHotelDetails(multiplePropertyHotelInfo)
}

const queryForCmResolver = async (db, userId, language) => {
  const config = await db.findOne('smts', {
    user_id: userId,
  })
  let property, token
  if (config?.chainedProperties) {
    ;[property, token] = await Promise.all([
      mergeHotelInfo(db, Object.keys(config.chainedProperties), language),
      db.findOne('token', { userId }),
    ])
  } else {
    ;[property, token] = await Promise.all([
      bindSingleHotelInfo(await db.findOne('hotelinfo', { userId, language })),
      db.findOne('token', { userId }),
    ])
  }

  return {
    config,
    property,
    token,
  }
}

module.exports = queryForCmResolver
