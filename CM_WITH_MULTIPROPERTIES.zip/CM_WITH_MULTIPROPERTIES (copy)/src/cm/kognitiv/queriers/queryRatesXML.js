const assortRatesXML = (ratesXML) => {
  return ratesXML.reduce((acc, rateXML) => {
    return {
      ...acc,
      [rateXML.roomCode]: rateXML.rates,
    }
  }, {})
}

const mergeRatesXML = async (db, userIds) => {
  const multiplePropertyRatesXML = await Promise.all(
    userIds.map((userId) =>
      db.find('ratesXML', {
        userId,
      }),
    ),
  )

  const mergedRatesXML = {}

  for (let ratesXML of multiplePropertyRatesXML) {
    Object.assign(mergedRatesXML, assortRatesXML(ratesXML))
  }

  return mergedRatesXML
}

const queryRatesXML = async (db, config) => {
  if (config?.chainedProperties) {
    return mergeRatesXML(db, Object.keys(config.chainedProperties))
  } else {
    return assortRatesXML(
      await db.find('ratesXML', {
        userId: config.user_id,
      }),
    )
  }
}

module.exports = queryRatesXML
