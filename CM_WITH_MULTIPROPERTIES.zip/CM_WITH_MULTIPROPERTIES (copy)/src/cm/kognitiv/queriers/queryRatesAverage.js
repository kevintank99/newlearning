const mergeRatesAverage = async (db, userIds, language) => {
  const multiplePropertyRatesAverage = await Promise.all(
    userIds.map((userId) =>
      db.findOne('ratesaverage', {
        userId,
        language,
      }),
    ),
  )

  const mergedRatesAverage = {
    rooms: [],
    packages: [],
  }

  for (let ratesAverage of multiplePropertyRatesAverage) {
    mergedRatesAverage.rooms.push(...ratesAverage.rooms)
    mergedRatesAverage.packages.push(...ratesAverage.packages)
  }

  return mergedRatesAverage
}

const queryRatesAverage = async (db, config, language) => {
  if (config?.chainedProperties) {
    return mergeRatesAverage(db, Object.keys(config?.chainedProperties), language)
  } else {
    return db.findOne('ratesaverage', {
      userId: config.user_id,
      language,
    })
  }
}

module.exports = queryRatesAverage
