const mergeServices = async (db, userIds, language) => {
  const multiplePropertyServices = await Promise.all(
    userIds.map((userId) =>
      db.findOne('services', {
        userId,
        language,
      }),
    ),
  )

  const mergedServices = {
    services: [],
  }

  for (let services of multiplePropertyServices) {
    mergedServices.services.push(...services.services)
  }

  return mergedServices
}

const queryServices = async (db, config, language) => {
  if (config?.chainedProperties) {
    return mergeServices(db, Object.keys(config?.chainedProperties), language)
  } else {
    return db.findOne('services', {
      userId: config.user_id,
      language,
    })
  }
}

module.exports = queryServices
