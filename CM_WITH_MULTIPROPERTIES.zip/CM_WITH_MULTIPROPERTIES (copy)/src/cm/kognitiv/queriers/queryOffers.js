const { fetchOffers } = require('../fetchers')

const addHotelCode = (roomOffersForOccupancy,hotelCode)=>{
    if(roomOffersForOccupancy){
      roomOffersForOccupancy.map((data)=>{
        data.hotelCode = hotelCode
      })
    }
    return roomOffersForOccupancy
}


const bindSingleHotelInfo = async(offers)=>{
  const hotelId = Object.keys(offers.result)[0]
    offers.result[hotelId].room_offers.map(async(data) =>{
      await addHotelCode(data,hotelId)
    })
    return offers
}

const mergeOffers = async (dataSources, hotelIds, params, masterHotelId) => {
  const multiplePropertyOffers = await Promise.all(
    hotelIds.map((hotelId) => fetchOffers(dataSources, { ...params, hotelId })),
  )

  const mergedOffers = {
    success: true,
    result: {
      [masterHotelId]: {
        currency_code: '',
        room_offers: [],
        metadata: {
          rooms: [],
          mealPlans: {},
          rates: [],
          images: [],
          categories: [],
        },
        hide_prices: false,
      },
    },
  }

  for (let index in multiplePropertyOffers) {
    const { data: offers } = multiplePropertyOffers[index]
    
    const hotelIdOfOffers = hotelIds[index]
    
    mergedOffers.result[masterHotelId].currency_code = offers.result[hotelIdOfOffers].currency_code
    offers.result[hotelIdOfOffers].room_offers.forEach((roomOffersForOccupancy, index) => {
      if (!mergedOffers.result[masterHotelId].room_offers[index]) {
        mergedOffers.result[masterHotelId].room_offers[index] = []
      }
      mergedOffers.result[masterHotelId].room_offers[index].push(...(addHotelCode(roomOffersForOccupancy || [],hotelIdOfOffers)))
    })
    mergedOffers.result[masterHotelId].metadata.rooms.push(...offers.result[hotelIdOfOffers].metadata.rooms)
    mergedOffers.result[masterHotelId].metadata.mealPlans = {
      ...mergedOffers.result[masterHotelId].metadata.mealPlans,
      ...offers.result[hotelIdOfOffers].metadata.mealPlans,
    }
    mergedOffers.result[masterHotelId].metadata.rates.push(...(offers.result[hotelIdOfOffers].metadata.rates || []))
    mergedOffers.result[masterHotelId].metadata.images.push(...offers.result[hotelIdOfOffers].metadata.images)
    mergedOffers.result[masterHotelId].metadata.categories.push(...offers.result[hotelIdOfOffers].metadata.categories)
  }
  
  return mergedOffers
}

const queryOffers = async (dataSources, config, params) => {
  if (config?.chainedProperties) {
    return mergeOffers(dataSources, Object.values(config?.chainedProperties), params, config.seekda.hotelid)
  } else {
    return bindSingleHotelInfo(await fetchOffers(dataSources, params).then(({ data }) => data))
    // return fetchOffers(dataSources, params).then(({ data }) => data)
 }
}

module.exports = queryOffers
