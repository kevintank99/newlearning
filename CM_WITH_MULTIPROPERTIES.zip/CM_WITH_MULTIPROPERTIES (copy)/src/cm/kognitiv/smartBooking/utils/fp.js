import { isValue } from "./type";
import { arrayReduce, arrayReduceRight } from "./array";

export const fnId = (x) => x 
export const fnReturn = (f) => fnId //helper when inside arrow function a single statement has to be executed and another value has to be returned
export const fnCompose = (...fns) => (x) => arrayReduceRight((res, fn) => fn(res), fns)(x); //function composition (rtl)
export const fnPipe = (...fns) => (x) => arrayReduce((res, fn) => fn(res), fns)(x); //function composition (ltr)
export const fnTap = (f) => (x) => fnReturn(f(x))(x)  //way to invoke a function like console.log within Pipe or Compose
export const fnTrace = (label) => fnTap(console.log.bind(console, label + ':'));
export const fnIfElse = (fnCheck, fnTrue, fnFalse) => (x) => fnCheck(x) ? fnTrue(x) : fnFalse(x)
export const fnIfValue = (f) => (x) => fnIfElse(isValue, f, fnId)(x)
export const fnIf = (fnCheck, fnOk) => (x) => fnIfElse(fnCheck, fnOk, fnId)(x)
export const fnGt = (v) => (x) => x > v
export const fpConst = (c) => () => c //constant combinator, always returns c
export const fnAlways = () => true //helper function to return always true
