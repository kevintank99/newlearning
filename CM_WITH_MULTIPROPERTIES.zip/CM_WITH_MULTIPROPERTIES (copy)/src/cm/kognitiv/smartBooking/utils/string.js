import {isString, isStringValue, isArrayValue, isNumber} from './type'
import {arrayJoin} from './array'

/* string manipulation */
export const strPrefix = (p, s) => isStringValue(s) && isStringValue(p) ? p + s : '' //prefix (a) non-empty string (s)
export const strPrefixJoin = (p, a) => isArrayValue(a) && isStringValue(p) ? p + arrayJoin(p, a) : '' //join a non empty array of string (a) prefixing every element with (s)
export const strRepeat = (t, s) => s.repeat(t) //repeat string (s) for (t) times
export const strSplit = (p, s) => s.split(p)
export const strLength = (s) => s.length
export const strReplace = (se, re, su) => isString(se) ? arrayJoin(re, strSplit(se, su)) : su.replace(se, re) //replace search (se) with replacement (re) in subject (su)
export const strContains = (p, s) => s.indexOf(p) > -1 //find string p in string s
export const strCompareLength = (a, b) => strLength(b) - strLength(a) //sort methods by length so replacement of eg. "mmmm" precedes replacement of "m"
export const strSub = (s, t, l) => isNumber(l) ? s.substr(t, l) : s.substr(t) 
export const strToUpper = (s) => s.toUpperCase()
export const strToLower = (s) => s.toLowerCase()
export const strToCamelCase = (s) => strReplace(/-(.)/g, ($0, $1) => strToUpper($1), s)
export const strToDash = (s) => strReplace(/([A-Z])/g, ($0, $1) => '-' + strToLower($1), s)