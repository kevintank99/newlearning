/* type checks */
export const typeOf = (v) => typeof v //generic typeof with all odds (null = object, NaN = number, [] = object, etc.)
export const isDefined = (v) => typeOf(v)!== 'undefined' //is (v) defined
export const isObjectLike = (o) => typeOf(o) === 'object' //is o an object or array
export const isNull = (v) => isDefined(v) && v === null //is v null but defined
export const isNotNull = (v) => !isNull(v) //is v not null or undefined
export const isValue = (v) => isDefined(v) && !isNull(v) && isNaN(v) //is v defined an has a value not null or NaN
export const isNoValue = (v) => !isValue(v)  //is v undefined or null or NaN
export const isLength = (v) => !!v.length //does (v) have a length <> 0
export const isString = (s) => typeOf(s) === 'string' //is (s) of type "string"
export const isStringValue = (s) => isString(s) && isLength(s) //is (s) a non empty string
export const isArray = (v) => isObjectLike(v) && isNotNull(v) && Array.isArray(v); //is (v) an array
export const isArrayValue = (a) => isArray(a) && isLength(a); //is (a) a non empty array
export const isObject = (o) => isObjectLike(o) && isNotNull(o) && !isArray(o); //is (v) an object (but NOT an array and not null - n.B. typeof null = object)
export const isObjectEmpty = (o) => !isLength(Object.entries(o)) //is the object (o) with no properties (n.B. no type check is performed on "o")
// export const isEmptyObject = (o) => isObject(o) && isObjectEmpty(o);
export const isObjectValue = (o) => isObject(o) && !isObjectEmpty(o); //check if (o) is an object with properties
export const isNumber = (n) => typeOf(n) === 'number' && isFinite(n); //check for valid finite number (note: this excludes NaN - if check for NaN is wanted use isNaN())
export const isFunction = (f) => typeOf(f) === 'function' //is (f) of type function
export const isDate = (d) => isObjectLike(d) && d instanceof Date //is (d) of type date
