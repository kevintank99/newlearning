
//date manipulation
export const dateDate = (d) => d.getDate()
export const dateYear = (d) => d.getFullYear()
export const dateMonth = (d) => d.getMonth()
export const dateDay = (d) => d.getDay()

export const dateCreate = (yyyy, mm, dd) => new Date(yyyy, mm, dd, 0, 0, 0, 0, 0) //time value is always reset to 00:00
export const dateClone = (d) => dateCreate(dateYear(d), dateMonth(d), dateDate(d)) 
export const dateFirstOfMonth = (d) => dateCreate(dateYear(d), dateMonth(d), 1);
export const dateLastOfMonth = (d) => dateCreate(dateYear(d), dateMonth(d) + 1, 0)
export const dateDiffDays = (d1, d2) => (dateClone(d2) - dateClone(d1)) / 86400000 //get the difference in days between two dates. 0 = equal | <0 = d1 > d2 | >0 = d2 > d1
export const dateSameDate = (d1, d2) => dateDiffDays(d1, d2) === 0
export const dateBefore = (d1, d2) => d1 < d2 ? d1 : d2
export const dateAfter = (d1, d2) => d2 > d1 ? d2 : d1
export const dateBetween = (d1, d2) => (d) => dateDiffDays(dateBefore(d1, d2), d) >= 0 && dateDiffDays(dateAfter(d1, d2), d) <= 0
export const dateBetweenEx = (d1, d2) => (d) => dateDiffDays(dateBefore(d1, d2), d) > 0 && dateDiffDays(dateAfter(d1, d2), d) < 0
export const dateMonthLength = (d) => dateLastOfMonth(d).getDate()
export const dateAddMonths = (n, d) => dateCreate(dateYear(d), dateMonth(d) + n, dateDate(d))
export const dateAddDays = (n, d) => dateCreate(dateYear(d), dateMonth(d), dateDate(d) + n)

export const dateToday = () => dateClone(new Date) //impure - result depends on current date