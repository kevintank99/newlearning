// import { strSplit } from './string'
// import { isObject, typeOf } from './type'
// import { arrayFirst, arrayMap } from './array'

// //impure - change input obj
// export const objMutate = (m) => (o) => Object.assign(o, Object.assign({}, m)) //mutate object o with (cloned) object m
// export const objMutateKey = (k, v) => (o) => (typeOf(o[k]) === typeOf(v) ? o[k] : (o[k] = v)) //changes object (o) - returns whatever is o[k] if typeof v matches and overwrites any different type value with (v)
// const objMutatePathArray = (path, value) => (o) => {
//   path.length > 1 ? objMutatePathArray(arrayFirst(path), value)(objMutateKey(path[0], {})(o)) : (o[path] = value)
//   return o
// }
// export const objMutatePath = (path, value) => (o) => objMutatePathArray(strSplit('.', path), value)(o) //mutates object o
// //PURE
// export const objClone = (o) => objMutate({})(o) //return a shallow copy of object o by mutating an empty object with it
// export const objExtend = (o, e) => objMutate(e)(objClone(o)) //extend object (o) with properties from object (e)
// export const objExtendKey = (o, k, v) => objExtend(o, { [k]: v }) //extend object (o) with a key (k) with value (v)
// export const objIncludesEntry = (o) => (e) => Object.keys(o).includes(e[0]) //do the keys of object (o) contain the key part of the entry-array (e)
// export const objIntersect = (o1, o2) => Object.fromEntries(Object.entries(o1).filter(objIncludesEntry(o2)))
// export const objCollection = (n, fn) => Array.from({ length: n }, fn) // [...Array(size).keys] create an array of size (n) with creation function (fn)
// export const objFunctions = (o) =>
//   Object.getOwnPropertyNames(o)
//     .filter((i) => isFunction(o[i]))
//     .sort(strCompareLength) //list all properties of type function from object (o)
// export const objSetPath = (path, value) => (o) => objMutatePath(path, value)(objClone(o)) //set value on copy of obj in nested dot path with value
// export const objMap = (fn) => (o) => Object.fromEntries(Object.entries(o).map(([k, v], i) => [k, fn(v, k, i)]))

// returns an array of the found results as objects [{ searched_key: 'value', path: 'nested.object' }]
const findByKeyFromObject = (obj, keyToFind, path) =>
  Object.entries(obj).reduce(
    (acc, [key, value]) =>
      key === keyToFind
        ? acc.concat({
            [key]: value,
            ...(path && { path }),
          })
        : typeof value === 'object' && value
        ? acc.concat(findByKeyFromObject(value, keyToFind, path ? `${path}.${key}` : key))
        : acc,
    [],
  ) || []

// returns a value by it's path/key, example: findValueByPath(obj, 'seekda.apikey') -> 'abc123'
const findValueByPath = (obj, path) =>
  path
    .replace(/\[|\]\.?/g, '.')
    .split('.')
    .filter((s) => s)
    .reduce((acc, val) => {
      return acc && acc[val]
    }, obj)

module.exports = {
  findByKeyFromObject,
  findValueByPath,
}
