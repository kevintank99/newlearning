import {strSub} from './string'

export const twoDigits = (n) => strSub('00' + n, -2) //return two digits 0 prefixed string for number n
