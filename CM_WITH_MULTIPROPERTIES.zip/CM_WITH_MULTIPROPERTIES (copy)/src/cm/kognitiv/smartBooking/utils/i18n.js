
const localeText = (arr, languageKey, targetKey, fallback, language) => {
  const translation = arr.find(obj => obj[languageKey].toLowerCase() === language)
  return translation ? translation[targetKey] : fallback
}

module.exports = {
  localeText
}
