export const arrayJoin = (s, a) => a.join(s) //join an array to string with separator (s)
export const arrayJoinFn = (fn, a) => a.join(fn(a))
export const arrayMap = (f, a) => a.map(f) // map function f over array a
export const arrayFilter = (f, a) => a.filter(f);
export const arrayFilterOne = (f, a) => arrayFilter(f, a)[0]
export const arrayPush = (v, a) => [].concat(a, v) //https://vincent.billey.me/pure-javascript-immutable-array/
export const arrayFirst = (a) => a.slice(1) //return first element of array (shift)
export const arrayLast = (a) => a.slice(0, -1) //return last element of array (pop)
export const asArray = (l) => Array.from(l)
export const arrayReduce = (f, a) => (v) => a.reduce(f, v)
export const arrayReduceRight = (f, a) => (v) => a.reduceRight(f, v)
export const arrayClone = (a) => [].concat(a)
/* impure */
export const arrayMutatePush = (v, a) => a.push(v)
