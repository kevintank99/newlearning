const { defaults, bedTypes } = require('./constants')
const fetchProperty = require('./datasources/fetchProperty')
const fetchOffers = require('./datasources/fetchOffers')
const fetchServices = require('./datasources/fetchServices')
const fetchToken = require('./datasources/fetchToken')
const fetchXMLRates = require('./datasources/fetchXMLRates')
const { findValueByPath } = require('./utils/object')
const decode = require('unescape')

const resolveSmartBooking = async (_source, params, { dataSources }, info) => {
  // parse stringified json object from params
  // const configJSON = JSON.parse(decode(params.config)) || {}
  const configJSON = params.config || {}
  console.log('_____________')
  // console.log(configJSON.rooms)

  // Create options object from the given parameters or from the constants ('./utils/constants') in case none is provided
  const options = {
    ...params,
    language: params.language ? params.language : defaults.language,
    hotelId: findValueByPath(configJSON, 'seekda.hotelid'),
    apiKey: findValueByPath(configJSON, 'seekda.apikey'),
    apiUser: findValueByPath(configJSON, 'seekda.user') || defaults.apiUser, //default api user is info@mts-italia.it, can only be changed in the protected user config
    apiToken: findValueByPath(configJSON, 'seekda.token') || defaults.apiToken, //default api password for accessing data
    config: configJSON,
    ...(params.checkin && { checkin: params.checkin }),
    ...(params.checkout && { checkout: params.checkout }),
    ...(params.rooms && { rooms: params.rooms }),
    ...(params.exclude && { exclude: params.exclude }),
  }

  // Fetch data from the datasource (fetch token together with property info)
  const [{ data: tokenData, error: tokenError }, { data: propertyData, error: propertyError }] = await Promise.all([
    fetchToken(dataSources, options),
    fetchProperty(dataSources, options),
  ])

  // const { data: ratesData, error: ratesError } = await fetchXMLRates(dataSources, options)
  const { data: servicesData, error: servicesError } = await fetchServices(dataSources, { ...options, accessToken: tokenData })

  const [
    { data: offersData, error: offersError },
  ] = await Promise.all([
    fetchOffers(dataSources, { ...options, accessToken: tokenData }),
  ])



  offersError && console.log(`Offers: ${offersError}`)
  tokenError && console.log(`Token: ${tokenError}`)
  propertyError && console.log(`Property: ${propertyError}`)

  // console.log(servicesData)

  // return resolved property object to GraphQL (all values are typed in the schema)
  // everything added here has to be added to the schema
  return {
    offersDebug: offersData,
    servicesDebug: servicesData,
    tokenDebug: tokenData, // <- only for the testing
    propertyDebug: propertyData, // <- only for the testing
    rooms: buildRooms(offersData, propertyData, options),
  }
}

const buildRoomCategory = (config, roomCode) => {
  const categories = config?.rooms?.categories || {}
  return Object.entries(categories).reduce((acc, [key, value]) => {
    return value.codes && Object.values(value.codes).includes(roomCode) ? key : acc
  }, '')
}

const buildCategoryTitle = (classifications, category, language) => {
  const classificationItem = classifications?.items?.find((item) => item.code === category)
  const title = classificationItem?.titles?.find((title) => title.language.toLowerCase() === language.toLowerCase())
  return title?.content && title.content !== '' && title.content
}

const buildClassificationServices = (classifications) =>
  Array.isArray(classifications) &&
  classifications.find((classification) => classification?.code?.toLowerCase() === 'services')

const buildRates = async () => {
  const { data: ratesData, error: ratesError } = await fetchXMLRates(dataSources, options)
  ratesError && console.log(`Rates: ${ratesError}`)
  return ratesData ? ratesData : null
}

const buildImagesizes = (images) => {
  return images.reduce((acc, { url, description, title, width, height, size, category }) => {
    return {
      ...acc,
      [size]: {
        url,
        description,
        title,
        width,
        height,
        size,
        category,
      },
    }
  }, {})
}

const buildImages = (images) => {
  const internal = images.reduce(
    (acc, { url, description, title, width, height, size, category, alternativeSizes }) => {
      const sizes = (alternativeSizes && buildImagesizes(alternativeSizes)) || []
      return [
        ...acc,
        {
          ...sizes,
          url,
          description,
          title,
          width,
          height,
          size,
          category,
        },
      ]
    },
    [],
  )
  const plan = []
  return {
    internal,
    plan,
  }
}

const buildRooms = (rooms, client, options) => {
  const { config, language } = options
  const clientRooms = (client.facility && client.facility.rooms) || []
  const classifications =
    (client.ext && client.ext.classifications && buildClassificationServices(client.ext.classifications)) || []
  return rooms.map(
    ({ available, code, title, description, minOccupancy, maxOccupancy, stdOccupancy, images, basePrice, breakfastPrice, halfBoardPrice }) => {
      const clientRoom = clientRooms.find((clientRoom) => clientRoom.code === code)
      const { size, non_smoking, bed_code, std_num_beds, max_rollaways } = clientRoom.types[0]
      const clientAmenities = clientRoom.amenities || []
      const category = buildRoomCategory(config, code)
      const categoryTitle = buildCategoryTitle(classifications, category, language)
      console.log('====================================================')
      console.log(title)
      console.log({ basePrice })
      console.log({ breakfastPrice })
      console.log({ halfBoardPrice })
      return {
        available,
        title,
        code,
        description,
        size,
        ...((basePrice || breakfastPrice || halfBoardPrice) && {
          prices: {
            ...(basePrice && { basePrice }),
            ...(breakfastPrice && { breakfastPrice }),
            ...(halfBoardPrice && { halfBoardPrice }),
          },
        }),
        ...(category &&
          category !== '' && {
            category: {
              code: category,
              ...(categoryTitle && { title: categoryTitle }),
            },
          }),
        non_smoking,
        occupancy: {
          min: minOccupancy,
          max: maxOccupancy,
          std: stdOccupancy,
          range: `${minOccupancy} - ${maxOccupancy}`,
        },
        beds: {
          std_num: std_num_beds,
          max_rollaways,
          type: {
            code: bed_code,
            name: bedTypes[bed_code] || '',
          },
        },
        amenities: clientAmenities,
        images: buildImages(images),
      }
    },
  )
}

module.exports = resolveSmartBooking

