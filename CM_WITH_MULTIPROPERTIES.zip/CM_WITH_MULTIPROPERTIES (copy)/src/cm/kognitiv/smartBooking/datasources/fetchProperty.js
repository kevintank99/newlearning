const fetchProperty = (dataSources, options) =>
  dataSources[options.provider.toLowerCase()]
  .fetchSmartBookingProperty(options)
  .then((data) => ({ data, error: null }))
  .catch(async(error) => ({ data: null, error: 'ERROR' }))

module.exports = fetchProperty
