const parseString = require('xml2js').parseString

// rates XML to JSON
// TODO: move parsing to a proper place (utils or helpers)
const parseXML = (xml) =>
  new Promise((resolve, reject) => {
    parseString(xml, (err, result) => {
      if (err) {
        reject(err)
      } else {
        resolve(result)
      }
    })
  })

// remove namespacing and sanitize the xml
const cleanXMLRates = (XMLRates) =>
  [
    {
      match: /ota:| xmlns:ota="http:\/\/www.opentravel\.org\/OTA\/2003\/05"| xmlns="http:\/\/www.opentravel.org\/OTA\/2003\/05"|seekda:| xmlns:seekda="http:\/\/connect.seekda.com\/2009\/04"/g,
      replaceWith: '',
    },
    { match: /[\x00-\x08\x0B\x0C\x0E-\x1F\x80-\x9F]/u, replaceWith: '' }, // remove non visible control characters
    { match: /[\xA0]/u, replaceWith: ' ' }, // replace utf8 non breaking space
    { match: /\r?\n/m, replaceWith: ' ' }, // remove newlines
    { match: /[\ts]+/m, replaceWith: ' ' }, // replace tabs and spaces with one space
    { match: /s*&euro;s*/, replaceWith: '&nbsp;€&nbsp;' }, // avoid € breaking to the next line
  ].reduce((acc, rule) => acc.replace(rule.match, rule.replaceWith), XMLRates)

const fetchXMLRates = async (dataSources, options) =>
  await dataSources[options.provider.toLowerCase()]
    .fetchSmartBookingXMLRates(options)
    .then(async (data) => {
      const ratesJSON = await parseXML(cleanXMLRates(data))
      const ratePlans = ratesJSON?.OTA_HotelRatePlanRS?.RatePlans
      return ratePlans ? { data: ratePlans, error: null } : { data: null, error: 'Error parsing rates XML' }
    })
    .catch(async (error) => ({ data: null, error }))

module.exports = fetchXMLRates
