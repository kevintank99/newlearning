const fetchToken = require('./fetchToken')
const { defaults } = require('../constants')

const dateDate = (d) => d.getDate()
const dateYear = (d) => d.getFullYear()
const dateMonth = (d) => d.getMonth()
const dateCreate = (yyyy, mm, dd) => new Date(yyyy, mm, dd, 0, 0, 0, 0, 0) //time value is always reset to 00:00
const dateClone = (d) => dateCreate(dateYear(d), dateMonth(d), dateDate(d))
const dateToday = () => dateClone(new Date) //impure - result depends on current date

const setOptionsDefaults = (options) => ({
  ...options,
  startDate: options.startDate ? options.startDate : dateToday(), //start date falls back to current day
  numberOfDays: options.config.numberOfDays ? options.config.numberOfDays : defaults.numberOfDays, //number of days are only saved in the config and not passed as parameter
})

// need token for ratesavarage/rooms, in case the provided one is expired fetch a new one
const fetchRoomsAndPackages = async (dataSources, options, refetch = true) =>
  await dataSources[options.provider.toLowerCase()]
    .fetchRates(setOptionsDefaults(options))
    .then((data) => {
        return data.result
          ? {
            data: {
              rooms: data.result.rooms ? data.result.rooms : [],
              packages: data.result.packages ? data.result.packages : [],
            },
            error: null,
            accessToken: options.accessToken,
          }
          : { data: null, error: 'ERROR' }
      },
    )
    .catch(async (error) => {
      if (error.extensions && error.extensions.response && error.extensions.response.status === 403 && refetch) {
        const accessToken = await fetchToken(dataSources, options)
        return await fetchRoomsAndPackages(dataSources, { ...options, accessToken }, false)
      }
      return { data: null, error }
    })

module.exports = fetchRoomsAndPackages
