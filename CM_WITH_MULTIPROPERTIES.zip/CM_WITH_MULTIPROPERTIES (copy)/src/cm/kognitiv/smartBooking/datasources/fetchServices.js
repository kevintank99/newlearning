const { defaults } = require('../constants')

const dateDate = (d) => d.getDate()
const dateYear = (d) => d.getFullYear()
const dateMonth = (d) => d.getMonth()
const dateCreate = (yyyy, mm, dd) => new Date(yyyy, mm, dd, 0, 0, 0, 0, 0) //time value is always reset to 00:00
const dateClone = (d) => dateCreate(dateYear(d), dateMonth(d), dateDate(d))
const dateToday = () => dateClone(new Date()) //impure - result depends on current date

const formatDate = (d) => d.toISOString().substring(0, 10)

const setOptionsDefaults = (options) => ({
  ...options,
  currency: options.currency ? options.currency : defaults.currency,
  startDate: options.startDate ? options.startDate : formatDate(dateToday()), //start date falls back to current day
  endDate: options.endDate
    ? options.endDate
    : formatDate(new Date(new Date().getTime() + defaults.numberOfDays * 24 * 60 * 60 * 1000)),
})

const fetchServices = async (dataSources, options) =>
  await dataSources[options.provider.toLowerCase()]
    .fetchSmartBookingServices(setOptionsDefaults(options))
    .then(async (data) => {
      if (data?.result) {
        const res = data.result
        const services = res?.services.reduce((acc, service) => {

        }, [])
        return { data: res, error: null }
      } else return { data: null, error: 'Error fetching services' }
    })
    .catch(async (error) => ({ data: null, error }))

module.exports = fetchServices

