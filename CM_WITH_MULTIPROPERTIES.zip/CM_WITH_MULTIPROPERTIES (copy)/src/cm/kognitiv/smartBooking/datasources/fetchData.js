const { fetchRoomsAndPackages } = require('./fetchRoomsAndPackages')
const { fetchProperty } = require('./fetchProperty')
const { fetchXMLRates } = require('./fetchXMLRates')

const fetchData = ({}) => {

  // Fetch data from the datasource (eg. Kognitiv)
  const [{
      data: { rooms, packages },
      error: roomsError,
      accessToken,
    },
    { data: client, error: clientError },
    { data: rates, error: ratesError },
  ] = await Promise.all([
    fetchRoomsAndPackages(dataSources, options),
    fetchProperty(dataSources, options),
    fetchXMLRates(dataSources, options),
  ])

  // rates XML to JSON
  const ratesJSON = await getRates(rates)
  const ratePlans = ratesJSON && ratesJSON.OTA_HotelRatePlanRS && ratesJSON.OTA_HotelRatePlanRS.RatePlans

  // return resolved client object to GraphQL (all values are typed in the schema)
  return {
    config: ratePlans, // <- only for the testing
    hotelId: client.hotelId,
    accessToken: accessToken || options.accessToken,
    startDate: options.startDate,
    days: options.days,
    test: ratePlans[0].RatePlan[0]['$'].RatePlanCode, // <- only for the testing
    rooms: getRooms(rooms, client, options),
    seasons: getSeasons(client, options),
  }
}


module.exports = fetchData