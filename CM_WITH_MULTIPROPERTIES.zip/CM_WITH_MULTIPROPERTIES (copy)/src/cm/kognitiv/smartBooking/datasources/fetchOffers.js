const { defaults } = require('../constants')

const dateDate = (d) => d.getDate()
const dateYear = (d) => d.getFullYear()
const dateMonth = (d) => d.getMonth()
const dateCreate = (yyyy, mm, dd) => new Date(yyyy, mm, dd, 0, 0, 0, 0, 0) //time value is always reset to 00:00
const dateClone = (d) => dateCreate(dateYear(d), dateMonth(d), dateDate(d))
const dateToday = () => dateClone(new Date()) //impure - result depends on current date
const formatDate = (d) => d.toISOString().substring(0, 10)

const setOptionsDefaults = (options) => ({
  ...options,
  currency: options.currency ? options.currency : defaults.currency,
  checkin: options.checkin ? options.checkin : formatDate(dateToday()), //start date falls back to current day
  checkout: options.checkout ? options.checkout : formatDate(new Date(new Date().getTime() + 7 * 24 * 60 * 60 * 1000)),
})

const fetchOffers = async (dataSources, options) => {
  const { hotelId } = options
  const excludedRooms = options.exclude || []
  return await dataSources[options.provider.toLowerCase()]
    .fetchSmartBookingOffers(setOptionsDefaults(options))
    .then(async (data) => {
      if (data?.result?.[hotelId]) {
        const res = data.result[hotelId]
        const ratesBasePrice =
          res.metadata?.rates?.reduce((acc, rate) => {
            return rate.meal_plan_code === null && rate.type !== 'Package' ? [...acc, rate] : acc
          }, []) || []
        const ratesBreakfastPrice =
          res.metadata?.rates?.reduce((acc, rate) => {
            return rate.meal_plan_code === '11' && rate.type !== 'Package' ? [...acc, rate] : acc
          }, []) || []
        const ratesHalfBoardPrice =
          res.metadata?.rates?.reduce((acc, rate) => {
            return rate.meal_plan_code === '12' && rate.type !== 'Package' ? [...acc, rate] : acc
          }, []) || []
        const roomOffersFlat = res.room_offers?.flat(1) || []
        const findPrice = (room) => room.items.find((item) => item.code === room.primary_item_code)
        const availableRooms = roomOffersFlat.reduce((acc, room) => {
          const basePrice = ratesBasePrice.find((roomRate) => {
            return room.items.some((item) => item.code === roomRate.code && item.code === room.primary_item_code)
          })
          const breakfastPrice = ratesBreakfastPrice.find((roomRate) =>
            room.items.some((item) => item.code === roomRate.code && item.code === room.primary_item_code),
          )
          const halfBoardPrice = ratesHalfBoardPrice.find((roomRate) =>
            room.items.some((item) => item.code === roomRate.code && item.code === room.primary_item_code),
          )
          if (basePrice || breakfastPrice || halfBoardPrice) {
            return {
              ...acc,
              [room.room_code]: {
                ...acc[room.room_code],
                ...(basePrice && { basePrice: findPrice(room).price }),
                ...(breakfastPrice && { breakfastPrice: findPrice(room).price }),
                ...(halfBoardPrice && { halfBoardPrice: findPrice(room).price }),
              },
            }
          } else return acc
        }, {})
        const rooms = res.metadata?.rooms.reduce((acc, room) => {
          return availableRooms[room.code]
            ? !excludedRooms.some((exludedRoom) => exludedRoom === room.code)
              ? [...acc, { ...room, ...availableRooms[room.code], available: true }]
              : acc
            : !excludedRooms.some((exludedRoom) => exludedRoom === room.code)
            ? [...acc, { ...room, available: false }]
            : acc
        }, [])
        return { data: rooms, error: null }
      } else {
        return { data: null, error: 'Error fetching offers' }
      }
    })
    .catch(async (error) => {
      return { data: null, error }
    })
}

module.exports = fetchOffers
