const fetchProperty = (dataSources, options) =>
  dataSources[options.provider.toLowerCase()]
    .fetchProperty(options)
    .then((data) =>
      data?.errors?.length
        ? { data: null, error: data.errors }
        : {
            data: {
              hotelCode: options.hotelId,
              language: options.language,
              userId: options.userId,
              lastUpdated: Date.now(),
              ...data,
            },
            error: null,
          },
    )
    .catch(async (error) => ({ data: null, error: 'ERROR' }))

module.exports = fetchProperty
