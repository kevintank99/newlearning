const { defaults } = require('../constants')
const { dateToday, dateIsoFormat, dateDiffDaysAfterTimeRange } = require('../../../utils/date')
const { isObject } = require('../../../utils/type')
const setOptionsDefaults = (options) => ({
  ...options,
  startDate: options.config.startDate ? options.config.startDate : dateIsoFormat(dateToday()),
  overviewLength: options.config.timerange
    ? dateDiffDaysAfterTimeRange(options.config.timerange)
    : defaults.numberOfDays,
  overviewType: options.config.overviewType ? options.config.overviewType : 'rate', //default the overviewType to "rate" instead of kognitiv default "room"
  promotionCode:
    options.config.promotioncodes &&
    isObject(options.config.promotioncodes) &&
    Object.values(options.config.promotioncodes).join(','),
})

const fetchOffersOverview = async (dataSources, options) =>
  await dataSources[options.provider.toLowerCase()]
    .fetchOffersOverview(setOptionsDefaults(options))
    .then(async (data) => {
      return data?.errors?.length
        ? { data: null, error: data.errors }
        : {
            data: {
              hotelCode: options.hotelId,
              userId: options.userId,
              language: options.language,
              lastUpdated: Date.now(),
              ...data,
            },
            error: null,
          }
    })
    .catch(async (error) => {
      return { data: null, error }
    })

module.exports = fetchOffersOverview
