const { isObject } = require('../../../utils/type')
const { defaults } = require('../constants')

const dateDate = (d) => d.getDate()
const dateYear = (d) => d.getFullYear()
const dateMonth = (d) => d.getMonth()
const dateCreate = (yyyy, mm, dd) => new Date(yyyy, mm, dd, 0, 0, 0, 0, 0) //time value is always reset to 00:00
const dateClone = (d) => dateCreate(dateYear(d), dateMonth(d), dateDate(d))
const dateToday = () => dateClone(new Date()) //impure - result depends on current date

const formatDate = (d) => d.toISOString().substring(0, 10)

const setOptionsDefaults = (options) => ({
  ...options,
  months: options.config.numberOfMonths ? options.config.numberOfMonths : defaults.numberOfMonths,
  channelId: options.config.channelId ? options.config.channelId : 'ibe', //default channel in constant is 'MTS' but here we will use 'ibe'
  promotionCode:
    options.config.promotioncodes &&
    isObject(options.config.promotioncodes) &&
    Object.values(options.config.promotioncodes).join(','),
  filterByPrice: "false",
})

const fetchRatesAvarage = async (dataSources, options) =>
  await dataSources[options.provider.toLowerCase()]
    .fetchRatesAverage(setOptionsDefaults(options))
    .then(async (data) => {
      return data?.errors?.length
        ? { data: null, error: data.errors }
        : {
            data: {
              hotelCode: options.hotelId,
              userId: options.userId,
              language: options.language,
              lastUpdated: Date.now(),
              ...data.result,
            },
            error: null,
          }
    })
    .catch(async (error) => {
      console.log('fetchRatesAverage ERROR', error)
      return { data: null, error }
    })

module.exports = fetchRatesAvarage
