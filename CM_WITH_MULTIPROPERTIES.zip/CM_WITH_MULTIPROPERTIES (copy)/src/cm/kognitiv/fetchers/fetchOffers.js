const fetchOffers = (dataSources, options) =>
  dataSources[options.provider.toLowerCase()]
    .fetchOffers(options)
    .then((data) => (data?.errors?.length ? { data: null, error: data.errors } : { data, error: null }))
    .catch(async (error) => ({ data: null, error: error }))

module.exports = fetchOffers
