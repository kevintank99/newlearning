const parseXML = require('../../../utils/xml').parseXML
const cleanKognitivXML = require('../../../utils/xml').cleanKognitivXML
const { dateIsoFormat, dateFrom } = require('../../../utils/date')
const { isStringValue } = require('../../../utils/type')

const setOptions = (params, options) => {
  isStringValue(params.start) && (options.startDate = dateIsoFormat(dateFrom(params.start)))
  isStringValue(params.end) && (options.endDate = dateIsoFormat(dateFrom(params.end)))
  isStringValue(params.id) && (options.reservationId = params.id)
  isStringValue(params.pin) && (options.reservationPin = params.pin)
  return options
}
const fetchXMLBookings = async (dataSources, params) => {
  return await dataSources[params.provider.toLowerCase()]
    .fetchXMLBookings({ ...params, ...setOptions(params, {}) })
    .then(async (data) => {
      const bookingsJSON = await parseXML(cleanKognitivXML(data))
      const xmlError = bookingsJSON?.OTA_ResRetrieveRS?.Errors
      //TODO: write better error parsing, throw error, logging/telegram?
      const xmlBookings = bookingsJSON?.OTA_ResRetrieveRS?.ReservationsList
      return xmlError
        ? { data: null, error: xmlError[0]?.Error[0]?._ }
        : xmlBookings
        ? { data: xmlBookings[0].HotelReservation, error: null }
        : { data: null, error: 'Error parsing bookings XML' }
    })
    .catch(async (error) => ({ data: null, error }))
}
module.exports = fetchXMLBookings
