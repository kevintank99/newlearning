const parseXML = require('../../../utils/xml').parseXML
const cleanKognitivXML = require('../../../utils/xml').cleanKognitivXML

const fetchXMLServices = async (dataSources, options) =>
  await dataSources[options.provider.toLowerCase()]
    .fetchXMLServices(options)
    .then(async (data) => {
      const servicesJSON = await parseXML(cleanKognitivXML(data))
      const services = servicesJSON?.ServiceReadRS?.Services
        ? servicesJSON.ServiceReadRS.Services
        : servicesJSON?.ServiceReadRS?.Success
        ? []
        : false
      const servicesError = servicesJSON?.ServiceReadRS?.Errors
      return services
        ? { data: services, error: null }
        : servicesError
        ? { data: null, error: servicesError }
        : { data: null, error: 'Error parsing services XML' }
    })
    .catch(async (error) => ({ data: null, error }))

module.exports = fetchXMLServices
