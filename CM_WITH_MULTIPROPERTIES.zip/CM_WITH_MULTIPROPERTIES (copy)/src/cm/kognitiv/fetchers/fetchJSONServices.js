const { dateToday, dateAddDays, dateIsoFormat } = require('../../../utils/date')
const { defaults } = require('../constants')

const setOptions = (options) => {
  options.startDate = options?.config?.startDate || dateIsoFormat(dateToday())
  options.endDate = options?.config?.endDate || dateIsoFormat(dateAddDays(365, dateToday()))
  options.currency = options?.config?.currency || defaults.currency
  options.meta = options?.config?.meta || false
  return options
}

const fetchJSONServices = async (dataSources, options) =>
  await dataSources[options.provider.toLowerCase()]
    .fetchServices(setOptions(options))
    .then((data) =>
      data?.errors?.length
        ? { data: null, error: data.errors }
        : {
            data: {
              hotelCode: options.hotelId,
              userId: options.userId,
              language: options.language,
              lastUpdated: Date.now(),
              ...data.result,
            },
            error: null,
          },
    )
    .catch(async (error) => ({ data: null, error: error }))

module.exports = fetchJSONServices
