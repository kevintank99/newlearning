const { defaults } = require('../constants')

const dateDate = (d) => d.getDate()
const dateYear = (d) => d.getFullYear()
const dateMonth = (d) => d.getMonth()
const dateCreate = (yyyy, mm, dd) => new Date(yyyy, mm, dd, 0, 0, 0, 0, 0) //time value is always reset to 00:00
const dateClone = (d) => dateCreate(dateYear(d), dateMonth(d), dateDate(d))
const dateToday = () => dateClone(new Date()) //impure - result depends on current date

const formatDate = (d) => d.toISOString().substring(0, 10)

const setOptionsDefaults = (options) => ({
  ...options,
  startDate: options?.config?.startDate ? options.config.startDate : formatDate(dateToday()), //start date falls back to current day
  numberOfDays: options?.config?.numberOfDays ? options.config.numberOfDays : defaults.timePeriod, //number of days are only saved in the config and not passed as parameter
})

const fetchBookability = async (dataSources, options) =>
  await dataSources[options.provider.toLowerCase()]
    .fetchBookability(setOptionsDefaults(options))
    .then(async (data) => {
      return data?.errors?.length
        ? { data: null, error: data.errors }
        : {
            data: { hotelCode: options.hotelId, userId: options.userId, lastUpdated: Date.now(), ...data.data },
            error: null,
          }
    })
    .catch(async (error) => ({ data: null, error }))

module.exports = fetchBookability
