const fetchToken = async (dataSources, options) =>
  await dataSources[options.provider.toLowerCase()]
    .fetchToken(options)
    .then((token) => ({ data: token?.access_token, error: null }))
    .catch((error) => ({ data: null, error }))

module.exports = fetchToken
