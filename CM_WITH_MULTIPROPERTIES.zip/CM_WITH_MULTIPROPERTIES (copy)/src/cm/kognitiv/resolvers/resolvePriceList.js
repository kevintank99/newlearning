const { isStringValue, isObject } = require('../../../utils/type')
const { dateToday, dateDiffDays, dateFrom } = require('../../../utils/date')
const { DEFAULT_MEALPLANCODE, roomTypes } = require('../constants')
const { resolveRates } = require('./resolveRates')
const generateCacheKey = require('../../../cache/L1Cache/generateCacheKey')

const setOptions = (params) => {
  let options = {}
  options.checkin = isStringValue(params.start) ? params.start : dateToday()
  options.checkout = isStringValue(params.end) ? params.end : dateToday()
  options.roomCodes = isStringValue(params.roomCode) ? params.roomCode : ''
  options.rooms = [
    {
      adults: params.adults,
      children: params.children,
    },
  ]
  // options.promotionCode = isStringValue(params.promotionCode) ? params.promotionCode : ''
  return options
}

function resolveOccupancy(roomDetails) {
  return {
    min: roomDetails?.min_occup,
    max: roomDetails?.max_occup,
    standard: roomDetails?.types?.[0]?.std_occup,
  }
}

function resolveMinMaxDayRateAdults(dayRates, occupancy, params, ratecode, configPrices, roomcode) {
  const minOccup = parseInt(occupancy.min)
  const maxOccup = parseInt(occupancy.max)
  const stdOccup = parseInt(occupancy.standard)

  // min adult price for all occupancy
  let minRateRange = {}
  let maxRateRange = {}

  let dayRateForAllOcc = {}
  for(let i = minOccup; i <= maxOccup; i++) {
    const dayRateArr = dayRates.reduce((acc, dRate, inx) => {
      if(parseInt(dRate?.availability) > 0 || dRate?.availability == null) { // check availability
        if(!dRate?.adults?.[i] &&  i <= stdOccup) {
          let prevOcc = i - 1
          if(dRate?.adults?.[prevOcc]) {
            let dayPrice = dRate?.adults?.[prevOcc] + (i - parseInt(prevOcc)) * dRate?.adults?.additional
            if(!isNaN(dayPrice)) {
              acc.push(dayPrice)
            }
          }
        } else if(dRate?.adults?.[i] && i <= stdOccup) { // set the price for occupancy < std
          let prevRates = []
          for(let j = minOccup; j < i; j++) {
            prevRates.push(dRate?.adults?.[j])
          }
          if(prevRates.every(ele => ele === null || ele === undefined) && prevRates.length > 0) {
            for(let j = minOccup; j < i; j++) { // set prices for previous all nulls
              dayRateForAllOcc[j][inx] = dRate?.adults?.[i]
            }
          }
          acc.push(dRate?.adults?.[i])
        } else if(dRate?.adults?.additional && dayRateForAllOcc[stdOccup][inx] && i > stdOccup) { // set the price for occupancy > std
          acc.push(dayRateForAllOcc[stdOccup][inx] + (i - parseInt(stdOccup)) * dRate?.adults?.additional)
        }
      }
      return acc
    }, [])
    dayRateForAllOcc[i] = dayRateArr
  }

  for(let i = minOccup; i <= maxOccup; i++) {
    const minRateForOcc = (dayRateForAllOcc[i].length > 0) ? Math.min.apply(this, dayRateForAllOcc[i]) : null
    const maxRateForOcc = (dayRateForAllOcc[i].length > 0) ? Math.max.apply(this, dayRateForAllOcc[i]) : null
    if(minRateForOcc != null) {
      minRateRange[i] = minRateForOcc
    }
    if(maxRateForOcc != null) {
      maxRateRange[i] = maxRateForOcc
    }
  }

  const dayRateStdArr = dayRates.reduce((acc, dRate) => {
    if(dRate?.adults?.[stdOccup]) {
      acc.push(dRate?.adults?.[stdOccup])
    }
    return acc
  }, [])

  // min adult price for std occupancy
  let minAdultRateForStdOccu = (dayRateForAllOcc[stdOccup].length > 0) ? Math.min.apply(this, dayRateForAllOcc[stdOccup]) : null
  let maxAdultRateForStdOccu = (dayRateForAllOcc[stdOccup].length > 0) ? Math.max.apply(this, dayRateForAllOcc[stdOccup]) : null

  // get prices from user config
  if(params?.useConfig) {
    minAdultRateForStdOccu = configPrices?.[roomcode]?.min?.std ?? null
    maxAdultRateForStdOccu = configPrices?.[roomcode]?.max?.std ?? null
  }

  const priceSingleMin = (minAdultRateForStdOccu) ? (minAdultRateForStdOccu / stdOccup).toFixed(2) * 1 : null
  const priceSingleMax = (maxAdultRateForStdOccu) ? (maxAdultRateForStdOccu / stdOccup).toFixed(2) * 1 : null

  return {
    min: {
      amount: (params?.pricetype == 'SINGLE') ? priceSingleMin : minAdultRateForStdOccu,
      single: priceSingleMin,
      std: minAdultRateForStdOccu,
      guests: stdOccup,
      rate: minRateRange
    },
    max: {
      amount: (params?.pricetype == 'SINGLE') ? priceSingleMax : maxAdultRateForStdOccu,
      single: priceSingleMax,
      std: maxAdultRateForStdOccu,
      guests: stdOccup,
      rate: maxRateRange
    }
  }
}

function resolveMinMaxRateChildren(dayRates, ratecode) {
  const childRates = dayRates.reduce((acc, dRate) => {
    if(dRate?.children) {
      Object.entries(dRate?.children)?.forEach(([ageRange, price]) => {
        if(!acc[ageRange]) {
          acc[ageRange] = []
        }
        acc[ageRange].push(price)
      })
    }
    return acc
  }, {})

  const minPriceChildren = {}
  const maxPriceChildren = {}
  for(let key in childRates) {
    minPriceChildren[key] = Math.min(...childRates[key])
    maxPriceChildren[key] = Math.max(...childRates[key])
  }
  
  return {
    min: minPriceChildren,
    max: maxPriceChildren
  }
}

function resolveRatePrices(dayRates, occupancy, params, ratecode, configPrices, roomcode) {
  return {
    adults: {
      ...resolveMinMaxDayRateAdults(dayRates, occupancy, params, ratecode, configPrices, roomcode)
    },
    children: resolveMinMaxRateChildren(dayRates, ratecode)
  }
}

function resolveRatePlans(ratesData, occupancy, params, roomcode, ratesAverage) {
  const ratesOffersPrices = { rateplans: [], offers: [] }
  Object.entries(ratesData)?.forEach(([ratecode, rateplan]) => {
    let onSale = false;
    for (let i = 0;i < rateplan?.dayRates.length ;i++) {
      if (rateplan?.dayRates[i] !== null) {
        let minStay = parseInt(rateplan?.dayRates[i]?.minstay)
        let tempArr = rateplan?.dayRates.slice(i, i + minStay)
        const checkAvailForStay = tempArr.every((avail) => avail?.['availability'] && parseInt(avail['availability']) > 0)
        if(checkAvailForStay) {
          onSale = true
          break
        }
      }
    }
    let rateObj = {
      code: ratecode,
      ratePlanType: rateplan?.ratePlanType,
      mealplancode: rateplan?.mealPlanCode,
      price: resolveRatePrices(rateplan?.dayRates, occupancy, params, ratecode, params?.config?.rooms?.price, roomcode),
      onSale
    }
    if(rateplan?.ratePlanType == '5') {
      // rates from ratesAverage API
      const ratedataFromsAverage = ratesAverage.rooms.find((roomdata) => roomdata.code == roomcode)?.rates?.find((ratedata) => ratedata.code == ratecode)
      rateObj.title = ratedataFromsAverage?.title
      rateObj.description = ratedataFromsAverage?.description
      ratesOffersPrices.rateplans.push(rateObj)
    } else {
      // packages from ratesAverage API
      const offerdataFromsAverage = ratesAverage.packages.find((roomdata) => roomdata.code)
      rateObj.title = offerdataFromsAverage?.title
      rateObj.description = offerdataFromsAverage?.description
      ratesOffersPrices.offers.push(rateObj)
    }
  })
  return ratesOffersPrices
}

function resolveRoomPrices(ratePlansPrices, occupancy) {
  let roomPrices = {
    adults: { min: {}, max: {} },
    children: { min: {},  max: {} }
  }

  ratePlansPrices?.forEach(({ price }, index) => {
    const adultMin = price.adults.min
    const adultMax = price.adults.max
    const childrenMin = price.children.min
    const childrenMax = price.children.max
    if(index == 0) {
      roomPrices.adults = { ...price?.adults }
      roomPrices.children = { ...price?.children }
    } else {
      roomPrices.adults.min = {
        amount: adultMin?.amount ? Math.min(adultMin?.amount, roomPrices.adults.min?.amount) : adultMin?.amount,
        single: adultMin?.single ? Math.min(adultMin?.single, roomPrices.adults.min?.single) : adultMin?.single,
        std: adultMin?.std ? Math.min(adultMin?.std, roomPrices.adults.min?.std) : adultMin?.std,
        rate: {...roomPrices.adults.min.rate},
        guests: parseInt(occupancy.standard)
      }
      roomPrices.adults.max = {
        amount: adultMax?.amount ? Math.max(adultMax?.amount, roomPrices.adults.max?.amount) : adultMin?.amount,
        single: adultMax?.single ? Math.max(adultMax?.single, roomPrices.adults.max?.single) : adultMin?.single,
        std: adultMax?.std ? Math.max(adultMax?.std, roomPrices.adults.max?.std) : adultMin?.std,
        rate: {...roomPrices.adults.max.rate},
        guests: parseInt(occupancy.standard)
      }
      for(let key in adultMin?.rate) {
        roomPrices.adults.min.rate[key] = Math.min(roomPrices.adults.min.rate?.[key], adultMin.rate?.[key])
        roomPrices.adults.max.rate[key] = Math.max(roomPrices.adults.max.rate?.[key], adultMax.rate?.[key])
      }
      for(let key in childrenMin) {
        roomPrices.children.min = {
          ...roomPrices.children.min,
          [key]: Math.min(roomPrices.children.min?.[key], childrenMin[key])
        }
        roomPrices.children.max = {
          ...roomPrices.children.max,
          [key]: Math.max(roomPrices.children.max?.[key], childrenMax[key])
        }
      }
    }
  })
  return roomPrices
}

// resolver for internal call
const resolvePriceList = async ({ dataSources, db }, { property, token }, params, {dayPrice, ratesAvg} = {}) => {
  let ratesAverage, rates;
  if (dayPrice && isObject(dayPrice) && ratesAvg && isObject(ratesAvg)) {
    [rates,ratesAverage] = [dayPrice, ratesAvg]
  } else {
    [ratesAverage, rates] = await Promise.all([
     db.findOne('ratesaverage', {
       userId: params.userId,
       hotelCode: params.hotelId,
       language: params.language,
     }),
     resolveRates({ db }, { property }, params),
   ])
  }
  
  // filter rates based on promotion codes
  let promotionCodes = (params?.promotionCodes) ? params?.promotionCodes?.split(',') : []
  for(let roomcode in rates) {
    var results = Object.keys(rates[roomcode]).reduce(function(acc, ratecode) {
      if(promotionCodes.includes(rates[roomcode][ratecode]?.promotionCode) || !rates[roomcode][ratecode]?.promotionCode) {
        acc[ratecode] = rates[roomcode][ratecode]
      }
      return acc;
    }, {});
    rates[roomcode] = results
  }

  const roomCodeToRoomDetails = property.facility?.rooms?.reduce((acc, room) => {
    acc[room.code] = room
    return acc
  }, {})

  const roomsJson = []
  Object.entries(rates).forEach(([roomcode, ratesData]) => {
    const occupancy = resolveOccupancy(roomCodeToRoomDetails[roomcode])
    const ratePlansPrices = resolveRatePlans(ratesData, occupancy, params, roomcode, ratesAverage)
    // combined price summary based on mergeType
    let allRateplans = [...ratePlansPrices.rateplans]
    if(params?.mergeType == 'OFFERS') {
      allRateplans = [...ratePlansPrices.offers]
    } else if(params?.mergeType == 'RATEPLANS_AND_OFFERS') {
      allRateplans = [...ratePlansPrices.rateplans, ...ratePlansPrices.offers]
    }
    const roomPrices = resolveRoomPrices(allRateplans, occupancy)
    let roomObj = {
      roomcode,
      ...ratePlansPrices,
      price: {
        type: (params?.pricetype == 'SINGLE') ? 'single' : 'standard',
        ...roomPrices
      },
    }
    roomsJson.push(roomObj)
  })

  return roomsJson
}

//resolver for dynamic call
const priceListResolver = async (parent, params, context, info) => {
  const { cache, ttl } = context
  const { userId, provider, language } = parent.params.options
  const key = generateCacheKey('pricelists', params, userId, provider, language)
  const cacheHit = await cache?.get(key)
  if (cacheHit) {
    return JSON.parse(cacheHit)
  } else {
    const cacheableValue = await resolvePriceList(context, parent.params, { ...parent.params.options, ...params })
    cache?.setEx(key, ttl, JSON.stringify(cacheableValue))
    return cacheableValue
  }
}

// //resolver for dynamic call
// const priceListResolver = async (parent, params, context, info) => {
//   return resolvePriceList(context, parent.params, { ...parent.params.options, ...params })
// }

module.exports = {
  priceListResolver, //dynamic call
  resolvePriceList, //internal call
}