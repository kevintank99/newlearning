const generateCacheKey = require('../../../cache/L1Cache/generateCacheKey')
const convertToDaysString = require('../../../utils/convertToDaysString')
const { strSplit } = require('../../../utils/string')
const {
  decodeStrings: {
    DECRYPT_RESTRICTIONS,
    DECRYPT_RESTRICTIONS_MAX_LOS,
    DECRYPT_RESTRICTIONS_MIN_STAY_THRU,
    DECRYPT_RESTRICTIONS_MAX_STAY_THRU,
  },
  DEFAULT_MEALPLANCODE,
} = require('../constants')
const queryOffersOverview = require('../queriers/queryOffersOverview')
const queryRatesAverage = require('../queriers/queryRatesAverage')
const { resolveRates } = require('./resolveRates')

const stringDecoder = async (string, arrayFromXML, decodeMap) => {
  const arr = string.split('')
  return arr.map((a, idx) => {
    if (a.charCodeAt() >= 97 && a.charCodeAt() <= 122) {
      return arrayFromXML?.[idx]
    } else {
      return decodeMap[a]
    }
  })
}

const resolvePrices = (rates, priceType, std_occup) => {
  return rates
    .map((rate) => {
      if (rate?.adults?.[std_occup]) {
        return priceType === 'SINGLE' ? rate.adults[std_occup] / std_occup : rate.adults[std_occup]
      } else if (rate?.adults && rate.adults?.additional) {
        const maxAdultCount = Math.max(...Object.keys(rate.adults).filter((p) => !isNaN(p)))
        const total = rate.adults[maxAdultCount.toString()] + (std_occup - maxAdultCount) * rate.adults.additional
        return priceType === 'SINGLE' ? total / std_occup : total
      } else {
        return null
      }
    })
    .join('|')
}

/**
 * Resolves offersOverview data and extracts only useful data from it
 * @param {Object} offersOverview
 * @param {String} language
 * @param {String} roomCode
 * @param {Array} rooms
 * @param {Array} offers
 * @returns {object}
 */
const resolveRateplansAndOffers = async (
  offersOverview,
  { language, priceType = 'STD', roomCode = '', ...params },
  rooms,
  offers,
  ratesXML,
) => {
  const rates = {}
  const roomCodes = roomCode.split(',')
  const promotionCodes = params?.promotionCodes ? strSplit(',', params.promotionCodes) : []

  const rateTitleToRoomsMap = rooms.reduce((acc, room) => {
    if (!acc[room.code]) {
      acc[room.code] = {}
    }
    room.rates.forEach((rate) => {
      if (!acc[room.code][rate.code]) {
        acc[room.code][rate.code] = {
          title: rate.title,
          description: rate.description
        }
      }
    })
    return acc
  }, {})

  const offerTitleToCodeMap = offers.reduce((acc, offer) => {
    if (!acc[offer.code]) {
      acc[offer.code] = {
        title: offer.title,
        description: offer.description
      }
    }
    return acc
  }, {})

  for (let rate of offersOverview.overview.entities) {
    const rateOfXML = ratesXML?.[rate['room_code']]?.[rate['rate_code']]

    if (!rateOfXML || (rateOfXML.promotionCode && !promotionCodes.includes(rateOfXML.promotionCode))) {
      continue
    }
    if (rateOfXML && (!roomCode || roomCodes.includes(rate['room_code']))) {
      const stringsFromXML = rateOfXML.dayRates.reduce(
        (acc, cur, idx) => {
          acc.minstay[idx] = cur?.minstay || '-'
          acc.maxstay[idx] = cur?.maxstay || '-'
          acc.minstaythru[idx] = cur?.minstaythru || '-'
          acc.maxstaythru[idx] = cur?.maxstaythru || '-'
          return acc
        },
        {
          minstay: Array(rateOfXML.dayRates.length),
          maxstay: Array(rateOfXML.dayRates.length),
          minstaythru: Array(rateOfXML.dayRates.length),
          maxstaythru: Array(rateOfXML.dayRates.length),
        },
      )

      const [days, min_los, min_stay_thru, max_los, max_stay_thru] = await Promise.all([
        convertToDaysString(rate.restrictions, stringsFromXML),
        stringDecoder(rate.restrictions, stringsFromXML.minstay, DECRYPT_RESTRICTIONS),
        stringDecoder(rate.restrictions_min_stay_thru, stringsFromXML.minstaythru, DECRYPT_RESTRICTIONS_MIN_STAY_THRU),
        stringDecoder(rate.restrictions_max_los, stringsFromXML.maxstay, DECRYPT_RESTRICTIONS_MAX_LOS),
        stringDecoder(rate.restrictions_max_stay_thru, stringsFromXML.maxstaythru, DECRYPT_RESTRICTIONS_MAX_STAY_THRU),
      ])

      const rateplanObj = {
        room_code: rate['room_code'],
        rate_code: rate['rate_code'],
        isPackage: rate['isPackage'],
        title: rate['isPackage']
          ? offerTitleToCodeMap?.[rate['rate_code']]?.title
          : rateTitleToRoomsMap?.[rate['room_code']]?.[rate['rate_code']]?.title,
        description: rate['isPackage']	
          ? offerTitleToCodeMap?.[rate['rate_code']]?.description	
          : rateTitleToRoomsMap?.[rate['room_code']]?.[rate['rate_code']]?.description,
        meal_plan_code: rate['meal_plan_code'] || DEFAULT_MEALPLANCODE,
        availabilities: rate.availabilities.join('|'),
        days: days.join('|'),
        min_los: min_los.join('|'),
        min_stay_thru: min_stay_thru.join('|'),
        max_los: max_los.join('|'),
        max_stay_thru: max_stay_thru.join('|'),
        closed_to: rate.changeOver,
        prices: resolvePrices(rateOfXML.dayRates, priceType, rate['std_occupancy']),
      }

      if (!rates[rate['room_code']]) {
        rates[rate['room_code']] = {
          roomCode: rate['room_code'],
          rateplans: rateplanObj.isPackage ? [] : [rateplanObj],
          offers: rateplanObj.isPackage ? [rateplanObj] : [],
        }
      } else {
        if (rateplanObj.isPackage) {
          rates[rate['room_code']].offers.push(rateplanObj)
        } else {
          rates[rate['room_code']].rateplans.push(rateplanObj)
        }
      }
    }
  }

  return Object.values(rates || {})
}

const resolveOverview = async ({ dataSources, db }, { property, token }, params) => {
  const [ratesAverage, offersOverview, ratesXML] = await Promise.all([
    queryRatesAverage(db, params.config, params.language),
    queryOffersOverview(db, params.config, params.language),
    resolveRates({ db }, { property }, params),
  ])

  return resolveRateplansAndOffers(offersOverview, params, ratesAverage.rooms, ratesAverage.packages, ratesXML)
}

//resolver for dynamic call
const overviewResolver = async (parent, params, context, info) => {
  const { cache, ttl } = context
  const { userId, provider, language } = parent.params.options
  const key = generateCacheKey('overview', params, userId, provider, language)
  const cacheHit = await cache?.get(key)
  if (cacheHit) {
    return JSON.parse(cacheHit)
  } else {
    const cacheableValue = await resolveOverview(context, parent.params, { ...parent.params.options, ...params })
    cache?.setEx(key, ttl, JSON.stringify(cacheableValue))
    return cacheableValue
  }
}

module.exports = {
  overviewResolver, //dynamic call
  resolveOverview, //internal call
}
