const { dateAddDays, dateIsoFormat, dateToday, dateFrom } = require('../../../utils/date')
const convertToDaysString = require('../../../utils/convertToDaysString')
const { resolveRates } = require('./resolveRates')
const { resolveOffers } = require('./resolveOffers')
const generateCacheKey = require('../../../cache/L1Cache/generateCacheKey')
const { strSplit } = require('../../../utils/string')
const queryOffersOverview = require('../queriers/queryOffersOverview')

/**
 * Extracts the last available stay gaps from rooms availability.
 * These gaps are usually not salable because of not right minstays.
 * @param {Array} restrictions
 * @param {String} room_code
 * @param {Object} availability
 * @param {Object} roomsOccupancy
 * @param {Object} params
 * @returns {Array} dates
 */
const resolveLastAvailableGaps = ({ restrictions, room_code }, availability, roomsOccupancy, params) => {
  const restrictionsDecoded = [...restrictions]
  const dates = []
  const today = dateToday()

  for (i = 0; i < 20; i++) {
    if (restrictionsDecoded[i] === '$') {
      continue
    }

    const varyingMinStay = parseInt(restrictionsDecoded[i])
    const nonVaryingMinStays = []
    const nonVaryingDynamicStays = []

    for (let rateplan in availability[room_code]) {
      nonVaryingMinStays.push(availability[room_code][rateplan].minstay[i])
      nonVaryingDynamicStays.push(availability[room_code][rateplan].dynamicminstay[i])
    }

    if (
      varyingMinStay.toString() !== '$' && //Checkin should be possible
      varyingMinStay.toString() !== '0' && //Day should be available
      !nonVaryingMinStays.some((e) => e === varyingMinStay.toString()) && //Dynamically changed minstay value should not be there in regular minstay of any of the rateplans
      nonVaryingDynamicStays.some((e) => parseInt(e) > 0) && //Some non-zero dynamic stay should be there
      nonVaryingDynamicStays.some(
        (e, index) =>
          parseInt(e) <= parseInt(varyingMinStay) && parseInt(nonVaryingMinStays[index]) > parseInt(varyingMinStay), //Dynamically changed minstay could be anything between regular minstay and dynamicstay
      )
    ) {
      for (j = 0; j < varyingMinStay; j++) {
        if (restrictionsDecoded[i + j] == 0) {
          //Break when any non-available day found in gap
          break
        } else if (
          j == varyingMinStay - 1 && //All the days of gap are available
          restrictionsDecoded[i + j] != 0 && //Check out day of gap should be available
          restrictionsDecoded[i + j + 1] == 0 && //Next day of checkout of gap should be non-available
          (restrictionsDecoded[i - 1] == 0 || i === 0) //Previous day of checkin of gap should be non-available
        ) {
          const tempDate = dateFrom(today)
          const lastAvailableDate = dateIsoFormat(tempDate)
          const lastAvailableUpto = tempDate.setDate(tempDate.getDate() + j + 1)

          if (
            (dateFrom(lastAvailableDate) >= dateFrom(params.staticStartDate) &&
              dateFrom(lastAvailableDate) <= dateFrom(params.staticEndDate)) ||
            (dateFrom(lastAvailableDate) >= dateAddDays(params.dynamicStart, dateToday()) &&
              dateFrom(lastAvailableDate) <= dateAddDays(params.dynamicStart + params.dynamicEnd, dateToday()))
          ) {
            dates.push({
              minStay: varyingMinStay,
              start: lastAvailableDate,
              end: dateIsoFormat(dateFrom(lastAvailableUpto)),
              ...roomsOccupancy,
            })
          } else if (!params.staticStartDate && !params.staticEndDate && !params.dynamicStart && !params.dynamicEnd) {
            dates.push({
              minStay: varyingMinStay,
              start: lastAvailableDate,
              end: dateIsoFormat(dateFrom(lastAvailableUpto)),
              ...roomsOccupancy,
            })
          }
        }
      }
    }

    if (
      params.staticEndDate &&
      params.dynamicEnd &&
      dateFrom(today) > dateFrom(params.staticEndDate) &&
      dateFrom(today) > dateAddDays(params.dynamicStart + params.dynamicEnd, dateToday())
    ) {
      break
    } else if (
      (params.staticStartDate && !params.dynamicEnd && dateFrom(today) > dateFrom(params.staticEndDate)) ||
      (params.dynamicEnd &&
        !params.staticStartDate &&
        dateFrom(today) > dateAddDays(params.dynamicStart + params.dynamicEnd, dateToday()))
    ) {
      break
    }

    today.setDate(today.getDate() + 1)
  }
  return dates
}

/**
 * Merges days and prices string of all rateplans of each room
 * @param {array} offersOverview
 * @param {object} xmlRatesOfRoom
 * @returns {object}
 */
const resolveDaysStringPerRoom = async (offersOverview, xmlRatesOfRoom, params) => {
  let genericDayString = []
  const promotionCodes = params?.promotionCodes ? strSplit(',', params.promotionCodes) : []

  for (let rateplan of offersOverview) {
    const rateOfXML = xmlRatesOfRoom[rateplan.rate_code]

    if (rateOfXML.promotionCode && !promotionCodes.includes(rateOfXML.promotionCode)) {
      continue
    }

    const stringsFromXML = rateOfXML.dayRates.reduce(
      (acc, cur, idx) => {
        acc.minstay[idx] = cur?.minstay || '-'
        acc.minstaythru[idx] = cur?.minstaythru || '-'
        return acc
      },
      {
        minstay: Array(rateOfXML.dayRates.length),
        minstaythru: Array(rateOfXML.dayRates.length),
      },
    )

    const daysArray = await convertToDaysString(rateplan.restrictions, stringsFromXML)

    if (!genericDayString || !genericDayString?.length) {
      genericDayString = [...daysArray]
    }

    if (genericDayString?.length) {
      for (i = 0; i < daysArray.length; i++) {
        const day = daysArray[i]

        if (parseInt(day) !== 0) {
          if (day === '$') {
            if (parseInt(genericDayString[i]) === 0) {
              genericDayString[i] = day.toString()
            }
          } else {
            if (parseInt(genericDayString[i]) === 0 || genericDayString[i] === '$') {
              genericDayString[i] = day.toString()
            } else {
              const stay = parseInt(day)
              const cstay = parseInt(genericDayString[i])
              if (stay < cstay) {
                genericDayString[i] = `${stay.toString()}`
              } else {
                genericDayString[i] = `${cstay.toString()}`
              }
            }
          }
        } else if (parseInt(day) === 0 && parseInt(genericDayString[i]) === 0) {
          genericDayString[i] = day.toString()
        }
      }
    }
  }

  return {
    restrictions: genericDayString,
    room_code: offersOverview?.[0]?.room_code,
  }
}

/**
 * Resolves each rooms occupancy for querying data
 * @param {Object} property
 * @param {Objecy} params
 * @returns {Array}
 */
const resolveRoomsOccupancy = (property, params, XMLRates) =>
  property.facility?.rooms.reduce((acc, room) => {
    const adults = params.adults || (room.min_child_occup && room.max_adult_occup) || room.types[0].std_occup
    const children = params.children || (room.min_child_occup ? Array(room.min_child_occup).fill(1) : [])
    const roomCode = params.roomCode || room.code
    if (
      adults + children.length >= room.min_occup &&
      adults + children.length <= room.max_occup &&
      roomCode === room.code &&
      XMLRates[room.code]
    ) {
      acc.push({
        adults,
        children,
        roomCode,
      })
    }
    return acc
  }, [])

/**
 * Resolves minstay and dynamicstay from XML based Rates
 * @param {Object} XMLRates
 * @returns {Object}
 */
const resolveXMLAvailability = (XMLRates) => {
  const availability = {}

  for (let roomCode in XMLRates) {
    const xmlRatesOfRoom = XMLRates[roomCode]
    availability[roomCode] = {}
    for (let rateCode in xmlRatesOfRoom) {
      const ratePlan = xmlRatesOfRoom[rateCode]['dayRates']
      availability[roomCode][rateCode] = {
        minstay: [],
        dynamicminstay: [],
      }
      ratePlan.forEach((day, index) => {
        if (!day) {
          availability[roomCode][rateCode]['minstay'][index] = '0'
          availability[roomCode][rateCode]['dynamicminstay'][index] = '0'
          return
        }

        if (day.minstay) {
          availability[roomCode][rateCode]['minstay'][index] = day.minstay
        } else {
          availability[roomCode][rateCode]['minstay'][index] = day.availability ? '1' : '0'
        }

        if (day.dynamicminstay) {
          availability[roomCode][rateCode]['dynamicminstay'][index] = day.dynamicminstay
        } else {
          availability[roomCode][rateCode]['dynamicminstay'][index] = '0'
        }
      })
    }
  }

  return availability
}

/**
 * Structures response
 * @param {Array} lastAvailableRoomsGaps
 * @param {Array} priceTotal
 * @returns {Object}
 */
const resolveStructuredResponse = (lastAvailableRoomsGaps, priceTotal) => {
  const lastAvailableRooms = {}

  lastAvailableRoomsGaps.forEach((room) => {
    room.forEach((dates) => {
      if (!lastAvailableRooms[dates.roomCode]) {
        lastAvailableRooms[dates.roomCode] = []
      }
      lastAvailableRooms[dates.roomCode].push({
        checkin: dates.start,
        checkout: dates.end,
        nights: dates.minstay,
        price: priceTotal.reduce((acc, { rateplans }) => {
          rateplans.forEach((rateplan) => {
            if (
              rateplan.checkin === dates.start &&
              rateplan.checkout === dates.end &&
              rateplan.room_code === dates.roomCode
            ) {
              acc.push({
                rateCode: rateplan.primary_item_code,
                total: rateplan.total,
                mealplanCode: rateplan.meal_plan_code,
              })
            }
          })
          return acc
        }, []),
      })
    })
  })

  return lastAvailableRooms
}

const resolveLastAvailableRooms = async ({ dataSources, db }, { property, token }, params) => {
  const [XMLRates, offersOverview] = await Promise.all([
    resolveRates({ db }, { property }, params),
    queryOffersOverview(db, params.config, params.language),
  ])
  const roomsOccupancy = resolveRoomsOccupancy(property, params, XMLRates)
  
  const daysStringPerRoom = await Promise.all(
    roomsOccupancy.map((room) =>
      resolveDaysStringPerRoom(
        offersOverview.overview.entities.filter((r) => r.room_code === room.roomCode && r.isPackage === false),
        XMLRates[room.roomCode],
        params,
        ),
      ),
    )
    
    const availability = resolveXMLAvailability(XMLRates)
    
    const lastAvailableRoomsGaps = await Promise.all(
    daysStringPerRoom.map((stringsOfRoom) =>
      resolveLastAvailableGaps(
        stringsOfRoom,
        availability,
        roomsOccupancy.find((r) => r.roomCode === stringsOfRoom.room_code),
        params,
        ),
        ),
        )

  const priceTotal = await Promise.all(
    lastAvailableRoomsGaps.reduce((acc, datesArray) => {
      datesArray.forEach((ele) => {
        acc.push(resolveOffers({ dataSources }, { property, token }, { ...params, ...ele }))
      })
      return acc
    }, []),
  )

  return resolveStructuredResponse(lastAvailableRoomsGaps, priceTotal)
}

const lastAvailableRoomsResolver = async (parent, params, context, info) => {
  const { cache, ttl } = context
  const { userId, provider, language } = parent.params.options
  const key = generateCacheKey('lastAvailableRooms', params, userId, provider, language)
  const cacheHit = await cache?.get(key)
  if (cacheHit) {
    return JSON.parse(cacheHit)
  } else {
    const cacheableValue = await resolveLastAvailableRooms(context, parent.params, {
      ...parent.params.options,
      ...params,
    })
    cache?.setEx(key, ttl, JSON.stringify(cacheableValue))
    return cacheableValue
  }
}

module.exports = {
  lastAvailableRoomsResolver, //dynamic call
  resolveLastAvailableRooms, //internal call
}
