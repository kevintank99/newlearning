const { isStringValue, isArrayValue, isDefined } = require('../../../utils/type')
const { strSplit } = require('../../../utils/string')
const { dateIsoFormat, dateToday, dateAddDays, dateDiffDays, dateFrom } = require('../../../utils/date')
const { arrayContains, arrayFilter, arrayMap } = require('../../../utils/array')
const { isPositiveNumber } = require('../../../utils/number')
const { defaults } = require('../constants')
const generateCacheKey = require('../../../cache/L1Cache/generateCacheKey')
const { resolvePriceList } = require('./resolvePriceList')
const { resolveRates } = require("./resolveRates");

//
const setDefaultOptions = (params, options) => {
  let defaultOptions = {}
  isStringValue(params.codes) && (defaultOptions.codes = strSplit(',', params.codes).map((str) => str.trim()))
  defaultOptions.startDate = isStringValue(params.start) ? dateFrom(params.start) : dateToday()
  defaultOptions.numberOfDays = isPositiveNumber(params.length) ? params.length : defaults.numberOfDays
  defaultOptions.endDate = dateAddDays(defaultOptions.numberOfDays, defaultOptions.startDate)
  defaultOptions.promotionCodes = (params?.promotionCodes) ? params?.promotionCodes : ''
  return {
    ...params,
    ...defaultOptions,
  }
}

const filterSeasonPeriods = (seasons, options) =>
  seasons.reduce((acc, { season_code, season_name, titles, operation_schedules }) => {
    if (!isArrayValue(options.codes) || arrayContains(season_code, options.codes)) {
      //skip the seasons which are not in the filter
      let startDate = dateFrom(options.startDate)
      let periods = arrayFilter(
        ({ start, end }) =>
          dateFrom(end) >= options.startDate || (options.endDate && dateFrom(start) >= options.endDate),
        operation_schedules,
      ) //filter periods by start/enddate
      if (isArrayValue(periods)) {
        //skip seasons with no periods
        let season = {
          code: season_code,
          ...resolveSeasonTitle(titles, season_name, options),
        }
        arrayMap((period) => {
          let periodStartDate = dateFrom(period.start)
          let periodEndDate = dateFrom(period.end)
          if (periodStartDate <= options.endDate) {
            let from = periodStartDate > startDate ? dateDiffDays(startDate, periodStartDate) : 0
            let to = dateDiffDays(startDate, periodEndDate)
            acc.push({
              ...season,
              ...period,
              from,
              to,
            })
          }
        }, periods)
      }
    }
    return acc
  }, new Array())

//assign group to season sorted periods
const groupSeasonPeriods = async (seasonPeriods, context, parentParams, options) => {
  var seasons = []
  var group = 0
  options.startDate = (dateToday() > dateFrom(seasonPeriods[0].start)) ? dateToday() : seasonPeriods[0].start 
  const { db } = context;
  const { property } = parentParams;
  const [ratesAvg, rates] = await Promise.all([
    db.findOne("ratesaverage", {
      userId: options.userId,
      hotelCode: options.hotelId,
      language: options.language,
    }),
    resolveRates({ db }, { property }, options),
  ]);
  for (let p = 0; p < seasonPeriods.length; p++) {
    const dayPrice = {};
    for (let roomCode in rates) {
      if (!dayPrice[roomCode]) {
        dayPrice[roomCode] = {};
      }
      for (let rateCode in rates[roomCode]) {
        if (!dayPrice[roomCode][rateCode]) {
          dayPrice[roomCode][rateCode] = {};
        }
        dayPrice[roomCode][rateCode] = {
          ...rates[roomCode][rateCode],
          dayRates: rates[roomCode][rateCode]["dayRates"].slice(
            seasonPeriods[p].from,
            seasonPeriods[p].to + 1
          ),
        };
      }
    }

    let code = seasonPeriods[p].code;
    let title = seasonPeriods[p].title;
    let start = seasonPeriods[p].start;
    let end = seasonPeriods[p].end;
    let from = seasonPeriods[p].from;
    let to = seasonPeriods[p].to;

    group = p > 0 ? (code == seasonPeriods[p - 1].code ? group : group + 1) : 0; //find the season index
    const priceList = await resolvePriceList(
      context,
      parentParams,
      options,
      {dayPrice,ratesAvg}
    );
    if (isDefined(seasons[group])) {
      seasons[group].periods.push({start, end, from, to, priceList });
    } else {
      seasons[group] = { code, title, periods: [{ start, end, from, to, priceList }] }
    }
  }
  return seasons
}

//sort the season periods by start date
const sortSeasonPeriods = (seasonPeriods) => seasonPeriods.sort((a, b) => (a.start < b.start ? -1 : 1)) //sort all the periods

/**
 * Split the seasons into single period keys and sort by date - same season can be valid for different years and have
 * other seasons in between
 */
const resolveSeasonTitle = (titles, season_name, options) =>
  titles.reduce(
    (acc, { language, text }) => {
      let title = text
      if (language.toLowerCase() == options.language) {
        acc.title = title
      }
      return acc
    },
    { title: season_name },
  )

/**
 * Add the from-to years to each season group
 * @param {array} seasons
 */
const resolveSeasonYears = (seasons) => {
  seasons.map((season) => {
    let startYear = season.periods[0].start.substring(0, 4)
    let endYear = season.periods[season.periods.length - 1].start.substring(0, 4)
    season.years = startYear === endYear ? `${startYear}` : `${startYear} - ${endYear}`
  })
  return seasons
}

//all the seasons for a client are in property info ext.seasons
//each season has periods (ext.seasons[n].operation_schedules)
const resolveSeasons = async (propertyData, options, context, parentParams) => {
  options = setDefaultOptions(options, {})
  return resolveSeasonYears(
    await groupSeasonPeriods(sortSeasonPeriods(filterSeasonPeriods(propertyData.ext.seasons, options)), context, parentParams, options),
  ) //split the seasons to periods, sort them, group again by season
}

//resolver for dynamic call
const seasonsResolver = async (parent, params, context, info) => {
  const { cache, ttl } = context
  const { userId, provider, language } = parent.params.options
  const key = generateCacheKey('seasons', params, userId, provider, language)
  const cacheHit = await cache?.get(key)
  if (cacheHit) {
    return JSON.parse(cacheHit)
  } else {
    const cacheableValue = await resolveSeasons(parent.params.property, { ...parent.params.options, ...params }, context, parent.params)
    cache?.setEx(key, ttl, JSON.stringify(cacheableValue))
    return cacheableValue
  }
}

module.exports = {
  seasonsResolver, //resolver for dynamic call
  resolveSeasons, //resolver function for internal use
}