// const { fetchOffers } = require('../fetchers')
const queryOffers = require('../queriers/queryOffers')
const { isStringValue } = require('../../../utils/type')
const { dateToday, dateDiffDays, dateFrom } = require('../../../utils/date')
const { DEFAULT_MEALPLANCODE } = require('../constants')
const { strSplit } = require('../../../utils/string')

const setOptions = (params) => {
  let options = {}
  options.checkin = isStringValue(params.start) ? params.start : dateToday()
  options.checkout = isStringValue(params.end) ? params.end : dateToday()
  options.roomCodes = isStringValue(params.roomCode) ? params.roomCode : ''
  options.rooms = [
    {
      adults: params.adults,
      children: params.children,
    },
  ]
  options.promotionCode = isStringValue(params.promotionCode) ? params.promotionCode : ''
  return options
}

// resolver for internal call
const resolveOffers = async ({ dataSources }, { property, token }, params) => {
  const options = setOptions({ ...params, property })

  const offers = await queryOffers(dataSources, params.config, { ...params, ...options, accessToken: token })
  const { result: { [params.hotelId]: { room_offers: roomOffers = [], metadata: { rates = [] } = {} } = {} } = {} } =
    offers

  //Rate code to rates data mapping
  const metaOfRates = rates.reduce((acc, rate) => {
    acc[rate.code] = { ...rate }
    return acc
  }, {})

  const mealplanToRateplans = {}
  const mealplanToOffers = {}

  const allRateplans = []
  const allOffers = []

  const alternativeRooms = new Set()
  const alternativeOffers = new Set()

  const roomCodes = params.roomCode ? strSplit(',', params.roomCode) : []
  const offerCodes = params.offerCode ? strSplit(',', params.offerCode) : []

  for (let rate of roomOffers[0]) {
    const metaOfRate = metaOfRates[rate.primary_item_code]

    const mealplanCode = metaOfRate.meal_plan_code || DEFAULT_MEALPLANCODE
    const isOffer = metaOfRate.type !== 'DayRate'

    const prices = rate.items
      .map((p) => {
        if (p.pricing_details) {
          return Object.values(p.pricing_details)
        } else {
          const diffCount = dateDiffDays(dateFrom(p.start), dateFrom(p.end)) + 1
          const pricePerDay = p.price / diffCount
          return Array(diffCount).fill(pricePerDay)
        }
      })
      .flat()

    const modifiedRate = {
      ...rate,
      meal_plan_code: mealplanCode,
      calendar: {
        startIndex: dateDiffDays(dateToday(), dateFrom(params.start)),
        nights: prices.length,
        prices,
      },
    }

    alternativeRooms.add(rate.room_code)
    isOffer && alternativeOffers.add(rate.primary_item_code)

    if (roomCodes.length && !roomCodes.includes(rate.room_code)) {
      continue
    }

    if (isOffer && offerCodes.length && !offerCodes.includes(rate.primary_item_code)) {
      continue
    }

    if (isOffer) {
      allOffers.push(modifiedRate)
      if (!mealplanToOffers[mealplanCode] || mealplanToOffers[mealplanCode].total > rate.total) {
        mealplanToOffers[mealplanCode] = modifiedRate
      }
    } else {
      allRateplans.push(modifiedRate)
      if (!mealplanToRateplans[mealplanCode] || mealplanToRateplans[mealplanCode].total > rate.total) {
        mealplanToRateplans[mealplanCode] = modifiedRate
      }
    }
  }

  return {
    rateplans: Object.values(mealplanToRateplans),
    offers: Object.values(mealplanToOffers),
    allRateplans,
    allOffers,
    alternativeRooms: [...alternativeRooms],
    alternativeOffers: [...alternativeOffers],
  }
}

//resolver for dynamic call
const offersResolver = async (parent, params, context, info) => {
  return resolveOffers(context, parent.params, { ...parent.params.options, ...params })
}

module.exports = {
  offersResolver, //dynamic call
  resolveOffers, //internal call
}
