const { resolvePictures } = require('./resolvePictures')
const { isStringValue, isArray } = require('../../../utils/type')
const { strSplit } = require('../../../utils/string')
const generateCacheKey = require('../../../cache/L1Cache/generateCacheKey')
const resolveText = (name, translations, options) =>
  translations.reduce((acc, { language, content }) => {
    if (language.toLowerCase() == options.language) {
      acc[name] = content
    }
    return acc
  }, {})

const resolveCategoryImages = (propertyData, options) =>
  resolvePictures(propertyData, options).reduce((acc, { category, url, fileName }) => {
    if (category) {
      //TODO: add image title
      isArray(acc[category]?.images)
        ? acc[category].images.push({ url, fileName })
        : (acc[category] = { images: [{ url, fileName }] })
    }
    return acc
  }, {})

const setDefaultOptions = (params, options) => {
  let defaultOptions = {}
  isStringValue(params.language) ? (defaultOptions.language = params.language) : (defaultOptions.language = 'en')
  isStringValue(params.codes) && (defaultOptions.codes = strSplit(',', params.codes))
  return {
    ...options,
    ...defaultOptions,
  }
}

const resolveCategories = (propertyData, options) => {
  options = setDefaultOptions(options, {})
  const categoryImages = resolveCategoryImages(propertyData, options)
  return propertyData.ext.classifications[0]?.items.reduce((acc, { code, titles, descriptions }) => {
    ;(!options.codes || options.codes.indexOf(code) > -1) && //filter by code
      acc.push({
        code,
        ...(categoryImages[code] || {}),
        ...resolveText('title', titles, options),
        ...resolveText('description', descriptions, options),
      })
    return acc
  }, new Array())
}

//resolver for dynamic call
const categoriesResolver = async (parent, params, context, info) => {
  const { cache, ttl } = context
  const { userId, provider, language } = parent.params.options
  const key = generateCacheKey('categories', params, userId, provider, language)
  const cacheHit = await cache?.get(key)
  if (cacheHit) {
    return JSON.parse(cacheHit)
  } else {
    const cacheableValue = resolveCategories(parent.params.property, { ...parent.params.options, ...params })
    cache?.setEx(key, ttl, JSON.stringify(cacheableValue))
    return cacheableValue
  }
}

module.exports = {
  categoriesResolver,
  resolveCategories,
}
