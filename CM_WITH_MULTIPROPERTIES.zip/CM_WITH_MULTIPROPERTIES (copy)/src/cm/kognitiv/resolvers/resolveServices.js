const generateCacheKey = require('../../../cache/L1Cache/generateCacheKey')
const { arrayIntersect } = require('../../../utils/array')
const { strSplit } = require('../../../utils/string')
const { isStringValue } = require('../../../utils/type')
const queryServicesXML = require('../queriers/queryServicesXML')
const queryServices = require('../queriers/queryServices')

//
const setDefaultOptions = (params, options) => {
  isStringValue(params.categories) && (options.categories = strSplit(',', params.categories).map((str) => str.trim())) //split categories filter to array
  isStringValue(params.services) && (options.services = strSplit(',', params.services).map((str) => str.trim())) //split services filter to array
  return {
    ...params,
    ...options,
  }
}

const serviceMatchCategory = (categories, options) =>
  !options.categories || arrayIntersect(options.categories, categories).length > 0

const requestedServices = (code, Services) => (Services && Services?.join('') ? Services.includes(code) : true)

/**
 * Resolve Services from XML & Json
 * @param {Array} XMLServices
 * @param {Array} jsonServices
 * @param {Object} options
 * @returns {Array}
 */
const resolveXMLServicesWithJson = (XMLServices, jsonServices, options) => {
  const services =
    XMLServices?.services?.reduce((acc, service) => {
      if (
        service.enabled != 'false' &&
        serviceMatchCategory(service.category_codes, options) &&
        requestedServices(service.code, options.services)
      ) {
        const jsonService = jsonServices?.services?.find((j) => j.code === service.code) || {}
        acc.push({
          code: service.code,
          categories: service.category_codes,
          sort: service.sort,
          images: service?.images,
          videos: service?.videos,
          title: service?.title?.[options.language],
          teaser: service?.teaser,
          description: service?.description?.[options.language],
          price: {
            amount: service?.unit_price,
            currency: service?.currency_code,
          },
          availability: service.availability,
          ...jsonService,
        })
      }
      return acc
    }, new Array()) || {}
  return services
}

//
const resolveServices = async ({ dataSources, db }, { property, token }, options) => {
  options = setDefaultOptions(options, {})

  const [xmlServices, jsonServices] = await Promise.all([
    queryServicesXML(db, options.config),
    queryServices(db, options.config, options.language),
  ])
  !xmlServices && console.log(`Xml services error`)
  !jsonServices && console.log(`Json services error`)

  return resolveXMLServicesWithJson(xmlServices, jsonServices, options)
}

//resolver for dynamic call
const servicesResolver = async (parent, params, context, info) => {
  const { cache, ttl } = context
  const { userId, provider, language } = parent.params.options
  const key = generateCacheKey('services', params, userId, provider, language)
  const cacheHit = await cache?.get(key)
  if (cacheHit) {
    return JSON.parse(cacheHit)
  } else {
    const cacheableValue = await resolveServices(context, parent.params, { ...parent.params.options, ...params })
    cache?.setEx(key, ttl, JSON.stringify(cacheableValue))
    return cacheableValue
  }
}

module.exports = {
  servicesResolver, //dynamic call
  resolveServices, //internal call
}
