const { isStringValue } = require('../../../utils/type')
const { fetchOffers } = require('../fetchers')
const { resolveRooms } = require('./resolveRooms')
const { mealPlanCodes } = require('../constants')
const { dateToday, dateDiffDays, dateAddDays, dateFrom, dateIsoFormat } = require('../../../utils/date')

const setOptions = (params) => {
  let options = {}
  options.checkin = isStringValue(params.start) ? params.start : dateToday()
  options.checkout = isStringValue(params.end) ? params.end : dateToday()
  options.promotionCode = isStringValue(params.promotionCode) ? params.promotionCode : ''
  return options
}

/**
 * Resolves meta by searching the meta of that offer code and including into it
 * @param {object} offer
 * @param {array} meta_rates
 * @param {array} meta_rooms
 * @param {object} meta_policies
 * @param {array} rooms
 * @returns object
 */
const resolveMetaOfOffers = (offer, meta_rates, meta_rooms, meta_policies, rooms) => {
  const room = rooms.find((room) => room.code === offer.room_code)
  const meta_rate = meta_rates.find((rate) => rate.code === offer.primary_item_code)
  const meta_room = meta_rooms.find((room) => room.code === offer.room_code)
  const policiesInRate = { ...meta_policies }
  if (policiesInRate.taxes) {
    policiesInRate.taxes = policiesInRate.taxes.find((tax) => tax.code === meta_rate.tax_policy_code)
  }
  if (policiesInRate.guarantees) {
    policiesInRate.guarantees = policiesInRate.guarantees.find(
      (guarantee) => guarantee.code === meta_rate.guarantee_policy_code,
    )
  }
  if (policiesInRate.cancellations) {
    policiesInRate.cancellations = policiesInRate.cancellations.find(
      (cancellation) => cancellation.code === meta_rate.cancel_policy_code,
    )
  }
  if (policiesInRate.pets) {
    policiesInRate.pets = policiesInRate.pets.find((pet) => pet.code === meta_rate.pets_policy_code)
  }
  return {
    ...offer,
    meta_room,
    meta_room_extras: room,
    meta_rate,
    meta_policy: policiesInRate,
  }
}

/**
 * Adds the rateplans info regarding start date, end date and stay duration
 * @param {object} offer
 * @returns object
 */
const resolveDailyRates = (offer) => ({
  dailyRates: offer?.items?.reduce((prev, cur) => {
    if (cur?.pricing_details && cur?.original_pricing_details) {
      const orgPriceDetails = Object.values(cur?.original_pricing_details)
      Object.entries(cur.pricing_details).forEach(([key, value], idx) => {
        prev.push({
          date: key,
          price: value,
          ...(offer?.total !== offer?.original_total && { originalPrice: orgPriceDetails[idx] }),
        })
      })
    }
    return prev
  }, []),
})

/**
 * Adds the package info like start date, end date and stay duration
 * @param {object} offer
 * @returns object
 */
const resolvePackages = (offer) => ({
  images: offer?.meta_rate?.images,
  los: offer?.items?.reduce((prev, cur) => {
    if (!prev.package && !prev.shoulderRate) {
      prev = {
        package: {},
        shoulderRate: {
          shoulderRateTotalLos: 0,
          after: null,
          before: null,
        },
      }
    }
    const offerStayInfo = {
      nights: dateDiffDays(dateFrom(cur.start), dateFrom(cur.end)) + 1,
      startDate: cur.start,
      endDate: dateIsoFormat(dateAddDays(1, dateFrom(cur.end))),
    }
    if (!Object.values(prev.package)?.length && !prev?.shoulderRate?.before && cur.code !== offer.primary_item_code) {
      prev.shoulderRate.before = offerStayInfo
      prev.shoulderRate.shoulderRateTotalLos += offerStayInfo.nights
    } else if (cur.code === offer.primary_item_code) {
      prev.package = offerStayInfo
    } else if (cur.code !== offer.primary_item_code) {
      prev.shoulderRate.after = offerStayInfo
      prev.shoulderRate.shoulderRateTotalLos += offerStayInfo.nights
    }
    return prev
  }, {}),
})

/**
 * Formats the kognitiv's API response into its adjacent kognitiv internal API
 * @param {array} offers
 * @param {object} meta_mealPlans
 * @param {string} language
 * @returns array
 */
const alterOffers = (offers, meta_mealPlans, language, params) =>
  offers.reduce((acc, offer) => {
    const tempIndex = acc?.findIndex((e) => e.code == offer.room_code)
    const alteredOfferIndex = tempIndex < 0 ? acc.length : tempIndex
    const mealPlanCode = offer?.meta_rate?.meal_plan_code || '3'
    const mealPlan = meta_mealPlans[mealPlanCode] || mealPlanCodes[mealPlanCode][language]
    if (tempIndex < 0) {
      acc[alteredOfferIndex] = {
        code: offer.room_code,
        rates: [],
        marketing: {
          bestSeller: offer?.meta_room?.bestSeller,
          suite: offer?.meta_room?.type == '3',
        },
        amenities: offer?.meta_room?.amenitiesInfo.reduce((pre, cur) => ({ ...pre, [cur.code]: cur.title }), {}),
        images: {
          internal: [...offer?.meta_room_extras?.images],
          plan: [...offer?.meta_room_extras?.floorplans],
        },
        title: offer?.meta_room?.title,
        description: offer?.meta_room?.description,
        occupancy: offer?.meta_room_extras?.occupancy,
        size: offer?.meta_room?.size ? `${offer?.meta_room?.size} ${offer?.meta_room?.sizeUnit}` : null,
        non_smoking: !offer?.meta_room?.smoking,
        beds: {
          type: offer?.meta_room_extras?.beds?.type,
          std_num: offer?.meta_room_extras?.beds?.stdNum,
          max_rollaways: offer?.meta_room_extras?.beds?.maxRollaways,
        },
        type: offer?.meta_room_extras?.type,
        offers: [],
      }
    }
    const ratesOrOffers = {
      code: offer.primary_item_code,
      title: offer?.meta_rate?.title,
      description: offer?.meta_rate?.description,
      categoryCodes: offer?.meta_rate?.category_codes,
      discount: offer?.discount_percent,
      onHoldDuration: offer?.on_hold_duration,
      marketing: {
        promotion: {
          enabled: !!offer?.promotion,
          details: {
            expires: offer?.promotion?.expires ?? 0,
            freeNights: offer?.promotion?.freeNights ?? 0,
            freeChildren: offer?.promotion?.freeChildren ?? 0,
            lastMinute: offer?.promotion?.lastMinute || false,
          },
        },
        bestDeal: offer?.best_deal || false,
        lowestRate: offer?.lowest_rate || false,
      },
      extraInfo: {
        onRequest: offer?.meta_policy?.guarantees?.available_on_request,
        nonRefundable: offer?.refundable !== 'full',
        freeCancellationDeadline: offer?.meta_policy?.cancellations?.free_cancellation_deadline,
        withoutPayment: !offer?.prepayment_amount,
        mealPlan,
        mealPlanCode,
      },
      policies: {
        cancellations: offer?.meta_policy?.cancellations?.penalties?.map((p) => p.description),
        guarantees: offer?.meta_policy?.guarantees?.description,
        taxes: offer?.meta_policy?.taxes?.rules?.map((r) => r.description),
        pets: offer?.meta_policy?.pets?.policies?.map((p) => p.description),
      },
      guaranteePolicyCode: offer?.meta_rate?.guarantee_policy_code,
      quantity: offer?.quantity,
      price: offer?.items?.reduce((prev, cur) => prev + cur.price, 0),
      ...(offer?.meta_rate?.type !== 'Package' ? resolveDailyRates(offer) : resolvePackages(offer)),
      total: offer?.total,
      shoppingCartPrice: offer?.total,
      roomCode: offer?.room_code,
      ...(offer?.meta_rate?.exclusive_offer ? { promotionCode: params.promotionCode } : {}),
    }
    offer?.meta_rate?.type !== 'Package'
      ? acc[alteredOfferIndex]?.rates?.push(ratesOrOffers)
      : acc[alteredOfferIndex]?.offers?.push(ratesOrOffers)
    return acc
  }, [])

/**
 * Resolves available rooms as per requested occupancy or occupancies to book multiple rooms at same time
 * @param {array} offers
 * @param {array} roomCodes
 * @param {array} rooms
 * @param {string} language
 * @param {object} meta_policies
 * @param {array} meta_rooms
 * @param {array} meta_rates
 * @param {object} meta_mealPlans
 * @returns array
 */
const resolveAvailableRoomsForOccupancy = async (
  offers,
  roomCodes,
  rooms,
  language,
  meta_policies,
  meta_rooms,
  meta_rates,
  meta_mealPlans,
  params,
) => {
  if (offers) {
    offers = offers.reduce((acc, offer) => {
      if (!roomCodes.length || roomCodes.includes(offer.room_code)) {
        acc.push(resolveMetaOfOffers(offer, meta_rates, meta_rooms, meta_policies, rooms))
      }
      return acc
    }, [])
    return alterOffers(offers, meta_mealPlans, language, params)
  }
  return [];
}

/**
 * Merges meta of offers and formats the response
 * @returns array
 */
const reolveRatesAndOffers = async (
  {
    room_offers: offers,
    metadata: { policies: meta_policies, rooms: meta_rooms, rates: meta_rates, mealPlans: meta_mealPlans },
  },
  rooms,
  { language, ...params },
) => {
  const roomCodes = params.roomCode ? params.roomCode.split(',') : []
  if (!offers) {
    return
  }
  return Promise.all(
    offers.map((offer) =>
      resolveAvailableRoomsForOccupancy(
        offer,
        roomCodes,
        rooms,
        language,
        meta_policies,
        meta_rooms,
        meta_rates,
        meta_mealPlans,
        params,
      ),
    ),
  )
}

//resolver for internal calls
const resolveOffersForAutoReply = async ({ dataSources }, { property, token }, params) => {
  const options = setOptions({ ...params, property })
  const [{ data: offers, error: offersError }, rooms] = await Promise.all([
    fetchOffers(dataSources, { ...params, ...options, accessToken: token }),
    resolveRooms(property, params),
  ])
  offersError && console.log(`Offers: ${offersError}`)
  return reolveRatesAndOffers(offers?.result?.[params.hotelId], rooms, params)
}

//resolver for dynamic calls
const offersForAutoReplyResolver = async (parent, params, context, info) => {
  return resolveOffersForAutoReply(context, parent.params, { ...parent.params.options, ...params })
}

module.exports = {
  offersForAutoReplyResolver,
  resolveOffersForAutoReply,
}
