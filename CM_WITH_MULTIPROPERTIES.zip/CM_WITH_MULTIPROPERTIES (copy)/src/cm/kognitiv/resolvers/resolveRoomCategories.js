const generateCacheKey = require('../../../cache/L1Cache/generateCacheKey')
const { resolveCategories } = require('./resolveCategories')

const resolveRoomCategories = (propertyData, options) => {
  const roomCategories = options.config?.rooms?.categories ?? {}
  const categories = resolveCategories(propertyData, options)
  return Object.entries(roomCategories).reduce((acc, [key, value]) => {
    let category = {}
    if ((category = categories.find(({ code }) => code === key))) {
      acc.push({
        ...category,
        rooms: value.codes || value.rooms || [],
      })
    }
    return acc
  }, new Array())
}

//resolver for dynamic call
const roomCategoriesResolver = async (parent, params, context, info) => {
  const { cache, ttl } = context
  const { userId, provider, language } = parent.params.options
  const key = generateCacheKey('roomCategories', params, userId, provider, language)
  const cacheHit = await cache?.get(key)
  if (cacheHit) {
    return JSON.parse(cacheHit)
  } else {
    const cacheableValue = resolveRoomCategories(parent.params.property, { ...parent.params.options, ...params })
    cache?.setEx(key, ttl, JSON.stringify(cacheableValue))
    return cacheableValue
  }
}

module.exports = {
  roomCategoriesResolver,
  resolveRoomCategories,
}
