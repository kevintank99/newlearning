const generateCacheKey = require('../../../cache/L1Cache/generateCacheKey')
const {isStringValue, isNumber} = require('../../../utils/type') 

const setDefaultOptions = (params, options) => {
  let defaultOptions = {}
  isStringValue(params.language) ? defaultOptions.language = params.language : defaultOptions.language = 'en'
  return {
    ...options, 
    ...defaultOptions
  }
}

const resolveDescriptions = (descriptions, options) => 
  descriptions[0]?.text_items.reduce((acc, {language, title}) => {
    if (language.toLowerCase() == options.language) {
      return { title }
    }
    return acc
  }, {})


const resolveChildAges = async (propertyData, options) => {
  options = setDefaultOptions(options, {})
  let fromAge = 0, toAge = 0
  let currentHotelCode = ''
  return propertyData.ext.children.reduce((acc, {age_qualifying_code, percent_of_adult_rate, total_value, descriptions,hotelCode,keyType}) => {
    if(!(currentHotelCode == '' || currentHotelCode == hotelCode)){
      fromAge = 0
    }
    toAge = age_qualifying_code - 100
    acc.push({
      code: age_qualifying_code,
      fromAge,
      toAge,
      ageRange: `${fromAge} - ${toAge}`,
      ratePercent: percent_of_adult_rate,
      rateAmount: total_value,
      freeOfCharge: percent_of_adult_rate === 0 || total_value === 0,
      priceType: isNumber(percent_of_adult_rate) ? 'percent' : (isNumber(total_value) ? 'amount' : 'custom'),
      ...resolveDescriptions(descriptions, options),
      hotelCode:hotelCode,
      keyType:keyType
    })
    fromAge = toAge + 1
    currentHotelCode = hotelCode
    return acc
  }, [])
}

const childAgeRange = (ageQualifyingCode, childAges) => {
  return childAges.reduce((acc, {code, ageRange}) => {
    if (code == ageQualifyingCode) {
      acc = ageRange
    }
    return acc
  }, null)
}

//resolver for dynamic call
const childAgesResolver = async (parent, params, context, info) => {
  const { cache, ttl } = context
  const { userId, provider, language } = parent.params.options
  const key = generateCacheKey('childAges', params, userId, provider, language)
  const cacheHit = await cache?.get(key)
  if (cacheHit) {
    return JSON.parse(cacheHit)
  } else {
    const cacheableValue = await resolveChildAges(parent.params.property, { ...parent.params.options, ...params })
    cache?.setEx(key, ttl, JSON.stringify(cacheableValue))
    return cacheableValue
  }
}

module.exports = {
  childAgesResolver,
  resolveChildAges,
  childAgeRange
}