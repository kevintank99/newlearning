const convertToDaysString = require('../../../utils/convertToDaysString')
const { dateToday, timeWithTimeZone } = require('../../../utils/date')
const {
  mealPlanCodes,
  DEFAULT_MEALPLANCODE,
  decodeStrings: {
    DECRYPT_RESTRICTIONS,
    DECRYPT_RESTRICTIONS_MAX_LOS,
    DECRYPT_RESTRICTIONS_MIN_STAY_THRU,
    DECRYPT_RESTRICTIONS_MAX_STAY_THRU,
  },
} = require('../constants')
const { strSplit } = require('../../../utils/string')
const { resolveRates } = require('./resolveRates')
const generateCacheKey = require('../../../cache/L1Cache/generateCacheKey')
const queryOffersOverview = require('../queriers/queryOffersOverview')

/**
 * Decode kognitiv strings to usable data strings
 * @param {string} string
 * @param {object} decodeMap
 */
const stringDecoder = async (string, arrayFromXML, decodeMap) => {
  const arr = string.split('')
  return arr.map((a, idx) => {
    if (a.charCodeAt() >= 97 && a.charCodeAt() <= 122) {
      return arrayFromXML?.[idx]
    } else {
      return decodeMap[a]
    }
  })
}

/**
 * Merges the changeOver of all the rooms and creates a combined closedto string
 * @param {array} calendarData
 * @returns {array}
 */
const resolveClosedTo = async (calendarData) => {
  const closedto = []

  for (let i = 0; i < calendarData[0]?.closedto.length; i++) {
    let currentClosedToArray = calendarData.map((c) => c.closedto[i])
    let currentRestrictionsToArray = calendarData.map((c) => c.days[i])

    if (currentRestrictionsToArray.every((e) => e === '0') && !currentClosedToArray.every((e) => e === '3')) {
      closedto[i] = '4' //For room not available
    } else if (currentClosedToArray.some((e) => e === '0')) {
      closedto[i] = '0'
    } else if (currentClosedToArray.every((e) => e === '1')) {
      closedto[i] = '1'
    } else if (currentClosedToArray.every((e) => e === '2')) {
      closedto[i] = '2'
    } else if (currentClosedToArray.every((e) => e === '3')) {
      closedto[i] = '3'
    } else if (currentClosedToArray.some((e) => e === '3')) {
      if (currentClosedToArray.some((e) => e === '2') && !currentClosedToArray.some((e) => e === '1')) {
        //only 3 and 2s, return 2
        closedto[i] = '2'
      } else if (currentClosedToArray.some((e) => e === '1') && !currentClosedToArray.some((e) => e === '2')) {
        //only 3 and 1s, return 1
        closedto[i] = '1'
      } else {
        //contains 3, 2 and 1, return 0
        closedto[i] = '0'
      }
    } else {
      closedto[i] = '0'
    }
  }

  return closedto
}

/**
 * Combines closedto string of multiple rooms with different occupancies
 * @param {array} closedtoArr
 * @returns {array}
 */
const resolveCombinedClosedToOfAllOccup = (closedtoArr) => {
  const closedto = []

  for (let i = 0; i < closedtoArr[0].length; i++) {
    let currentClosedToArray = closedtoArr.map((c) => c[i])

    if (currentClosedToArray.some((e) => e === '4')) {
      closedto[i] = '4'
    } else if (currentClosedToArray.some((e) => e === '3')) {
      closedto[i] = '3'
    } else if (currentClosedToArray.some((e) => e === '2')) {
      closedto[i] = '2'
    } else if (currentClosedToArray.some((e) => e === '1')) {
      closedto[i] = '1'
    } else {
      closedto[i] = '0'
    }
  }

  return closedto.join('|')
}

/**
 * Combines all rooms days string in negative manner
 * i.e., keeps only those indexes as available which are available in all rooms
 * @param {object} genericDayString
 * @returns {string}
 */
const resolveAllRoomsDayStringInNegative = async (genericDayString) => {
  let dayString = null
  for (let roomCode in genericDayString) {
    if (!dayString) {
      dayString = genericDayString[roomCode]
    } else {
      genericDayString[roomCode].forEach((day, index) => {
        if (day === '0' || dayString[index] === '0') {
          dayString[index] = '0'
        } else if (
          (day === '$' || dayString[index] === '$') &&
          ((!isNaN(parseInt(dayString[index - 1])) && parseInt(dayString[index - 1]) > 0) ||
            dayString[index - 1] === '$')
        ) {
          dayString[index] = '$'
        } else if (day === '$' && dayString[index] === '$' && parseInt(dayString[index - 1]) === 0) {
          dayString[index] = '0'
        } else if (day !== '0' && dayString[index] !== '0') {
          if (day !== '$') {
            if (parseInt(day) < parseInt(dayString[index])) {
              dayString[index] = day
            }
          }
        }
      })
    }
  }
  return resolveExplicitCheckout(dayString)
}

/**
 * Creates max stay string by checking the maximum constant availability
 * of any given index for particular room and keeps the maximum value out of them.
 * @param {array} calendar
 * @returns {string}
 */
const resolveMaxStay = async (calendar) => {
  const days = calendar?.map((c) => c?.days)
  const arrayLength = days?.[0]?.length
  const maxDaysString = Array(arrayLength || 0).fill('0')
  days.forEach((daysString) => {
    for (let i = 0; i < daysString.length; i++) {
      const day = daysString[i]
      if (day !== '$' && day !== '0') {
        let count = 0
        for (let j = i + parseInt(day); j < daysString.length; j++) {
          if (daysString[j] === '0') {
            break
          }
          count += 1
        }
        count += parseInt(day)
        if (isNaN(maxDaysString[i])) {
          maxDaysString[i] = count.toString()
        } else {
          maxDaysString[i] = count > parseInt(maxDaysString[i]) ? count.toString() : maxDaysString[i]
        }
      }
    }
  })
  return maxDaysString
}

/**
 * Merges days and prices string of all rateplans of each room
 * @param {array} calendarData
 */
const resolveDayAndPriceString = (calendarData) => {
  let genericDayString = []
  const genericPriceString = {
    mealplans: {},
    min: null,
    max: null,
  }

  calendarData.forEach((ratePlan) => {
    const priceArray = [...ratePlan.prices]
    const daysArray = [...ratePlan.days]
    const mealplanCode = ratePlan.meal_plan_code

    if (
      !genericPriceString['mealplans']?.[mealplanCode]?.['min'] &&
      !genericPriceString['mealplans']?.[mealplanCode]?.['max']
    ) {
      genericPriceString['mealplans'][mealplanCode] = {
        min: priceArray.map((price, index) => {
          if (daysArray[index] === '0') {
            return null
          }
          return price
        }),
        max: priceArray.map((price, index) => {
          if (daysArray[index] === '0') {
            return null
          }
          return price
        }),
      }
    }

    if (!genericPriceString['min']) {
      genericPriceString['min'] = priceArray.map((price, index) => {
        if (daysArray[index] === '0') {
          return null
        }
        return price
      })
    }

    if (!genericPriceString['max']) {
      genericPriceString['max'] = priceArray.map((price, index) => {
        if (daysArray[index] === '0') {
          return null
        }
        return price
      })
    }

    if (!genericDayString?.length) {
      genericDayString = [...daysArray]
    }

    if (
      genericPriceString['mealplans']?.[mealplanCode]?.['min'] &&
      genericPriceString['mealplans']?.[mealplanCode]?.['max'] &&
      genericPriceString['min'] &&
      genericPriceString['max'] &&
      genericDayString?.length
    ) {
      for (i = 0; i < daysArray.length; i++) {
        const price = priceArray[i]
        const day = daysArray[i]

        if (
          price &&
          day !== '0' &&
          genericPriceString['mealplans'][mealplanCode]['min'][i] &&
          parseInt(price) < parseInt(genericPriceString['mealplans'][mealplanCode]['min'][i])
        ) {
          genericPriceString['mealplans'][mealplanCode]['min'][i] = price
        } else if (!genericPriceString['mealplans'][mealplanCode]['min'][i] && daysArray[i] !== '0') {
          genericPriceString['mealplans'][mealplanCode]['min'][i] = price
        }

        if (
          price &&
          day !== '0' &&
          genericPriceString['mealplans'][mealplanCode]['max'][i] &&
          parseInt(price) > parseInt(genericPriceString['mealplans'][mealplanCode]['max'][i])
        ) {
          genericPriceString['mealplans'][mealplanCode]['max'][i] = price
        } else if (!genericPriceString['mealplans'][mealplanCode]['max'][i] && daysArray[i] !== '0') {
          genericPriceString['mealplans'][mealplanCode]['max'][i] = price
        }

        if (
          price &&
          day !== '0' &&
          genericPriceString['min'][i] &&
          parseInt(price) < parseInt(genericPriceString['min'][i])
        ) {
          genericPriceString['min'][i] = price
        } else if (!genericPriceString['min'][i] && daysArray[i] !== '0') {
          genericPriceString['min'][i] = price
        }

        if (
          price &&
          day !== '0' &&
          genericPriceString['max'][i] &&
          parseInt(price) > parseInt(genericPriceString['max'][i])
        ) {
          genericPriceString['max'][i] = price
        } else if (!genericPriceString['max'][i] && daysArray[i] !== '0') {
          genericPriceString['max'][i] = price
        }

        if (day !== '0') {
          if (day === '$') {
            if (genericDayString[i] === '0') {
              genericDayString[i] = day
            }
          } else {
            if (genericDayString[i] === '0' || genericDayString[i] === '$') {
              genericDayString[i] = day
            } else {
              const stay = parseInt(day)
              const cstay = parseInt(genericDayString[i])
              if (stay < cstay) {
                genericDayString[i] = `${stay.toString()}`
              } else {
                genericDayString[i] = `${cstay.toString()}`
              }
            }
          }
        } else if (day === '0' && genericDayString[i] === '0') {
          genericDayString[i] = day
        }
      }
    }
  })

  return {
    days: genericDayString,
    prices: genericPriceString,
  }
}

/**
 * In case of multiple rooms the sum of prices of each day is considered
 * @param {array} priceArray
 * @param {array} days
 * @returns {object}
 */
const resolveCombinedPrice = (priceArray, genericDayString) => {
  const resolvePriceOnAvailability = (priceArr) => {
    return priceArr.map((price, index) => {
      if (genericDayString[index] !== 0) {
        return price
      } else {
        return null
      }
    })
  }

  const resolvePriceSum = (priceArr, currPriceArr) =>
    priceArr.map((price, index) => {
      if (genericDayString[index] !== '0') {
        return (price ?? 0) + (currPriceArr[index] ?? 0)
      } else {
        return null
      }
    })

  const genericPriceString = priceArray.reduce((acc, priceString) => {
    if (!acc['mealplans']) {
      acc['mealplans'] = Object.entries(priceString.mealplans).reduce(
        (accMealPlanPrices, [mealplanCode, { min, max }]) => {
          accMealPlanPrices[mealplanCode] = {
            min: resolvePriceOnAvailability(min),
            max: resolvePriceOnAvailability(max),
          }
          return accMealPlanPrices
        },
        {},
      )
    } else if (acc['mealplans']) {
      Object.entries(priceString.mealplans).forEach(([mealplanCode, { min, max }]) => {
        if (!acc['mealplans'][mealplanCode]) {
          acc['mealplans'][mealplanCode] = {
            min: resolvePriceOnAvailability(min),
            max: resolvePriceOnAvailability(max),
          }
        } else if (acc['mealplans'][mealplanCode]) {
          acc['mealplans'][mealplanCode]['min'] = resolvePriceSum(min, acc['mealplans'][mealplanCode]['min'])
          acc['mealplans'][mealplanCode]['max'] = resolvePriceSum(max, acc['mealplans'][mealplanCode]['max'])
        }
      })
    }

    if (!acc['min']) {
      acc['min'] = resolvePriceOnAvailability(priceString.min)
    } else if (acc['min']) {
      acc['min'] = resolvePriceSum(priceString.min, acc['min'])
    }

    if (!acc['max']) {
      acc['max'] = resolvePriceOnAvailability(priceString.max)
    } else if (acc['max']) {
      acc['max'] = resolvePriceSum(priceString.max, acc['max'])
    }
    return acc
  }, {})

  genericPriceString.min = genericPriceString.min.join('|')
  genericPriceString.max = genericPriceString.max.join('|')

  Object.values(genericPriceString.mealplans).forEach((value) => {
    if (value.min) {
      value.min = value.min.join('|')
    }
    if (value.max) {
      value.max = value.max.join('|')
    }
  })

  return genericPriceString
}

/**
 * Reduces array of mealplans of multiple rooms into single generic mealplan object
 * @param {array} calendarDataArray
 * @returns {object}
 */
const resolveMealPlans = (multiRoomRequested) =>
  multiRoomRequested.reduce((acc, room) => {
    acc = {
      ...acc,
      ...room.mealplans,
    }
    return acc
  }, {})

/**
 * Adds explicit "$" to enable checkouts in calendar
 * @param {array} calendarDays
 * @param {array} closedto
 * @returns {string}
 */
const resolveExplicitCheckout = (calendarDays) =>
  calendarDays
    .map((day, index) => {
      if (day === '0' && index !== 0 && calendarDays[index - 1] !== '0') {
        return '$'
      } else {
        return day
      }
    })
    .join('|')

/**
 * Adds blacklisted stay count which could appear in all rooms generic days string or in each room specifically
 * @param {string} genericDayString
 * @param {string} genericMaxStayString
 * @param {array} calendar
 * @returns {array}
 */
const resolveBlacklistedStays = (genericDayString, genericMaxStayString, calendar, roomCodeToAvailRef) => {
  const blacklistedStays = Array(genericDayString.length)
  const stayGapsBetweenRooms = Array(genericDayString.length)
  const daysArray = calendar.map((c) => ({ room_code: c.room_code, rate_code: c.rate_code, days: c.days }))
  const maxInMinStays = []
  const minInMinStays = []
  for (let i = 0; i < genericDayString.length; i++) {
    const minStaysofAllRooms = daysArray.reduce((acc, { days }) => {
      const minStay = parseInt(days[i])
      if (!isNaN(minStay) && minStay > 0) {
        acc.push(minStay)
      }
      return acc
    }, [])
    maxInMinStays.push((minStaysofAllRooms.length && Math.max(...minStaysofAllRooms)) || 0)
    minInMinStays.push((minStaysofAllRooms.length && Math.min(...minStaysofAllRooms)) || 0)
  }
  
  for (let i = 0; i < genericDayString.length; i++) {
    blacklistedStays[i] = [0]
    stayGapsBetweenRooms[i] = [0]
    const reduceAvailOfRooms = new Set()
    
    //Stay gaps in between rooms. Could appear when more than one rooms are merged.
    if (minInMinStays[i] !== maxInMinStays[i] && maxInMinStays[i] !== 0 && minInMinStays[i] !== 0) {
      for (let j = minInMinStays[i]; j <= maxInMinStays[i]; j++) {
        stayGapsBetweenRooms[i].push(j)
      }
      for (let j = 0; j < daysArray.length; j++) {
        const roomMinStayOfEachDay =
          !isNaN(parseInt(daysArray[j]['days'][i])) && parseInt(daysArray[j]['days'][i]) > 0
            ? parseInt(daysArray[j]['days'][i])
            : 0

        if (!stayGapsBetweenRooms[i].length || stayGapsBetweenRooms[i].every((e) => e === 0)) {
          break
        }

        if (roomMinStayOfEachDay === 0) {
          continue
        }

        for (let k = roomMinStayOfEachDay; k <= maxInMinStays[i]; k++) {
          const tempStay = daysArray[j]['days'][i + k - 1]
          const poppingItem = k
          if (parseInt(tempStay) === 0) {
            break
          }
          const indexOfPop = stayGapsBetweenRooms[i].indexOf(poppingItem)
          if (indexOfPop > 0) {
            stayGapsBetweenRooms[i].splice(indexOfPop, 1)
            reduceAvailOfRooms.add(daysArray[j]['room_code'])
          }
        }
      }
    }

    //Blacklist stays usecase. Could appear inside specific room.
    if (genericDayString[i] === '0' || genericDayString[i] === '$') {
      continue
    }
    for (let j = parseInt(genericDayString[i]); j <= parseInt(genericMaxStayString[i]); j++) {
      blacklistedStays[i].push(j)
    }
    calendar.forEach((rateplan) => {
      const { days: min_los, max_los, max_stay_thru, min_stay_thru, closedto, prices, room_code } = rateplan
      for (let stay = parseInt(genericDayString[i]); stay <= parseInt(genericMaxStayString[i]); stay++) {
        //Checkin not allowed by rateplan so iterate other and keep blacklisted as it is
        if (
          min_los[i] === '$' ||
          min_los[i] === '0' ||
          min_los.slice(i, i + parseInt(min_los[i])).some((ele) => ele === '0') ||
          min_los[i + stay - 1] === '0' ||
          !prices[i] ||
          !prices.slice(i, i + stay).every((ele) => !!ele) ||
          !roomCodeToAvailRef[room_code][i] ||
          !roomCodeToAvailRef[room_code].slice(i, i + stay).every((ele) => !!ele)
        ) {
          return
        }
        //Stay gaps between rateplans of same room.
        if (stay < parseInt(min_los[i])) {
          continue
        }
        //Stays Uplifting
        if (min_stay_thru[i] !== '-' && stay < parseInt(min_stay_thru[i])) {
          continue
        } else if (min_stay_thru.slice(i, i + stay).some((ele) => parseInt(ele) > stay)) {
          continue
        }
        //max_los restriction of kognitiv
        if (
          max_los[i] !== '0' &&
          max_los[i] !== '$' &&
          max_stay_thru[i] !== '0' &&
          ((max_stay_thru[i] !== '-' && stay > parseInt(max_stay_thru[i])) ||
            (max_los[i] !== '-' && stay > parseInt(max_los[i])))
        ) {
          return
        }
        //closed for arrival/departure
        if (closedto[i] === '1' || closedto[i] === '3') {
          return
        } else if (closedto[i + stay] === '2' || closedto[i + stay] === '3') {
          continue
        }
        const indexOfStay = blacklistedStays[i].indexOf(stay)
        if (indexOfStay > 0) {
          blacklistedStays[i].splice(indexOfStay, 1)
          reduceAvailOfRooms.add(room_code)
        }
      }
    })
    ;[...reduceAvailOfRooms].forEach((roomCode) => {
      roomCodeToAvailRef[roomCode][i] = roomCodeToAvailRef[roomCode][i] - 1
    })

    //Merge both the blacklist arrays
    blacklistedStays[i] = [...new Set([...blacklistedStays[i], ...stayGapsBetweenRooms[i]])].sort((a, b) =>
      a < b ? -1 : 1,
    )
  }

  return blacklistedStays
}

/**
 * Merges blacklisted stays string of multiple rooms in positive manner
 * @param {array} blacklistedStays
 * @returns string
 */
const resolveBlacklistedStaysInPositive = async (blacklistedStays) =>
  blacklistedStays
    .reduce((acc, curr) => {
      if (!acc.length) {
        acc = [...curr]
      } else {
        curr.forEach((ele, index) => {
          acc[index] = [...new Set(acc[index].concat(ele))].sort((a, b) => (a < b ? -1 : 1))
        })
      }
      return acc
    }, [])
    .map((ele) => ele.join(','))
    .join('|')

/**
 * Creates an array of prices as per the required occupancy
 * @param {array} dayRates
 * @param {object} occupancy
 * @param {object} params
 * @returns {array}
 */
const resolveXMLPrice = ({ dayRates }, occupancy, params) => {
  return dayRates?.map((price) => {
    let total = 0
    const { adults, children } = occupancy
    if (!price) {
      return null
    }
    if (adults && !price.adults) {
      return null
    }
    if (children && children.length  && !price.children && !price.adults.additional) {  
      return null
    }
    if (price?.adults?.[adults]) {
      total += price.adults[adults]
    } else if (price?.adults?.additional) {
      const maxAdultCount = Math.max(...Object.keys(price.adults).filter((p) => !isNaN(p)))
      total += price.adults[maxAdultCount.toString()] + (adults - maxAdultCount) * price.adults.additional
    } else {
      return null
    }

    if (children && children.length) {
      if (price.children) {
        const ageToPriceMap = Object.entries(price.children).reduce((acc, [ageRange, price]) => {
          const [min, max] = strSplit('-', ageRange)
          for (let i = parseInt(min); i <= parseInt(max); i++) {
            acc[i] = price
          }
          return acc
        }, {})

        if (children.every((v) => ageToPriceMap.hasOwnProperty(v))) {
          children.forEach((age) => {
            total += ageToPriceMap[age]
          })
        } else if (children.some((v) => ageToPriceMap.hasOwnProperty(v)) && price.adults.additional) {
          children.forEach((age) => {
            if (ageToPriceMap[age]) {
              total += ageToPriceMap[age]
            } else {
              total += price.adults.additional
            }
          })
        } else if (price.adults.additional) {
          children.forEach(() => {
            total += price.adults.additional
          })
        } else {
          return null
        }
      } else if (price.adults.additional) {
        total += price.adults.additional * children.length
      } else {
        return null
      }
    }
    if (params?.config?.booking?.calendar?.pricetype === 'single') {
      total = (total / (adults + (children?.length || 0))).toFixed(2) * 1
    }
    return total
  })
}

const resolveOffersOverviewToCalendar = async (rooms, offersOverview, XMLRates, params, occupancy) => {
  const { mergeType = 'RATEPLANS' } = params
  const offerCodes = params.offerCode ? strSplit(',', params.offerCode) : []
  const skipPriceOfRooms = params?.skipPriceOfRooms ? strSplit(',', params.skipPriceOfRooms) : []
  const promotionCodes = params?.promotionCodes ? strSplit(',', params.promotionCodes) : []
  const calendar = []
  const mealplans = {}
  for (let rate of offersOverview.entities.filter((et) =>
  offerCodes.length ? offerCodes.includes(et.rate_code) : true,
  )) {
    const rateOfXML = XMLRates?.[rate['room_code']]?.[rate['rate_code']]
    
    if (!rooms.includes(rate['room_code']) || !rateOfXML) {
      continue
    }

    if (rateOfXML.promotionCode && !promotionCodes.includes(rateOfXML.promotionCode)) {
      continue
    }

    const getAssortedData = async () => {
      const stringsFromXML = rateOfXML.dayRates.reduce(
        (acc, cur, idx) => {
          acc.minstay[idx] = params.allDaysAvailable ? '1' : cur?.minstay || '-'
          acc.maxstay[idx] = params.allDaysAvailable ? '-' : cur?.maxstay || '-'
          acc.minstaythru[idx] = params.allDaysAvailable ? '-' : cur?.minstaythru || '-'
          acc.maxstaythru[idx] = params.allDaysAvailable ? '-' : cur?.maxstaythru || '-'
          return acc
        },
        {
          minstay: Array(rateOfXML.dayRates.length),
          maxstay: Array(rateOfXML.dayRates.length),
          minstaythru: Array(rateOfXML.dayRates.length),
          maxstaythru: Array(rateOfXML.dayRates.length),
        },
      )

      if (params.allDaysAvailable) {
        rate.restrictions = rate.restrictions.replace(/./g, 'a')
        rate.restrictions_max_los = rate.restrictions_max_los.replace(/./g, 'z')
        rate.restrictions_min_stay_thru = rate.restrictions_min_stay_thru.replace(/./g, 'a')
        rate.restrictions_max_stay_thru = rate.restrictions_max_stay_thru.replace(/./g, 'a')
        rate.changeOver = rate.changeOver.replace(/./g, '0')
      }

      const [days, min_los, min_stay_thru, max_los, max_stay_thru] = await Promise.all([
        convertToDaysString(rate.restrictions, stringsFromXML),
        stringDecoder(rate.restrictions, stringsFromXML.minstay, DECRYPT_RESTRICTIONS),
        stringDecoder(rate.restrictions_min_stay_thru, stringsFromXML.minstaythru, DECRYPT_RESTRICTIONS_MIN_STAY_THRU),
        stringDecoder(rate.restrictions_max_los, stringsFromXML.maxstay, DECRYPT_RESTRICTIONS_MAX_LOS),
        stringDecoder(rate.restrictions_max_stay_thru, stringsFromXML.maxstaythru, DECRYPT_RESTRICTIONS_MAX_STAY_THRU),
      ])

      return {
        room_code: rate['room_code'],
        rate_code: rate['rate_code'],
        isPackage: rate.isPackage,
        meal_plan_code: rate['meal_plan_code'] || DEFAULT_MEALPLANCODE,
        days,
        min_los,
        min_stay_thru,
        max_los,
        max_stay_thru,
        closedto: rate.changeOver,
        prices:
          skipPriceOfRooms.length && skipPriceOfRooms.includes(rate['room_code'])
            ? []
            : resolveXMLPrice(rateOfXML, occupancy, params),
      }
    }

    const mealplanCode = rate['meal_plan_code'] || DEFAULT_MEALPLANCODE

    switch (mergeType) {
      case 'RATEPLANS':
        if (!rate.isPackage) {
          calendar.push(await getAssortedData())
          mealplans[mealplanCode] =
            mealplanCode === DEFAULT_MEALPLANCODE
              ? mealPlanCodes[mealplanCode][params.language]
              : offersOverview.mealPlans[mealplanCode]
        }
        break

      case 'OFFERS':
        if (rate.isPackage) {
          calendar.push(await getAssortedData())
          mealplans[mealplanCode] =
            mealplanCode === DEFAULT_MEALPLANCODE
              ? mealPlanCodes[mealplanCode][params.language]
              : offersOverview.mealPlans[mealplanCode]
        }
        break

      case 'RATEPLANS_AND_OFFERS':
        calendar.push(await getAssortedData())
        mealplans[mealplanCode] =
          mealplanCode === DEFAULT_MEALPLANCODE
            ? mealPlanCodes[mealplanCode][params.language]
            : offersOverview.mealPlans[mealplanCode]
        break
    }
  }

  return {
    calendar,
    mealplans,
  }
}

/**
 * Resolves calendar data for each room
 * @param {object} param0
 * @param {object} param1
 * @param {object} params
 * @returns {object}
 */
const resolveCalendarPerRoom = async (rooms, offersOverview, XMLRates, params, occupancy, roomCodeToAvailRef) => {
  const { calendar, mealplans } = await resolveOffersOverviewToCalendar(
    rooms,
    offersOverview,
    XMLRates,
    params,
    occupancy,
  )
  const { days: genericDayString, prices: genericPriceString } = resolveDayAndPriceString(calendar, params)

  const [genericClosedto, genericMaxDayString] = await Promise.all([
    resolveClosedTo(calendar),
    resolveMaxStay(calendar),
  ])

  const genericBlacklistedStaysString = resolveBlacklistedStays(
    genericDayString,
    genericMaxDayString,
    calendar,
    roomCodeToAvailRef,
  )
  return {
    days: genericDayString,
    prices: genericPriceString,
    closedto: genericClosedto,
    maxstay: genericMaxDayString,
    blacklistedStays: genericBlacklistedStaysString,
    mealplans,
  }
}

/**
 * Creates an array of room codes which support the required occupancy
 * @param {array} occupancy
 * @param {object} property
 * @param {array} roomCodes
 * @returns {array}
 */
const resolveRoomsWithSupOcc = (occupancy, property, roomCodes = '') => {
  roomCodes = roomCodes ? strSplit(',', roomCodes) : ''
  return occupancy.map(({ adults, children }) => {
    adults = Number(adults)
    children = children && children.length ? children.map(Number) : []
    return property.facility?.rooms.reduce((acc, room) => {
      if (
        adults + children.length >= room.min_occup &&
        adults + children.length <= room.max_occup &&
        adults >= (room.min_adult_occup ?? Number.MIN_SAFE_INTEGER) &&
        adults <= (room.max_adult_occup ?? Number.MAX_SAFE_INTEGER) &&
        children.length >= (room.min_child_occup ?? Number.MIN_SAFE_INTEGER) &&
        children.length <= (room.max_child_occup ?? Number.MAX_SAFE_INTEGER) &&
        (!roomCodes || roomCodes.includes(room.code))
      ) {
        acc = acc.concat(`${acc ? ',' : ''}${room.code}`)
      }
      return acc
    }, '')
  })
}

// resolver for internal call
const resolveCalendar = async ({ dataSources, db }, { property, token }, params) => {
  const roomsWithSupOcc = resolveRoomsWithSupOcc(params.rooms, property, params.roomCode)

  const [offersOverview, XMLRates] = await Promise.all([
    queryOffersOverview(db, params.config, params.language),
    resolveRates({ db }, { property }, params),
  ])

  const roomCodeToRoomDetails = property.facility?.rooms?.reduce((acc, room) => {
    acc[room.code] = room
    return acc
  }, {})

  const roomCodeToAvailRef = offersOverview.overview.entities.reduce((acc, cur) => {
    if (!acc[cur.room_code]) {
      acc[cur.room_code] = params.allDaysAvailable
        ? Array(cur.availabilities.length).fill(roomCodeToRoomDetails[cur.room_code].quantity)
        : [...cur.availabilities]
    }
    return acc
  }, {})
  const multiRoomRequested = await Promise.all(
    roomsWithSupOcc.map((room, index) =>
      resolveCalendarPerRoom(
        strSplit(',', room),
        offersOverview.overview,
        XMLRates,
        params,
        params.rooms[index],
        roomCodeToAvailRef,
        ),
        ),
        )
    const [genericDayString, genericMaxDayString, genericBlacklistedStaysString] = await Promise.all([
      resolveAllRoomsDayStringInNegative(multiRoomRequested.map((c) => c.days)),
      resolveAllRoomsDayStringInNegative(multiRoomRequested.map((c) => c.maxstay)),
      resolveBlacklistedStaysInPositive(multiRoomRequested.map((c) => c.blacklistedStays)),
    ])

  const [genericPriceString, genericClosedto] = await Promise.all([
    resolveCombinedPrice(
      multiRoomRequested.map((c) => c.prices),
      genericDayString,
    ),
    resolveCombinedClosedToOfAllOccup(multiRoomRequested.map((c) => c.closedto)),
  ])
// console.log("offersOverview.overview.currency", offersOverview.overview)
  return {
    meal_plans: resolveMealPlans(multiRoomRequested),
    days: genericDayString,
    maxstay: genericMaxDayString,
    closedto: genericClosedto,
    prices: genericPriceString,
    blacklistedStays: genericBlacklistedStaysString,
    currency_code: offersOverview.overview.currency,
    timezone: timeWithTimeZone('Europe/Berlin', dateToday(), 12, 0, 0),
  }
}

//resolver for dynamic call
const calendarResolver = async (parent, params, context, info) => {
  const { cache, ttl } = context
  const { userId, provider, language } = parent.params.options
  const key = generateCacheKey('calendar', params, userId, provider, language)
  const cacheHit = await cache?.get(key)
  if (cacheHit) {
    return JSON.parse(cacheHit)
  } else {
    const cacheableValue = await resolveCalendar(context, parent.params, { ...parent.params.options, ...params })
    cache?.setEx(key, ttl, JSON.stringify(cacheableValue))
    return cacheableValue
  }
}

module.exports = {
  calendarResolver, //dynamic call
  resolveCalendar, //internal call
}
