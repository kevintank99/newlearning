const { resolveRates } = require('./resolveRates')
const { mealPlanCodes } = require('../constants')
const { dateToday } = require('../../../utils/date')
const { dateDiffDays } = require('../../../utils/date')
const { dateFrom } = require('../../../utils/date')
const { DEFAULT_MEALPLANCODE } = require('../constants')
const generateCacheKey = require('../../../cache/L1Cache/generateCacheKey')
const queryRatesAverage = require('../queriers/queryRatesAverage')

/**
 * Resolves the minimum stay duration of offer.
 * @param {Object} offer
 * @returns {Number}
 */
const resolveMinimumStay = (offer) => {
  return Math.min(...Object.values(offer.min_los_per_week_day))
}

/**
 * Resolves minimum/maximum price of offer
 * @param {Object} ratesOfOffer
 * @param {*} ratesOfRateplan
 * @param {*} offer
 * @param {*} minStay
 * @param {*} priceType
 * @param {*} occupancy
 * @returns
 */
const resolvePrice = (ratesOfOffer, ratesOfRateplan, offer, minStay, priceType, occupancy) => {
  const { availableOnly, dayRates: offerDayRates } = ratesOfOffer
  let minimumRateForStay = 0
  let maximumRateForStay = 0

  if (offer.type === 'DayRate') {
    //Calculates the offer price total for span of minimum stay and opts the minimum price.
    const { dayRates: rateplanDayRates } = ratesOfRateplan
    const today = dateToday()
    availableOnly.forEach((period) => {
      const offerStart = today > dateFrom(period.Start) ? today : dateFrom(period.Start)
      const offerEnd = dateFrom(period.End)

      const offset = dateDiffDays(today, offerStart)
      const end = Math.min(dateDiffDays(today, offerEnd), rateplanDayRates.length)

      for (let i = offset; i < end; i++) {
        let offerTotal = 0
        const ratesForMinStay = rateplanDayRates.slice(i, i + minStay).map((rate) => rate?.adults?.[occupancy])
        if (!ratesForMinStay.every((rate) => rate) || ratesForMinStay.length !== minStay) {
          continue
        }
        for (let j = 0; j < minStay; j++) {
          //Count the room price of the standard occupancy for min stay
          offerTotal += parseInt(ratesForMinStay[j])
        }
        offerTotal += Math.abs(
          parseInt(rateplanDayRates?.[i]?.adults?.[occupancy]) - parseInt(offerDayRates?.[i]?.adults?.[occupancy]),
        )
        minimumRateForStay =
          offerTotal < minimumRateForStay || minimumRateForStay === 0 ? offerTotal : minimumRateForStay
        maximumRateForStay =
          offerTotal > maximumRateForStay || maximumRateForStay === 0 ? offerTotal : maximumRateForStay
      }
    })
  } else if (offer.type === 'FixPrice') {
    //No need to calculate offer price total. It gives that out-of-the-box.
    offerDayRates.forEach((day) => {
      if (!day) {
        return
      }
      const { adults } = day
      if (!minimumRateForStay || parseInt(minimumRateForStay) > parseInt(adults[occupancy])) {
        minimumRateForStay = adults[occupancy]
      }
      if (!maximumRateForStay || parseInt(maximumRateForStay) > parseInt(adults[occupancy])) {
        maximumRateForStay = adults[occupancy]
      }
    })
  }

  //Price could be based on standard occupancy or per person
  if (priceType == 'SINGLE') {
    return { price: { min: +minimumRateForStay / +occupancy, max: +maximumRateForStay / +occupancy } }
  }
  return { price: { min: minimumRateForStay, max: maximumRateForStay } }
}

/**
 * Reolves room offer details in structured format
 * @param {Array} availableOffers
 * @param {String} language
 * @param {String} priceType
 * @returns {Array}
 */
const resolveRoomAndOffers = (availableOffers, { language, priceType }) => {
  return availableOffers.reduce((acc, availableOffer) => {
    const { room, offer, ratesOfOffer, ratesOfRateplan } = availableOffer
    const minStay = resolveMinimumStay(offer)
    const { price } = resolvePrice(ratesOfOffer, ratesOfRateplan, offer, minStay, priceType, room.std_occupancy)
    if (offer.type === 'DayRate' && (!price.min || !price.max)) {
      return acc
    }
    return (
      acc.push({
        code: offer.code,
        roomCode: room.code,
        title: offer.title,
        teaser: offer.teaser,
        description: offer.description,
        images: offer.imagesInfo,
        minStay,
        price,
        availabilityPeriod: ratesOfOffer?.availableOnly,
        mealPlanInfo: {
          [offer.meal_plan_code || DEFAULT_MEALPLANCODE]:
            mealPlanCodes[offer.meal_plan_code || DEFAULT_MEALPLANCODE][language],
        },
        minimumOccupancy: room.min_occupancy,
        standardOccupancy: room.std_occupancy,
        maximumOccupancy: room.max_occupancy,
      }) && acc
    )
  }, [])
}

/**
 * Resolves applicable rooms
 * @param {Object} property
 * @param {Object} params
 * @returns {Array}
 */
const resolveRooms = (property, params) =>
  property.facility?.rooms.reduce((acc, r) => {
    const roomCode = (params.roomCode && params.roomCode.split(',')) || [r.code]
    if (roomCode.includes(r.code)) {
      acc.push(r.code)
    }
    return acc
  }, [])

const resolveRoomOffers = async ({ dataSources, db }, { property, token }, params) => {
  const [ratesXML, ratesAverage] = await Promise.all([
    resolveRates({ db }, { property }, params),
    queryRatesAverage(db, params.config, params.language),
  ])

  const rooms = resolveRooms(property, params)

  const availableOffers = rooms.reduce((acc, roomCode) => {
    acc[roomCode] = ratesAverage.packages.reduce((prev, offer) => {
      const isOfferInRoomIndex = offer?.rooms.findIndex((r) => r.code === roomCode)
      const offerCode = (params.offerCode && params.offerCode.split(',').map((e) => e.trim())) || [offer?.code]
      if (isOfferInRoomIndex !== -1 && offerCode.includes(offer?.code)) {
        ratesXML?.[roomCode]?.[offer.code] &&
          prev.push({
            roomCode,
            offer,
            ratesOfOffer: ratesXML?.[roomCode]?.[offer.code],
            ratesOfRateplan: ratesXML?.[roomCode]?.[ratesXML?.[roomCode]?.[offer.code]?.baseRateCode],
            room: ratesAverage.rooms.find((room) => room.code === roomCode),
          })
      }
      return prev
    }, [])
    return acc
  }, {})

  return Promise.all(
    rooms.map((room) =>
      resolveRoomAndOffers(availableOffers[room], {
        ...params,
        priceType: params?.config?.rooms?.pricetype || params.priceType,
      }),
    ),
  ).then((res) => res.flat())
}

const roomOffersResolver = async (parent, params, context, info) => {
  const { cache, ttl } = context
  const { userId, provider, language } = parent.params.options
  const key = generateCacheKey('roomOffers', params, userId, provider, language)
  const cacheHit = await cache?.get(key)
  if (cacheHit) {
    return JSON.parse(cacheHit)
  } else {
    const cacheableValue = await resolveRoomOffers(context, parent.params, { ...parent.params.options, ...params })
    cache?.setEx(key, ttl, JSON.stringify(cacheableValue))
    return cacheableValue
  }
}

module.exports = {
  roomOffersResolver, //dynamic call
  resolveRoomOffers, //internal call
}
