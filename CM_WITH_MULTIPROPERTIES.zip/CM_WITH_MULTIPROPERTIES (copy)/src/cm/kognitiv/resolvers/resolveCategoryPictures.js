//find image_items with info_code=null and detail_code=null = full gallery with texts
const resolvePicturesData = (mm_descriptions) => 
  mm_descriptions.reduce((acc, {info_code, detail_code, image_items}) => {
    if (info_code == null && detail_code == null && image_items.length) {
      acc = [...acc, ...image_items]
    }
    return acc
  }, [])

const resolvePictureTitle = (descriptions, options) => 
  descriptions.reduce((acc, {language, content}) => {
    let title = content
    if (content.match(/^[A-Z0-9_]+(\s|$)/)) {
      [acc.category, title] = content.indexOf('-') > -1 ? content.split(/\s*-\s*/) : [content, ""] //check if it is CATEGORY_CODE - Some Title  - with title
    } else if (content.match(/^\[[A-Za-z0-9_]+\]/)) {
      [acc.category, title] = content.split(/\]\s*/) //check if it is CATEGORY_CODE - Some Title  - with title
      acc.category = acc.category.substr(1)
    }
    if (language.toLowerCase() == options.language) {
      acc.title = title
    }
    return acc
  }, {title: null})

//full picture gallery for a property is in info.descriptions.mm_descriptions with info_code=null and detail_code=null
//categories are in ext.classifications.0.items
//pictures whose title contains one or more category codes in the title are the images for those (property)categories
//pictures "category" is different, it is a fixed list of ~15 codes - it is renamed to "topic.code"
const resolvePictures = (propertyData, options) => {
  //find image_items with info_code=null and detail_code=null = full gallery with texts
  return resolvePicturesData(propertyData.info.descriptions.mm_descriptions)
  //reduce the images to plain array
  .reduce((acc, {category, image_formats, descriptions}) => {
    let width, height, file_size
    ({width, height, file_size, url} = image_formats[0])
    acc.push({
      topic: category,
      width, 
      height, 
      size: file_size,
      ...resolvePictureTitle(descriptions, options),
      url
    })
    return acc
  }, new Array)
}

module.exports = {
  resolvePicturesData,
  resolvePictures
}
