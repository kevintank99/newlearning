const generateCacheKey = require("../../../cache/L1Cache/generateCacheKey");
const { countryCodes, roomTypes, mealPlanCodes } = require("../constants");
const { resolveChildAges } = require("./resolveChildAges");
const { resolveOffers } = require("../resolvers/resolveOffers");
const { resolvePictures } = require("./resolvePictures");



const resolveMealPlan = async(roomPlan, language)=>{

  const hotelMealPlan = {}
  const MealPlan = []
  roomPlan.map((data)=>{
    if(!hotelMealPlan[data.hotelCode]){
      hotelMealPlan[data.hotelCode] = []
    }
    if(hotelMealPlan[data.hotelCode] === 0 || !hotelMealPlan[data.hotelCode].includes(mealPlanCodes[data.meal_plan_code][language])){
      hotelMealPlan[data.hotelCode].push(mealPlanCodes[data.meal_plan_code][language])
    }
  })
  for (const key in hotelMealPlan) {
    MealPlan.push({
      hotelCode : key,
      mealPlanList : [...hotelMealPlan[key]],
      keyType: 'meal_Plan'
    })
  }
  return MealPlan
}

const resolveAddress =  ({addresses},language) =>{
  const address = addresses.reduce((acc,address)=>{
       acc.push({
        addresslines: address.addresslines[0],
        city: address.city,
        country : countryCodes[address.country.code][language],
       })
       return acc
  },[])
   return address
}

const resolvePrice = async(hotelRatePlane)=>{
  const hotelPrice = {}
  hotelRatePlane.map((data)=>{
    data.keyType = 'priceList'
    if(!hotelPrice[data.hotelCode]){
      hotelPrice[data.hotelCode] = []
    }
    if(hotelPrice[data.hotelCode].length == 0){
      hotelPrice[data.hotelCode].push(data)
    }else if(hotelPrice[data.hotelCode][0].total >= data.total){
      hotelPrice[data.hotelCode][0] = data
    } 
  })
  return Object.values(hotelPrice)
}

const resolveDescriptions = (descriptions,options) =>{
  const hotelDescriptions = descriptions.reduce((acc,{detail_code,text_items,hotelCode})=>{
    if(text_items){
      let descriptionIndex = text_items.findIndex(x=>x.language.toLowerCase() === options.language)
      if(descriptionIndex !== -1){
        acc.push({
          detail_code,
          ...text_items[descriptionIndex],
          hotelCode,
          keyType: 'text_items'
        })
      }
    }
    return acc
  },[])
  return hotelDescriptions
}

const resolveAmenities = async(amenities)=>{
  const listOfAmenity = {}
  amenities.map((amenity)=>{
    const {hotelCode ,keyType,...rest} = amenity
    if(!listOfAmenity[amenity.code]){
      listOfAmenity[amenity.code] = {}
      listOfAmenity[amenity.code] = rest
    }
  });
  return listOfAmenity
}

const resolveRoomType = async(rooms,language)=>{
  for (let index = 0; index < rooms.types.length; index++) {
    const element = rooms.types[index].type;
    return roomTypes[element][language]
  }
}

const resolveHotels = async(propertyData, options,contex,params)=>{
  // mergeHotel Information
  const hotelAmenities = propertyData.info.amenities
  const contacts =  propertyData.contacts
  const name = propertyData.info.name
  const mm_descriptions = propertyData.info.descriptions.mm_descriptions
  const rooms = propertyData.facility.rooms

  // required resolver's call 
  const text_items = resolveDescriptions(mm_descriptions,options)
  const images_items = resolvePictures(propertyData,options)
  const childData = await resolveChildAges(propertyData, options)
  const { allRateplans } = await resolveOffers(contex,params,options)

  // new internal resolver
  const mealPlanList = await resolveMealPlan(allRateplans,options.language)
  const data =  (await resolvePrice(allRateplans))
  const priceList = data.flat()

  // seprate the data hotel wise with hotel code 
  const childrenRange =  {min : [],max: []}
  const filterData =  { amenities : [], destination : [], priceRang : {min : 0 ,max: 0},roomTypes:[],childrenRange:  {min : 0 ,max: 0}, mealPlan : [] }
  const hotelGroupedData = {};
  const destination = [];
  [...hotelAmenities, ...contacts,...childData,...name,...priceList,...images_items,...text_items,...rooms,...mealPlanList].forEach(async (item) => {
      const {hotelCode,keyType,...rest} = item
      if (!hotelGroupedData[hotelCode]) {
          hotelGroupedData[hotelCode] = {  info : {amenities: [],name: [],descriptions:{image_items : [],text_items: []},mealPlan : []  }, facility: { rooms : {types : []}}, contacts: [], ext : {children: []},price:[] };
      }    
      switch (keyType) {
        case 'amenities':
          hotelGroupedData[hotelCode].info.amenities.push(rest)
        break;
        case 'name':
          hotelGroupedData[hotelCode].info.name.push(rest)
        break;
        case 'contacts':
          const addressDetails = await resolveAddress(item, options.language)
          destination.push(...addressDetails)
          hotelGroupedData[hotelCode].contacts.push(...(addressDetails))
        break;
        case 'children':
          hotelGroupedData[hotelCode].ext.children.push(rest)
          childrenRange.min.push(rest.fromAge)
          childrenRange.max.push(rest.toAge)
        break;
        case 'priceList':
          hotelGroupedData[hotelCode].price.push(rest)
        break;
        case 'image_items':
          hotelGroupedData[hotelCode].info.descriptions.image_items.push(rest)
        break;
        case 'text_items':
          hotelGroupedData[hotelCode].info.descriptions.text_items.push(rest)
        break;
        case 'rooms':
          const results = await resolveRoomType(rest,options.language)
          if(!hotelGroupedData[hotelCode].facility.rooms.types.includes(results)){
            hotelGroupedData[hotelCode].facility.rooms.types.push(results)
          }
        break;
        case 'meal_Plan':
          const {mealPlanList} = rest
          hotelGroupedData[hotelCode].info.mealPlan.push(...mealPlanList)
          filterData.mealPlan.push(...mealPlanList)
        break;
        default:
          break;
      }
  });


  //filter array of objects
  filterData.amenities.push(await resolveAmenities(propertyData.info.amenities))

  filterData.destination = [...new Set(destination.map((key)=> Object.values(key)[1]))]
  
  await  rooms.map(async(data)=>{filterData.roomTypes.push(await resolveRoomType(data,options.language))})
  filterData.roomTypes =  [...new Set(filterData.roomTypes)]

  filterData.mealPlan = [...new Set(filterData.mealPlan)]
  
  const priceTotal = allRateplans.map((rate)=>rate.total)
  filterData.priceRang.max = Math.max(...priceTotal)
  filterData.priceRang.min = Math.min(...priceTotal)
 
  filterData.childrenRange.min = Math.min(...childrenRange.min)
  filterData.childrenRange.max = Math.max(...childrenRange.max)

  // final Object to return
  const outputObjects = [];
  for (const hotelCode in hotelGroupedData) {
    const hotelObject = hotelGroupedData[hotelCode];
    hotelObject.hotelCode = hotelCode;
    outputObjects.push({...hotelObject,hotelCode : hotelObject.hotelCode}); 
  }
  return {hotelInfo : outputObjects,filterInfo : filterData}
}

const hotelsResolver =  async (parent, params, context, info)=>{
  const { cache, ttl } = context
  const { userId, provider, language } = parent.params.options
  const key = generateCacheKey('hotels', params, userId, provider, language)
  const cacheHit = await cache?.get(key)
  if (cacheHit) {
    return JSON.parse(cacheHit)
  } else {
    const cacheableValue = await resolveHotels(parent.params.property, { ...parent.params.options, ...params }, context, parent.params)
    cache?.setEx(key, ttl, JSON.stringify(cacheableValue))
    return cacheableValue
  }
}

module.exports = {
  hotelsResolver,
  resolveHotels,
}