const generateCacheKey = require('../../../cache/L1Cache/generateCacheKey')
const { strSplit } = require('../../../utils/string')
const { mealPlanCodes, DEFAULT_MEALPLANCODE } = require('../constants')
const queryOffersOverview = require('../queriers/queryOffersOverview')
const { resolveRates } = require('./resolveRates')

const resolveMealplans = async ({ dataSources, db }, { property, token }, params) => {
  const [offersOverview, XMLRates] = await Promise.all([
    queryOffersOverview(db, params.config, params.language),
    resolveRates({ db }, { property }, params),
  ])

  const roomCodes = params?.roomCode?.split(',') || []
  const promotionCodes = params?.promotionCodes ? strSplit(',', params.promotionCodes) : []

  return offersOverview.overview.entities.reduce((acc, rateplan) => {
    const rateOfXML = XMLRates?.[rateplan['room_code']]?.[rateplan['rate_code']]

    if (!rateOfXML || (rateOfXML.promotionCode && !promotionCodes.includes(rateOfXML.promotionCode))) {
      return acc
    }

    if (!params.includeOffers && rateplan.isPackage) {
      //Skip offers
      return acc
    }

    if (!roomCodes.length || roomCodes.includes(rateplan.room_code)) {
      const mealplanCode = rateplan['meal_plan_code'] || DEFAULT_MEALPLANCODE
      acc[mealplanCode] =
        mealplanCode === DEFAULT_MEALPLANCODE
          ? mealPlanCodes[mealplanCode][params.language]
          : offersOverview.overview.mealPlans[mealplanCode]
    }

    return acc
  }, {})
}

//resolver for dynamic call
const mealplansResolver = async (parent, params, context, info) => {
  const { cache, ttl } = context
  const { userId, provider, language } = parent.params.options
  const key = generateCacheKey('mealplans', params, userId, provider, language)
  const cacheHit = await cache?.get(key)
  if (cacheHit) {
    return JSON.parse(cacheHit)
  } else {
    const cacheableValue = await resolveMealplans(context, parent.params, { ...parent.params.options, ...params })
    cache?.setEx(key, ttl, JSON.stringify(cacheableValue))
    return cacheableValue
  }
}

module.exports = {
  mealplansResolver, //dynamic call
  resolveMealplans, //internal call
}
