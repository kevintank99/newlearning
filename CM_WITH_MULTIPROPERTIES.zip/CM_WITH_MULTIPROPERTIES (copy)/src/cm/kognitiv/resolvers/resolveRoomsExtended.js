const fetchOffersOverview = require("../datasources/fetchOffersOverview");
const fetchRatesAverage = require("../datasources/fetchRatesAverage");
const { resolveRoomCategories } = require('./resolveRoomCategories')
const { resolveRates } = require('./resolveRates')
const { resolveSeasons } = require('./resolveSeasons')
const { mealPlanCodes } = require('../constants')
const { dateIsoFormat, dateToday, dateFrom, dateAddDays, dateDiffDays } = require('../../../utils/date');
const { bedTypes, bedTypeAmenityCodes, roomTypes, roomTypesCamping, hotelOnlyRoomAmenities } = require('../constants')

const DECRYPT_RESTRICTIONS = {
    "1": 0,
    "2": 0,
    "3": 0,
    "4": 0,
    "5": 0,
    "6": 0,
    "7": 0,
    "A": "$",
    "a": 1,
    "b": 2,
    "c": 3,
    "d": 4,
    "e": 5,
    "f": 6,
    "g": 7,
    "h": 8,
    "i": 9,
    "j": "a",
    "k": "b",
    "l": "c",
    "m": "d",
    "n": "e",
    "o": "f",
    "p": "g",
    "q": "h",
    "r": "i",
    "s": "j",
    "t": "k",
    "u": "l",
    "v": "m",
    "w": "n",
    "x": "o",
    "y": "p",
    "z": "q"
}
const DECRYPT_RESTRICTIONS_MIN_STAY_THRU = {
    "5": 0,
    "a": 1,
    "b": 2,
    "c": 3,
    "d": 4,
    "e": 5,
    "f": 6,
    "g": 7,
    "h": 8,
    "i": 9,
    "j": "a",
    "k": "b",
    "l": "c",
    "m": "d",
    "n": "e",
    "o": "f",
    "p": "g",
    "q": "h",
    "r": "i",
    "s": "j",
    "t": "k",
    "u": "l",
    "v": "m",
    "w": "n",
    "x": "o",
    "y": "p",
    "z": "q"
}
const DECRYPT_RESTRICTIONS_CHANGEOVER = {
    "-": 0,
    "0": 0,
    "1": 1,
    "2": 2,
    "3": 3
}
const CHARMAP = {
    "a": 10,
    "b": 11,
    "c": 12,
    "d": 13,
    "e": 14,
    "f": 15,
    "g": 16,
    "h": 17,
    "i": 18,
    "j": 19,
    "k": 20,
    "l": 21,
    "m": 22,
    "n": 23,
    "o": 24,
    "p": 25,
    "q": 26
}
const INTMAP = {
    "10": "a",
    "11": "b",
    "12": "c",
    "13": "d",
    "14": "e",
    "15": "f",
    "16": "g",
    "17": "h",
    "18": "i",
    "19": "j",
    "20": "k",
    "21": "l",
    "22": "m",
    "23": "n",
    "24": "o",
    "25": "p",
    "26": "q"
}

const setOptions = (params) => {
    let options = {
        ...params
    }
    options.overviewLength = 365;
    options.packages = true;
    options.roomCodes = params.roomCode;
    options.occupancy =  params.adults ? `${params.adults}${params.children?.length ? params.children.reduce((prev,next)=>{return prev+","+next},"") : ''}` : '';
    return options
}

/**
 * Decode kognitiv strings to usable data strings
 * @param {string} string
 * @param {object} decodeMap
 */
 const stringDecoder = (string, decodeMap) => {
    const arr = string.split('');
    return arr.map(a=>decodeMap[a]).join('')
}

/**
 * Extract general minimum and maximum stay values from available string
 * @param {string} minStay 
 * @param {string} maxStay
 */
const getStayRange = (minStay,maxStay) => {
    let min = null,
    max = null

    for(let i = 0; i < minStay.length; i++) {
        let currMinStay = CHARMAP[minStay[i]] || minStay[i]
        let currMaxStay = CHARMAP[maxStay[i]] || maxStay[i]

        if(!min && !isNaN(parseInt(currMinStay))) {
            min = parseInt(currMinStay)
        }
        else if(parseInt(min) > parseInt(currMinStay) && currMinStay > 0 ) {
            min = parseInt(currMinStay)
        }

        if(!max && !isNaN(parseInt(currMaxStay))) {
            max = parseInt(currMaxStay)
        } 
        else if(max < parseInt(currMaxStay)) {
            max = parseInt(currMaxStay)
        }
    }

    return {
        min,
        max
    }
}

/**
 * Creates days string to display it in calendar
 * @param {string} restrictions 
 * @param {string} minstaythrough
 */
const convertToDaysString = (restrictions, minstaythrough) => {
    const days = [];
    const minstaythru = [];
    for (let index in restrictions.split('')) {
        days[index] = CHARMAP[restrictions[index]] || restrictions[index];
        minstaythru[index] = CHARMAP[minstaythrough[index]] || minstaythrough[index]
        //When current alphabet of string denotes the current date to be closed to arrival and previous date has no room available
        //then the current date value will be no room available as well
        if (days[index] === '$' && days[parseInt(index) - 1] === "0") {
            days[index] = "0"
        }
        //When current alphabet is open for arrival and departure and contains minimum stay
        //To-Do: removed a validation of {minstaythru[index] !== '0'} need to check this with all hotels
        else if (days[index] !== "0" && days[index] !== '$') {
            //To remove dynamic minLOS gaps
            if(parseInt(days[index]) < parseInt(minstaythru[index])){
                days[index] = "0"
                continue;
            }
            //Iterate 'j' to check whether any no rooms available for next minimum stay amount of days
            for (let j = 0; j < days[index]; j++) {
                //Validation to check the no rooms available for current 'j' of iteration based on minimum stay amount 
                //if true replace the minimum stay amount with closed to arrival
                if (restrictions[parseInt(index) + parseInt(j)] === "0" || !restrictions[parseInt(index) + parseInt(j)]) {
                    //Check whether the previous index of closed to arrival from current index is available
                    //if not then replace it with no room available else keep closed to arrival
                    days[index] = days[parseInt(index) - 1] === "0" ? "0" : '$'
                    break;
                }
            }
            days[index] = INTMAP[days[index].toString()] || days[index]
        }
        else {
            days[index] = INTMAP[days[index].toString()] || days[index]
        }
    }
    return days.join('')
}

/**
 * Calculates the minimum and maximum price values of adults and children for provided date range
 * @param {object} offer
 * @param {array} prices
 * @param {array} xmlRatePlan
 */
const getPriceRange = (offer, prices, xmlRatePlan) => {
    let minStdAmount = null;
    let maxStdAmount = null;
    let minDayIndex = null;
    let maxDayIndex = null;

    for(let i=0; i<prices.length; i++){
        if(prices[i] && (!minStdAmount || parseInt(minStdAmount) > parseInt(prices[i]))){
            minStdAmount = parseInt(prices[i])
            minDayIndex = i;
        }
        if(prices[i] && (!maxStdAmount || parseInt(maxStdAmount) < parseInt(prices[i]))){
            maxStdAmount = parseInt(prices[i])
            maxDayIndex = i
        }
    }

    return {
        adults: {
            min: {
                amount: (minStdAmount/offer.std_occupancy).toFixed(2),
                single: (minStdAmount/offer.std_occupancy).toFixed(2),
                std: minStdAmount,
                guests: offer.std_occupancy,
                rate: (() => {
                    const r = {};
                    for(i=offer.min_occupancy; i<=offer.max_occupancy; i++){
                        r[i] = xmlRatePlan[minDayIndex].adults[i] ? xmlRatePlan[minDayIndex].adults[i] : minStdAmount + ((i - offer.std_occupancy) * xmlRatePlan[minDayIndex]['adults']['additional'])
                    }
                    return r
                })()
            },
            max: {
                amount: (maxStdAmount/offer.std_occupancy).toFixed(2),
                single: (maxStdAmount/offer.std_occupancy).toFixed(2),
                std: maxStdAmount,
                guests: offer.std_occupancy,
                rate: (() => {
                    const r = {};
                    for(i=offer.min_occupancy; i<=offer.max_occupancy; i++){
                        r[i] = xmlRatePlan[maxDayIndex].adults[i] ? xmlRatePlan[maxDayIndex].adults[i] : maxStdAmount + ((i - offer.std_occupancy) * xmlRatePlan[maxDayIndex]['adults']['additional'])
                    }
                    return r
                })()
            }
        },
        children: {
            min: {...xmlRatePlan[minDayIndex]['children']},
            max: {...xmlRatePlan[maxDayIndex]['children']}
        }
    }
}

/**
 * Creates days string for daily based offers
 * @param {string} daysString 
 * @param {string} restrictions 
 * @param {array} xmlRate 
 * @returns {string}
 */
 const convertToDaysStringForOffers = (daysString, restrictions, xmlRate) => {
    const days = []
    let addDays = ''
    for(i=0; i<daysString.length; i++){
        if(daysString[i] === '0' && restrictions[i] === '5' && days[i-1] !== '0'){
            days[i] = '$'
        } else if(i === daysString.length - 1 && daysString[i] === '$' && restrictions[i+1] === '5' && xmlRate?.[i+1]){
            days[i] = daysString[i]
            for(j=i+1; j<restrictions.slice(i+1).length; j++){
                if(restrictions[j]!=='5' || !xmlRate[j]){
                    break;
                }
                addDays += '$'
            }
        } else if(daysString[i] === '0' && restrictions[i].match(/[a-z]/g) && days[i-1] === '$'){
            days[i] = '$'
        } else {
            days[i] = daysString[i]
        }
    }
    return days.join('')+addDays;
}

/**
 * Calculates the adults, children min, max prices for daily based offers
 * @param {object} offer 
 * @param {array} prices 
 * @param {array} xmlRatePlan 
 * @param {number} duration 
 * @param {string} days 
 * @returns {object}
 */
const getPriceRangeForOffers = (offer, prices, xmlRatePlan, duration, days) => {
    let priceArray = []

    for(let i=0; i<prices.length; i++){
        if(prices[i] && days[i]!=='0' && days[i].match(/[1-9a-z]/g)){
            let tempPrice = prices[i]
            for(j = i+1; j < i+duration; j++){
                if(!prices[j] || days[j] === '0'){
                    break;
                } else if(j === i + duration - 1){
                    tempPrice += prices[j]
                    priceArray.push({
                        startIndex: i,
                        endIndex: j,
                        amount: tempPrice
                    })
                } else {
                    tempPrice += prices[j]
                }
            }
        }
    }

    priceArray = priceArray.sort((current, next)=>{
        if(current.amount > next.amount){
            return 1
        } else {
            return -1
        }
    })

    const minXmlPrice = xmlRatePlan.slice(priceArray[0].startIndex, priceArray[0].endIndex+1)
    const maxXmlPrice = xmlRatePlan.slice(priceArray[priceArray.length-1].startIndex, priceArray[priceArray.length-1].endIndex+1)

    return {
        adults: {
            min: {
                amount: (priceArray[0].amount/offer.std_occupancy).toFixed(2),
                single: (priceArray[0].amount/offer.std_occupancy).toFixed(2),
                std: priceArray[0].amount.toFixed(2),
                guests: offer.std_occupancy,
                rate: (() => {
                    const r = {};
                    for(i=offer.min_occupancy; i<=offer.max_occupancy; i++){
                        r[i] = 0
                        minXmlPrice.forEach(xmlPrice=>{
                            r[i] += xmlPrice.adults[i] ? xmlPrice.adults[i] : xmlPrice.adults[offer.std_occupancy] + ((i - offer.std_occupancy) * xmlPrice['adults']['additional'])
                        })
                        r[i] = r[i].toFixed(2)
                    }
                    return r
                })()
            },
            max: {
                amount: (priceArray[priceArray.length-1].amount/offer.std_occupancy).toFixed(2),
                single: (priceArray[priceArray.length-1].amount/offer.std_occupancy).toFixed(2),
                std: priceArray[priceArray.length-1].amount.toFixed(2),
                guests: offer.std_occupancy,
                rate: (() => {
                    const r = {};
                    for(i=offer.min_occupancy; i<=offer.max_occupancy; i++){
                        r[i] = 0
                        maxXmlPrice.forEach(xmlPrice=>{
                            r[i] += xmlPrice.adults[i] ? xmlPrice.adults[i] : xmlPrice.adults[offer.std_occupancy] + ((i - offer.std_occupancy) * xmlPrice['adults']['additional'])
                        })
                        r[i] = r[i].toFixed(2)
                    }
                    return r
                })()
            },
        },
        children: {
            min: minXmlPrice.reduce((acc,{children})=>{
                if(!children){
                    return;
                }
                Object.entries(children).forEach(([key,value])=>{
                    if(!acc[key]){
                        acc[key] = value
                    } else {
                        acc[key] += children[key]
                    }
                })
                return acc
            },{}),
            max: maxXmlPrice.reduce((acc,{children})=>{
                if(!children){
                    return;
                }
                Object.entries(children).forEach(([key,value])=>{
                    if(!acc[key]){
                        acc[key] = value
                    } else {
                        acc[key] += children[key]
                    }
                })
                return acc
            },{})
        }
    }
}

/**
 * Determine the daily availability of rooms for '365' days mapped with the room code
 * @param {array} ratePlans
 */
const resolveAvailability = (ratePlans) => {
    return ratePlans.reduce((previous,current)=>{
        if(!previous[current.room_code]){
            return {
                ...previous,
                [current.room_code]: {
                    start: dateIsoFormat(dateToday()),
                    range: 365,
                    quota: current.availabilities.join('')
                }
            }
        }
        return previous;
    },{})
}

/**
 * Determine the room type and camping category
 * @param {string} roomCode
 * @param {string} roomTypeCode
 * @param {object} options
 */
 const resolveType = (roomCode, roomTypeCode, options) => {
    const code = (options.config?.rooms?.type && options.config.rooms.type[roomCode]) ? options.config.rooms.type[roomCode] : roomTypeCode
    return {
      code,
      name: roomTypes[code][options.language],
      camping: roomTypesCamping.indexOf(code) > -1
    }
}

/**
 * Resolve description content based on selected language
 * @param {array} descriptions
 * @param {object} options
 */
const resolveDescriptions = (descriptions, options) => {
    return descriptions ? descriptions.reduce((acc, {text_items}) => {
      return {...acc, ...text_items.reduce((accu, {language, title, descriptions}) => {
        return language.toLowerCase() == options.language ? {title, description: descriptions[0]?.content} : accu
      }, {})}
    }, {title: null, description:null}) : {}
}

/**
 * Resolve Room Amenities respecting camping types to ignore beds and add custom ones
 * @param {array} amenities
 * @param {object} options
 */
 const resolveAmenities = (amenities, options, camping) => {
    //TODO: add custom room amenities from config
    return amenities.reduce((acc, {code, detail, title, quantity}) => {
      return camping && hotelOnlyRoomAmenities.indexOf(`${detail}_${code}`) > -1 ? acc : [...acc, {code: `${detail}_${code}`, title, quantity}]
    }, [])
}

/**
 * Resolve Image title and description based on current language selection
 * @param {array} descriptions 
 * @param {object} options 
 * @returns {object}
 */
const resolveImageTitle = (descriptions, options) => {
    return descriptions.reduce((acc, {language, content}) => {
      return language.toLowerCase() == options.language ? {title: content} : acc
    }, '')
}

/**
 * Resolve room images and split them into regular gallery and floorplans
 * set options.rooms.floorplans.skipgallery = false to override splitting
 * @param {*} descriptions
 * @param {*} options
 */
 const resolveImages = (descriptions, options) => {
    return descriptions ? descriptions.reduce((acc, {image_items}) => {
      return image_items.reduce((acc, {category, image_formats, descriptions}) => {
        const image = {url: image_formats[0].url, ...resolveImageTitle(descriptions, options)};
        (category == 21 && (options?.rooms?.floorplans?.skipgallery || true)) //by default, do not include floor plans in gallery
          ? acc.floorplans.push(image) : acc.images.push(image)
        return acc
      }, acc)
    }, {images: [], floorplans:[]}) : {}
}

/**
 * Resolve room categories received from cm config for each room and apply to room codes
 * @param {array} roomCategories
 * @param {string} roomCode
 */
const resolveCategories = (roomCategories, roomCode) => {
    return roomCategories.reduce((acc, {rooms, code, title, description}) => {
      // return (rooms.indexOf(roomCode) > -1) ? [...acc, {
      return Object.entries(rooms).find(( [key, value] ) => value === roomCode) ? [...acc, {
        code, title, description
      }] : acc}, [])
}

/**
 * Resolve detailed information of each rateplan available in each room
 * @param {array} offersOverview 
 * @param {object} ratesAverage 
 * @param {array} seasons 
 * @param {object} XMLRates 
 * @param {object} options 
 * @returns {array}
 */
const resolveRatePlans = (offersOverview, ratesAverage, seasons, XMLRates, options) => {
    let seasonStartDate = dateFrom(seasons[0].periods[0].start) <= dateToday() ? dateToday() : dateFrom(seasons[0].periods[0].start)
    let seasonEndDate = dateFrom(seasons[seasons.length - 1].periods[seasons[seasons.length - 1].periods.length - 1].end) >= dateAddDays(365,dateToday()) ? dateAddDays(365,dateToday()) : dateFrom(seasons[seasons.length - 1].periods[seasons[seasons.length - 1].periods.length - 1].end)

    return offersOverview.reduce((previous,current)=>{
        previous[current.room_code] = previous[current.room_code] || []
        if(!current.isPackage && ratesAverage[current.room_code]["allowed_rate_codes"].includes(current.rate_code) && XMLRates[current.room_code][current.rate_code]){
            const xmlRate = XMLRates[current.room_code][current.rate_code]

            let minstaythrough = stringDecoder(current.restrictions_min_stay_thru, DECRYPT_RESTRICTIONS_MIN_STAY_THRU)

            let daysString = convertToDaysString(stringDecoder(current.restrictions, DECRYPT_RESTRICTIONS), minstaythrough);

            let minstay = xmlRate.map(x=>{
                if(!x || !x.hasOwnProperty('minstay') || !x.minstay){
                    return '0'
                } else if( parseInt(x?.minstay) > 9){
                    return INTMAP[x?.minstay]
                } else {
                    return x?.minstay
                }            
            }).join('')

            let maxstay = xmlRate.map(x=>{
                if(!x || !x.hasOwnProperty('maxstay') || !x.maxstay){
                    return '0'
                } else if( parseInt(x?.maxstay) > 9){
                    return INTMAP[x?.maxstay]
                } else {
                    return x?.maxstay
                }            
            }).join('')

            let prices = xmlRate.map(x=>{
                if(x){
                    return x['adults'][current.std_occupancy]
                } else {
                    return null
                }
            })
            
            // When offers are not fetched properly from offers overview based on std occupancy
            // condition changed now we will always consider prices from xml rates api only
            if(!current.prices.join('')){
                const tempDays = []
                // const tempPrices=[]
                for(let i=0; i<current.prices.length; i++){
                    if(current.restrictions[i] === '5'){
                        tempDays[i] = minstay[i]
                    } else {
                        tempDays[i] = DECRYPT_RESTRICTIONS[current.restrictions[i]]
                    }

                    // if(xmlRate[i]){
                    //     tempPrices[i] = xmlRate[i].adults[current.std_occupancy]
                    // } else {
                    //     tempPrices[i] = null
                    // }
                }
                daysString = convertToDaysString(tempDays.join(''),minstaythrough)
                // prices = tempPrices
            }

            const sliceIndex = {}

            // Filtering out room not available indexes at initial and ending part of string
            for(let i=0; i < daysString.length; i++){
                if(i === 0 && daysString[i] === "0") {
                    sliceIndex["initialStart"] = 0
                    for(let j=i+1; j < daysString.length; j++) {
                        if(daysString[j] !== "0"){
                            sliceIndex["initialEnd"] = j
                            break;
                        } else if(j === daysString.length - 1 && !sliceIndex["initialEnd"]) {
                            sliceIndex["initialEnd"] = j
                            break;
                        }
                    }
                } else if(daysString[i] === "0" && !sliceIndex["closingStart"] && !sliceIndex["closingEnd"]) {
                    for(let k=i+1; k < daysString.length; k++) {
                        if(daysString[k] === "0" && k === daysString.length - 1) {
                            sliceIndex["closingStart"] = i;
                            sliceIndex["closingEnd"] = k;
                            break;
                        } else if(daysString[k] !== "0") {
                            break;
                        }
                    }
                } else if(sliceIndex["initialStart"] && sliceIndex["initialEnd"] && sliceIndex["closingStart"] && sliceIndex["closingEnd"]) {
                    break;
                }
            }

            const sliceStartIndex = Math.max(dateDiffDays(dateToday(), seasonStartDate), sliceIndex["initialEnd"] || 0);
            const sliceEndIndex = Math.min(dateDiffDays(dateToday(), seasonEndDate) + 1, sliceIndex["closingStart"] || 365);

            minstaythrough = minstaythrough.slice(sliceStartIndex, sliceEndIndex)
            daysString = convertToDaysString(daysString.slice(sliceStartIndex, sliceEndIndex), minstaythrough)

            daysString && previous[current.room_code].push({
                code: current.rate_code,
                start: dateIsoFormat(dateAddDays(sliceStartIndex,dateToday())), // Start date of rate plan by removing initial room not available conditions and considering the seasons start date
                end: dateIsoFormat(dateAddDays(sliceEndIndex - 1,dateToday())), // End date of rate plan by removing ending room not available conditions and considering the seasons end date
                mealplan: mealPlanCodes[current.meal_plan_code || "3"][options.language], 
                mealplancode: current.meal_plan_code || "3",
                description: ratesAverage[current.room_code].rates.find(r=>r.code === current.rate_code).description,
                title: ratesAverage[current.room_code].rates.find(r=>r.code === current.rate_code).title,
                stay: getStayRange(minstay.slice(sliceStartIndex,sliceEndIndex), maxstay.slice(sliceStartIndex,sliceEndIndex)),
                availability: {
                    start: dateIsoFormat(dateAddDays(sliceStartIndex,dateToday())), // Rateplan availability start date in ISO format
                    range: sliceEndIndex - sliceStartIndex,
                    quota: current.availabilities.slice(sliceStartIndex,sliceEndIndex).join(''), // availability of room,
                    minstay: minstay.slice(sliceStartIndex,sliceEndIndex),
                    maxstay: maxstay.slice(sliceStartIndex,sliceEndIndex),
                    minstaythrough,
                    rates: prices.join('') ? prices.slice(sliceStartIndex, sliceEndIndex).map(p=>!isNaN(parseInt(p)) ? '1' : '0').join('') : null,
                    prices: prices.join('') ? prices.slice(sliceStartIndex, sliceEndIndex).map(p=>!isNaN(parseInt(p)) ? Math.round(parseInt(p)/current.std_occupancy) : '').join('|') : null, // Prices should be per person only
                    closedto: stringDecoder(current.changeOver, DECRYPT_RESTRICTIONS_CHANGEOVER).slice(sliceStartIndex, sliceEndIndex),
                    days: daysString,
                    bookable: daysString.trim() !== '' ? 1 : 0, //If no days are bookable in that case the days string will be empty
                },
                price: prices.join('') ? getPriceRange(current, prices.slice(dateDiffDays(dateToday(), seasonStartDate), dateDiffDays(dateToday(), seasonEndDate) + 1), XMLRates[current.room_code][current.rate_code].slice(dateDiffDays(dateToday(), seasonStartDate), dateDiffDays(dateToday(), seasonEndDate) + 1)) : null
            })
        }
        return previous
    },{})
}

/**
 * Resolve the detailed information of seasons applicable to each room
 * @param {array} seasons 
 * @returns {array}
 */
const resolveSeasonsExtended = (seasons) => {
    const seasonTitles = [...new Set(seasons.map(s=>s.title))];
    const seasonsExt = [];

    seasonTitles.forEach(acc=>{
        const seasonArr = seasons.filter(s=>s.title === acc)
        const dates = []
        seasonArr.forEach(s=>{
            s.periods.forEach(p=>{
                dates.push([p.start,p.end])
            })
        })

        seasonsExt.push({
            code: seasonArr[0].code,
            start: seasonArr[0].periods[0].start,
            end: seasonArr[seasonArr.length - 1].periods[seasonArr[seasonArr.length - 1].periods.length - 1].end,
            title: seasonArr[0].title,
            dates
        })
    })

    return seasonsExt
}

/**
 * Resolve rates for each room based on the available rateplans for that room
 * @param {object} ratePlansToRoomsMap 
 * @param {array} seasons 
 * @param {array} offersOverview 
 * @param {object} xmlRates 
 * @returns {ratesToRoomsMap}
 */
const resolveRoomRates = (ratePlansToRoomsMap, seasons, offersOverview, xmlRates) => {
    const rates = {}
    for(let roomCode in ratePlansToRoomsMap){
        let rateplans = ratePlansToRoomsMap[roomCode]
        rates[roomCode] = rateplans.map(rateplan=>{
            const applicableSeasons = seasons.filter(s=>{
                if((dateFrom(rateplan.start) >= dateFrom(s.start) && dateFrom(rateplan.start) <= dateFrom(s.end))
                || (dateFrom(rateplan.end) >= dateFrom(s.start) && dateFrom(rateplan.end) <= dateFrom(s.end))
                || (dateFrom(s.start) >= dateFrom(rateplan.start) && dateFrom(s.end) <= dateFrom(rateplan.end))) {
                    return s;
                }
            })

            const applicableDatesAndPricesOfSeasons = applicableSeasons.map(s=>{
                const currentOffer = offersOverview.find(o=>o.rate_code === rateplan.code);

                let prices = xmlRates[roomCode][rateplan.code].map(x=>{
                    if(x){
                        return x['adults'][currentOffer.std_occupancy]
                    } else {
                        return null
                    }
                })

                // if(!currentOffer.prices.join('')){
                //     const tempPrices=[]
                //     for(let i=0; i<currentOffer.prices.length; i++){
                //         if(xmlRates[roomCode][rateplan.code][i]){
                //             tempPrices[i] = xmlRates[roomCode][rateplan.code][i].adults[currentOffer.std_occupancy]
                //         } else {
                //             tempPrices[i] = null
                //         }
                //     }
                //     prices = tempPrices
                // }

                return {
                    dates: s.dates.map(d=>{
                        if((dateFrom(rateplan.start) >= dateFrom(d[0]) && dateFrom(rateplan.start) <= dateFrom(d[1]))
                        || (dateFrom(rateplan.end) >= dateFrom(d[0]) && dateFrom(rateplan.end) <= dateFrom(d[1]))
                        || (dateFrom(d[0]) >= dateFrom(rateplan.start) && dateFrom(d[1]) <= dateFrom(rateplan.end))) {
                            const sliceStartIndex = dateDiffDays(dateToday(), dateFrom(d[0])) < 0 ? 0 : dateDiffDays(dateToday(), dateFrom(d[0])); //Season start dates could be before today which could result in negative value
                            const sliceEndIndex = dateDiffDays(dateToday(), dateFrom(d[1])) + 1;

                            return {
                                start: d[0],
                                end: d[1],
                                price: prices.join('') ? getPriceRange(currentOffer, prices.slice(sliceStartIndex, sliceEndIndex), xmlRates[roomCode][rateplan.code].slice(sliceStartIndex, sliceEndIndex)) : null
                            };
                        }
                    }).filter(Boolean)
                }
            })

            return {
                seasons: applicableDatesAndPricesOfSeasons,
                stay: rateplan.stay,
                price: rateplan.price,
                mealplan: rateplan.mealplancode
            }
        })
    }
    return rates
}

/**
 * Resolve the mealplan codes which are applicable in each room
 * @param {object} ratePlansToRoomsMap 
 * @returns {array}
 */
const resolveMealPlans = (ratePlansToRoomsMap) => {
    const mealplansToRoomsMap = {}

    for(let roomCode in ratePlansToRoomsMap){
        let rateplans = ratePlansToRoomsMap[roomCode];
        mealplansToRoomsMap[roomCode] = [];
        rateplans.forEach(rateplan=>{
            if(!mealplansToRoomsMap[roomCode].find(m=>m.id===parseInt(rateplan.mealplancode))){
                mealplansToRoomsMap[roomCode].push({
                    id: parseInt(rateplan.mealplancode),
                    title: rateplan.mealplan
                })
            }
        })
    }

    return mealplansToRoomsMap;
}

/**
 * Resolve the array of date ranges which are available for the applicable seasons
 * @param {array} seasons 
 * @returns {array}
 */
const resolveDates = (seasons) => {
    const dates = []

    seasons.forEach(season=>{
        season.periods.forEach(period=>{
            dates.push({
                start: period.start,
                end: period.end
            })
        })
    })

    return dates
}

/**
 * Resolve min/max price of whole room by iterating through min/max price of all available rateplans for that room
 * @param {array} rateplans 
 * @returns {object}
 */
const resolvePrice = (rateplans) => {
    const priceToRoomsMap = {
        type: 'single',
        adults:{
            min:{},
            max:{}
        },
        children:{
            min:{},
            max:{}
        }
    }

    rateplans.forEach(rateplan=>{
        if(!priceToRoomsMap?.adults.min.single || priceToRoomsMap?.adults.min.single > rateplan?.price?.adults.min.single){
            priceToRoomsMap.adults.min = {
                ...rateplan.price?.adults.min
            }
            priceToRoomsMap.children.min = {
                ...rateplan.price?.children.min
            }
        }

        if(!priceToRoomsMap?.adults.max.single || priceToRoomsMap?.adults.max.single < rateplan?.price?.adults.max.single){
            priceToRoomsMap.adults.max = {
                ...rateplan.price?.adults.max
            }
            priceToRoomsMap.children.max = {
                ...rateplan.price?.children.max
            }
        }
    })

    return priceToRoomsMap
}

/**
 * Resolve the daily based offers of rooms
 * @param {array} offersOverview 
 * @param {array} ratesAverage 
 * @param {array} seasons 
 * @param {array} xmlRates 
 * @param {object} options 
 * @returns {offersToRoomsMap}
 */
const resolveOffers = (offersOverview, ratesAverage, seasons, xmlRates, options) => {
    let seasonStartDate = dateFrom(seasons[0].periods[0].start) <= dateToday() ? dateToday() : dateFrom(seasons[0].periods[0].start)
    let seasonEndDate = dateFrom(seasons[seasons.length - 1].periods[seasons[seasons.length - 1].periods.length - 1].end) >= dateAddDays(365,dateToday()) ? dateAddDays(365,dateToday()) : dateFrom(seasons[seasons.length - 1].periods[seasons[seasons.length - 1].periods.length - 1].end)
    const applicableOffers = []

    ratesAverage.forEach(offer=>{
        offer.available_only.forEach(dates=>{
            if(dateFrom(dates.start) >= seasonStartDate && dateFrom(dates.end) <= seasonEndDate){
                applicableOffers.push(offer.code)
            }
        })
    })

    return offersOverview.reduce((previous,current)=>{
        previous[current.room_code] = previous[current.room_code] || []
        if(current.isPackage && applicableOffers.includes(current.rate_code)){
            const rateAverage = ratesAverage.find(r=>r.code === current.rate_code)

            const offerStartDate = rateAverage.available_only.sort((pre,cur)=>{
                if(dateFrom(pre.start) > dateFrom(cur.start)){
                    return 1
                } else {
                    return -1
                }
            })[0].start

            const offerEndDate = rateAverage.available_only.sort((pre,cur)=>{
                if(dateFrom(pre.end) < dateFrom(cur.end)){
                    return 1
                } else {
                    return -1
                }
            })[0].end

            const weekdays = {'MON': 1, 'TUE': 2, 'WEDS': 3, 'THU': 4, 'FRI': 5, 'SAT': 6, 'SUN': 7}

            const stay = {}
            let duration = null;

            const arrival_days = Object.entries(rateAverage.min_los_per_week_day).map(([key,value])=>{
                stay[weekdays[key]] = value
                duration = value // minimum stay duration
                return weekdays[key]
            }).join(',') // string contaning days of week in iso format upto 7 e.g.'1,4,5'

            const restricted = arrival_days.split(',').length !== 7 ? 1 : 0; // set value '0' when all days of week contain minimum stay and are bookable else '1'
            
            const xmlRate = xmlRates[current.room_code][current.rate_code]

            let minstaythrough = stringDecoder(current.restrictions_min_stay_thru, DECRYPT_RESTRICTIONS_MIN_STAY_THRU)
            let daysString = convertToDaysString(stringDecoder(current.restrictions, DECRYPT_RESTRICTIONS), minstaythrough);

            let minstay = current.prices.map((x,index)=>{
                if((x && daysString[index]!=='0' && daysString[index]!=='$') || current.restrictions[index].match(/[a-z]/g)){
                    return duration
                } else {
                    return 0
                }
            }).join('')

            const sliceIndex = {}

            // Filtering out room not available indexes at initial and ending part of string
            for(let i=0; i < daysString.length; i++){
                if(i === 0 && daysString[i] === "0") {
                    sliceIndex["initialStart"] = 0
                    for(let j=i+1; j < daysString.length; j++) {
                        if(daysString[j] !== "0"){
                            sliceIndex["initialEnd"] = j
                            break;
                        } else if(j === daysString.length - 1 && !sliceIndex["initialEnd"]) {
                            sliceIndex["initialEnd"] = j
                            break;
                        }
                    }
                } else if(daysString[i] === "0" && !sliceIndex["closingStart"] && !sliceIndex["closingEnd"]) {
                    for(let k=i+1; k < daysString.length; k++) {
                        if(daysString[k] === "0" && k === daysString.length - 1) {
                            sliceIndex["closingStart"] = i;
                            sliceIndex["closingEnd"] = k;
                            break;
                        } else if(daysString[k] !== "0") {
                            break;
                        }
                    }
                } else if(sliceIndex["initialStart"] && sliceIndex["initialEnd"] && sliceIndex["closingStart"] && sliceIndex["closingEnd"]) {
                    break;
                }
            }

            let sliceStartIndex = sliceIndex["initialEnd"] || 0;
            let sliceEndIndex = sliceIndex["closingStart"] || 365;
            
            daysString = convertToDaysStringForOffers(daysString.slice(sliceStartIndex, sliceEndIndex), current.restrictions.slice(sliceStartIndex), xmlRate?.slice(sliceStartIndex))

            if(daysString.length > sliceEndIndex - sliceStartIndex){
                sliceEndIndex = sliceStartIndex + daysString.length
            }

            let prices = xmlRate?.map(x=>{
                if(x){
                    return x['adults'][current.std_occupancy]
                } else {
                    return null
                }
            })

            daysString && previous[current.room_code].push({
                code: current.rate_code,
                type: rateAverage.type === 'DayRate' ? '2' : '1',
                dates: rateAverage.available_only.map(dates=>{ //This works different than the rooms.json of s.mts
                    return Object.values(dates)
                }),
                category: rateAverage.category_codes,
                description: rateAverage.description,
                teaser: rateAverage.teaser,
                title: rateAverage.title,
                images: rateAverage.imagesInfo,
                mealplancode: current.meal_plan_code || "3",
                mealplan: mealPlanCodes[current.meal_plan_code || "3"][options.language],
                start: offerStartDate,
                end: offerEndDate,
                stay,
                duration,
                restricted,
                arrival_days,
                guests: {
                    min: current.min_occupancy,
                    max: current.max_occupancy
                },
                availability: { // strings are accurate with kognitiv data but sometimes it doesn't match with s.mts rooms.json
                    start: dateIsoFormat(dateAddDays(sliceStartIndex,dateToday())),
                    range: sliceEndIndex - sliceStartIndex,
                    quota: current.availabilities.map(a => a > 9 ? 1 : a).slice(sliceStartIndex,sliceEndIndex).join(''),
                    minstay: minstay.slice(sliceStartIndex,sliceEndIndex),
                    closedto: stringDecoder(current.changeOver, DECRYPT_RESTRICTIONS_CHANGEOVER).slice(sliceStartIndex, sliceEndIndex),
                    days: daysString,
                    bookable: daysString.trim() !== '' ? 1 : 0,
                },
                price: {
                    ... prices?.join('') ? getPriceRangeForOffers(current, prices.slice(sliceStartIndex, sliceEndIndex), xmlRate.slice(sliceStartIndex,sliceEndIndex), duration, daysString) : null,
                    periods: prices?.join('') ? rateAverage.available_only.map(dates=>{
                        const start = Math.max(dateDiffDays(dateToday(), dateFrom(dates.start)), 0)
                        const end = dateDiffDays(dateToday(), dateFrom(dates.end)) + 1
                        return getPriceRangeForOffers(current, prices.slice(start, end), xmlRate.slice(start, end), duration, convertToDaysString(stringDecoder(current.restrictions.slice(start, end), DECRYPT_RESTRICTIONS), minstaythrough))
                    }) : null
                }
            })
        }
        return previous
    },{})
}

//For internal call
const resolveRoomsExtended = async ({ dataSources },{ property: propertyData, token }, params) => {
    const options = setOptions({ ...params, propertyData })

    const roomsOccupancy = propertyData.facility?.rooms.map(r=>{
        const adults = (r.min_child_occup && r.max_adult_occup) || r.types[0].std_occup
        const children = r.min_child_occup ? Array(r.min_child_occup).fill(1) : []
        return {
            adults,
            children,
            roomCode: r.code
        }
    })

    const [
        { data: ratesAverage, error: ratesAverageError},
        hotelSeasonInfo,
        XMLRates,
        ...offersOverview
    ] = await Promise.all([
        fetchRatesAverage(dataSources, { ...params, ...options, accessToken: token }),
        resolveSeasons(propertyData, { ...params, ...options, accessToken: token }),
        resolveRates({ dataSources }, { property: propertyData, token }, params),
        ...roomsOccupancy.map(r=>fetchOffersOverview(dataSources, {...params, ...setOptions({ ...params, ...r, propertyData }), accessToken: token }))
    ])

    const offersOverviewEntities = []

    offersOverview.forEach(d=>{
        offersOverviewEntities.push(...d.data.overview.entities)
    })

    ratesAverageError && console.log(`Rates Average: ${ratesAverageError}`);

    const ratesAverageExtended = ratesAverage.rooms.reduce((previous,current)=>{
        previous[current.code] = {
            ...current,
            allowed_rate_codes:current.rates.map(r=>r.code)
        }
        return previous
    },{})

    const rooms = propertyData.facility?.rooms || []
    const roomCategories = resolveRoomCategories(propertyData, options)

    const availabilityToRoomsMap = resolveAvailability(offersOverviewEntities)

    const ratePlansToRoomsMap = resolveRatePlans(offersOverviewEntities, ratesAverageExtended, hotelSeasonInfo, XMLRates, options)
    
    const seasons = resolveSeasonsExtended(hotelSeasonInfo)
    
    const ratesToRoomsMap = resolveRoomRates(ratePlansToRoomsMap, seasons, offersOverviewEntities, XMLRates)
    
    const mealplansToRoomsMap = resolveMealPlans(ratePlansToRoomsMap)
    
    //TO-DO
    //Need to check whether the seasons returned from this should be either those which were applied in this room or just all season dates.
    //Right now it is working as all season dates
    const seasonDates = resolveDates(hotelSeasonInfo)
    
    const offersToRoomsMap = resolveOffers(offersOverviewEntities, ratesAverage.packages, hotelSeasonInfo, XMLRates, options)
    
    return rooms.map(({
        code,
        title,
        descriptions,
        min_occup,
        max_occup,
        min_child_occup,
        max_child_occup,
        min_adult_occup,
        max_adult_occup,
        types,
        amenities,
        quantity
    })=>{
        if(!ratePlansToRoomsMap?.[code]){
            return
        }
        const { size, non_smoking, bed_code, std_num_beds, max_rollaways, std_occup } = types[0] //attention: the standard occupancy is in the bed type
        const type = resolveType(code, types[0].type, options)

        return {
            code,
            occupancy: {
                std: std_occup,
                min: min_occup,
                max: max_occup,
                range: min_occup == max_occup ? min_occup : `${min_occup} - ${max_occup}`,
                minChildren: min_child_occup,
                maxChildren: max_child_occup,
                minAdults: min_adult_occup,
                maxAdults: max_adult_occup,
            },
            nonSmoking: non_smoking,
            quantity,
            availability: availabilityToRoomsMap[code],
            size,
            beds: type.camping ? null : { //camping types do not have a bed
                stdNum: std_num_beds,
                maxRollaways: max_rollaways,
                type: {
                  code: bed_code,
                  name: bedTypes?.[bed_code]?.[options.language] || bedTypeAmenityCodes?.[bed_code]?.[options.language] || '',
                },
            },
            type,
            ...resolveDescriptions(descriptions, options),
            amenities: resolveAmenities(amenities, options, type.camping),
            ...resolveImages(descriptions, options),
            categories: resolveCategories(roomCategories, code),
            rateplans: ratePlansToRoomsMap[code],
            seasons,
            rates: ratesToRoomsMap[code],
            mealplans: mealplansToRoomsMap[code],
            dates: seasonDates,
            price: resolvePrice(ratePlansToRoomsMap[code]),
            offers: offersToRoomsMap[code]
        }
    })
}

//resolver for dynamic call
const roomsExtendedResolver = async(parent, params, context, info) =>
    resolveRoomsExtended(context, parent.params, { ...parent.params.options, ...params })


module.exports = {
    roomsExtendedResolver,
    resolveRoomsExtended
}