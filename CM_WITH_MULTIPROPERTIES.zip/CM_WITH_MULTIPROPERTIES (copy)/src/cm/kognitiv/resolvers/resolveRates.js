const generateCacheKey = require('../../../cache/L1Cache/generateCacheKey')
const { defaults } = require('../constants')
const { dateToday, dateFrom, dateDiffDays, dateDiffDaysAfterTimeRange } = require('../../../utils/date')
const queryRatesXML = require('../queriers/queryRatesXML')
const { isPositiveNumber } = require('../../../utils/number')

const setOptions = (params) => {
  let options = {}
  options.startIndex =
    params?.startDate && dateFrom(params.startDate) >= dateToday()
      ? dateDiffDays(dateToday(), dateFrom(params.startDate))
      : 0
  options.endIndex = isPositiveNumber(params?.length)
    ? options.startIndex + params.length
    : params?.config?.timerange
    ? options.startIndex + dateDiffDaysAfterTimeRange(params.config.timerange)
    : defaults.numberOfDays
  return options
}

const resolveRates = async ({ db }, { property }, params) => {
  const options = setOptions(params)
  const rates = await queryRatesXML(db, params.config)
  for (let roomCode in rates) {
    for (let rateCode in rates[roomCode]) {
      rates[roomCode][rateCode].dayRates = rates[roomCode][rateCode].dayRates.slice(
        options.startIndex,
        options.endIndex,
      )
    }
  }
  return rates
}

//resolver for dynamic call
const ratesResolver = async (parent, params, context, info) => {
  const { cache, ttl } = context
  const { userId, provider, language } = parent.params.options
  const key = generateCacheKey('rates', params, userId, provider, language)
  const cacheHit = await cache?.get(key)
  if (cacheHit) {
    return JSON.parse(cacheHit)
  } else {
    const cacheableValue = await resolveRates(context, parent.params, { ...parent.params.options, ...params })
    cache?.setEx(key, ttl, JSON.stringify(cacheableValue))
    return cacheableValue
  }
}

module.exports = {
  ratesResolver, //dynamic call
  resolveRates, //internal call
}
