const convertToDaysString = require('../../../utils/convertToDaysString')
const { dateToday, dateAddDays, dateIsoFormat, dateDiffDays, dateFrom } = require('../../../utils/date')
const { resolveOffers } = require('./resolveOffers')
const {
  defaults,
  decodeStrings: { DECRYPT_RESTRICTIONS_MAX_LOS, DECRYPT_RESTRICTIONS_MAX_STAY_THRU },
} = require('../constants')
const generateCacheKey = require('../../../cache/L1Cache/generateCacheKey')
const { resolveRates } = require('./resolveRates')
const { strSplit } = require('../../../utils/string')
const queryOffersOverview = require('../queriers/queryOffersOverview')

const NULL_MEALPLANCODE = '3'

const setOptions = (minstay, maxstay, language, params, options) => ({
  minstay,
  maxstay,
  ext: {
    ...options,
    language,
    ...params,
  },
})

/**
 * Decode kognitiv strings to usable data strings
 * @param {string} string
 * @param {object} decodeMap
 */
const stringDecoder = async (string, arrayFromXML, decodeMap) => {
  const arr = string.split('')
  return arr.map((a, idx) => {
    if (a.charCodeAt() >= 97 && a.charCodeAt() <= 122) {
      return arrayFromXML?.[idx]
    } else {
      return decodeMap[a]
    }
  })
}

/**
 * Modifies days array by resolving the stays which are non-bookable
 * @param {array} days
 * @param {array} max_los
 * @param {array} max_stay_thru
 * @param {array} closedto
 */
const resolveNonBookableDays = (days, max_los, max_stay_thru, closedto) => {
  for (let i = 0; i < days.length; i++) {
    if (days[i] != '0' && days[i] != '$') {
      const day = parseInt(days[i])
      if (closedto[i + day] == '2' || closedto[i + day] == '3') {
        for (let j = i + day + 1, k = 1; j < days.length; j++, k++) {
          const stay = day + k
          if (days[j] == '0') {
            days[i] = '0'
            break
          }
          if (
            max_los[j] != 0 &&
            max_los[j] != '$' &&
            max_stay_thru[j] != 0 &&
            (max_stay_thru[j] > 1 || max_los[j] < 26) &&
            (stay > max_stay_thru[j] || stay > max_los[j])
          ) {
            days[i] = '0'
            break
          }
          if (closedto[j] != '2' && closedto[j] != '3' && days[j] !== '0') {
            days[i] = stay
            break
          }
        }
      }
    }
  }
}

/**
 * Merges days string of all rateplans of same mealplan code into one
 * Here while merging we consider the minimum stay which is minimum of all the rateplans but is greater or equal to requested minstay
 * i.e., that rateplan's minimum stay gets the priority which is closest to requested minstay
 * @param {object} mealplanToDaysString
 * @param {number} minstay
 * @returns object
 */
const mergeDaysString = (mealplanToDaysString, minstay) => {
  return Object.entries(mealplanToDaysString).reduce((pre, [key, value]) => {
    pre[key] = value.reduce((acc, { days, max_los, max_stay_thru, closedto }) => {
      resolveNonBookableDays(days, max_los, max_stay_thru, closedto)
      if (acc.length === 0) {
        acc = [...days]
      } else {
        days.forEach((day, index) => {
          if (parseInt(day) !== 0) {
            if (day === '$') {
              if (parseInt(acc[index]) === 0) {
                acc[index] = day.toString()
              }
            } else {
              if (parseInt(acc[index]) === 0 || acc[index] === '$') {
                acc[index] = day.toString()
              } else {
                const stay = parseInt(day)
                const cstay = parseInt(acc[index])
                if (stay < cstay && stay >= +minstay) {
                  acc[index] = `${stay.toString()}`
                } else {
                  acc[index] = `${cstay.toString()}`
                }
              }
            }
          }
        })
      }
      return acc
    }, [])
    return pre
  }, {})
}

/**
 * Extracts first bookable date range and price for the range
 * @param {object} mealplanToMergedDaysString
 * @param {object} param1
 * @returns object
 */
const resolveBookableDateAndPrice = async (mealplanToMergedDaysString, { minstay, maxstay, ext: options }) => {
  const bookableDateRange = {}
  for (let [key, value] of Object.entries(mealplanToMergedDaysString)) {
    const dateRange = (bookableDateRange[key] = {})
    for (let index in value.slice(0, options.lengthofdays)) {
      const day = value[index]
      if (parseInt(day) !== 0 && parseInt(day) >= minstay && parseInt(day) <= maxstay) {
        dateRange['start'] = dateIsoFormat(dateAddDays(parseInt(index), dateToday()))
        dateRange['end'] = dateIsoFormat(dateAddDays(parseInt(index) + parseInt(day), dateToday()))
        break
      }
    }
    if (!dateRange?.start && !dateRange?.end) {
      continue
    }
    const offers = await resolveOffers(
      { dataSources: options.dataSources },
      { property: options.property, token: options.token },
      {
        ...options,
        roomCode: options.room.code,
        adults: options.room.adults,
        children: Array(options?.room?.children || 0).fill(1),
        ...dateRange,
      },
    )
    const occupancyTotal = options.room.adults + options.room.children
    dateRange['price'] = dateRange['default_price'] = offers.rateplans.find((r) => r.meal_plan_code === key)?.total
    dateRange['night'] = dateDiffDays(dateFrom(dateRange['start']), dateFrom(dateRange['end']))
    dateRange['stdOccupancy'] = occupancyTotal
    if (dateRange['price']) {
      // filter the price based on standard occupancy or date range
      let priceFilter = 1
      switch (options?.priceType) {
        case 'PER_NIGHT':
          priceFilter = dateRange['night']
          break
        case 'PER_PERSON':
          priceFilter = parseInt(occupancyTotal)
          break
        case 'PER_NIGHT_PER_PERSON':
          priceFilter = dateRange['night'] * parseInt(occupancyTotal)
          break
        default:
          break
      }
      dateRange['price'] = dateRange['default_price'] / priceFilter
      dateRange['pricePerNight'] = dateRange['default_price'] / dateRange['night']
      dateRange['pricePerPerson'] = dateRange['default_price'] / parseInt(occupancyTotal)
      dateRange['pricePerNightPerPerson'] = dateRange['default_price'] / dateRange['night'] / parseInt(occupancyTotal)
    }
  }
  return bookableDateRange
}

/**
 * Creates days string of individual rateplans and maps it to corresponding mealplans
 * @param {object} offers
 * @param {string} language
 * @returns object
 */
const resolveMealPlanToDaysString = async (offers, ratesXML, params) => {
  const mealplanToDaysString = {}
  const promotionCodes = params?.promotionCodes ? strSplit(',', params.promotionCodes) : []
  for (let offer of offers) {
    const mealPlanCode = offer.meal_plan_code || NULL_MEALPLANCODE
    const rateOfXML = ratesXML[offer.rate_code]
    if (rateOfXML && rateOfXML.promotionCode && !promotionCodes.includes(rateOfXML.promotionCode)) {
      continue
    }
    if (!offer.isPackage) {
      const stringsFromXML = rateOfXML.dayRates.reduce(
        (acc, cur, idx) => {
          acc.maxstay[idx] = cur?.maxstay || '-'
          acc.minstaythru[idx] = cur?.minstaythru || '-'
          acc.maxstaythru[idx] = cur?.maxstaythru || '-'
          return acc
        },
        {
          maxstay: Array(rateOfXML.dayRates.length),
          minstaythru: Array(rateOfXML.dayRates.length),
          maxstaythru: Array(rateOfXML.dayRates.length),
        },
      )

      if (!mealplanToDaysString[mealPlanCode]) {
        mealplanToDaysString[mealPlanCode] = []
      }

      const [days, max_los, max_stay_thru] = await Promise.all([
        convertToDaysString(offer.restrictions, stringsFromXML),
        stringDecoder(offer.restrictions_max_los, stringsFromXML.maxstay, DECRYPT_RESTRICTIONS_MAX_LOS),
        stringDecoder(offer.restrictions_max_stay_thru, stringsFromXML.maxstaythru, DECRYPT_RESTRICTIONS_MAX_STAY_THRU),
      ])

      mealplanToDaysString[mealPlanCode].push({
        rateCode: offer.rate_code,
        days,
        max_los,
        max_stay_thru,
        closedto: offer.changeOver,
      })
    }
  }

  return mealplanToDaysString
}

/**
 * Invokes individual functions to perform operations and formats the output
 * @param {object} offers
 * @param {object} param1
 * @param {object} options
 * @returns object
 */
const resolveDateRangeByRoom = async (
  offers,
  ratesXML,
  { minstay = 0, maxstay = Number.MAX_SAFE_INTEGER, language, ...params },
  options,
) => ({
  roomCode: offers[0].room_code,
  ranges: await resolveBookableDateAndPrice(
    mergeDaysString(await resolveMealPlanToDaysString(offers, ratesXML, params), minstay),
    setOptions(minstay, maxstay, language, params, options),
  ),
})

/**
 * Returns object of rooms with specific offers mapped to each room.
 * @param {array} offers
 * @param {array} property
 * @param {object} params
 * @returns {object}
 */
const resolveRoomsAndOffers = (offers, XMLRates, property, params) =>
  property.facility?.rooms.reduce((acc, cur) => {
    if (!params?.skipRooms?.split(',')?.includes(cur.code) && XMLRates[cur.code]) {
      acc[cur.code] = {
        code: cur.code,
        offers: offers.filter((offer) => offer.room_code === cur.code),
        ratesXML: XMLRates[cur.code],
        adults:
          cur.min_child_occup || cur.min_adult_occup ? cur.min_adult_occup ?? cur.min_occup : cur.types[0].std_occup,
        children: cur.min_child_occup ?? 0,
      }
    }
    return acc
  }, {})

//resolver for internal call
const resolveFirstBookableRange = async ({ dataSources, db }, { property, token }, params) => {
  const [offersOverview, XMLRates] = await Promise.all([
    queryOffersOverview(db, params.config, params.language),
    resolveRates({ db }, { property }, params),
  ])
  const offersToRoomMap = resolveRoomsAndOffers(offersOverview.overview.entities, XMLRates, property, params)
  return Promise.all(
    Object.values(offersToRoomMap).reduce((acc, { offers, ratesXML, ...room }) => {
      if (offers?.length) {
        acc.push(resolveDateRangeByRoom(offers, ratesXML, params, { dataSources, property, token, room }))
      }
      return acc
    }, []),
  )
}

const firstBookableRangeResolver = async (parent, params, context, info) => {
  const { cache, ttl } = context
  const { userId, provider, language } = parent.params.options
  const key = generateCacheKey('firstBookableRange', params, userId, provider, language)
  const cacheHit = await cache?.get(key)
  if (cacheHit) {
    return JSON.parse(cacheHit)
  } else {
    const cacheableValue = await resolveFirstBookableRange(context, parent.params, {
      ...parent.params.options,
      ...params,
    })
    cache?.setEx(key, ttl, JSON.stringify(cacheableValue))
    return cacheableValue
  }
}

module.exports = {
  resolveFirstBookableRange,
  firstBookableRangeResolver,
}
