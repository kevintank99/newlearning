const resolveCategories = require('./resolveCategories') 

const resolveServiceCategories = (propertyData, options) => {
  const roomCategories = options.config.rooms.categories ?? {}
  const categories = resolveCategories(propertyData, options)
  return Object.entries(roomCategories).reduce((acc, [key, value]) => {
    let category = {}
    if (category = categories.find(({code}) => code === key)) {
      acc[key] = {
        ...category, 
        rooms: value.codes || value.rooms || []
      }
    }
    return acc
  }, {})
}
  

module.exports = resolveRoomCategories

