const { defaults } = require('../constants')
const { findValueByPath } = require('../../../utils/object')
const generateCacheKey = require('../../../cache/L1Cache/generateCacheKey')
const queryForCmResolver = require('../queriers/queryForCmResolver')

const resolveCm = async (params, { db }) => {
  const options = {
    language: params.language ? params.language : defaults.language,
    provider: params.provider,
  }

  const { config, property, token: { token } = {} } = await queryForCmResolver(db, params.userId, options.language)

  return {
    params: {
      options: {
        ...options,
        hotelId: findValueByPath(config, 'seekda.hotelid'),
        userId: findValueByPath(config, 'user_id'),
        apiKey: findValueByPath(config, 'seekda.apikey'),
        apiUser: findValueByPath(config, 'seekda.user') || defaults.apiUser, //default api user is info@mts-italia.it, can only be changed in the protected user config
        apiToken: findValueByPath(config, 'seekda.token') || defaults.apiToken,
        config,
      },
      property,
      token,
    },
  }
}

const cmResolver = async (_, params, context) => {
  const { cache, ttl } = context
  const { userId, provider, language } = params
  const key = generateCacheKey('cm', params, userId, provider, language)
  const cacheHit = await cache?.get(key)
  if (cacheHit) {
    return JSON.parse(cacheHit)
  } else {
    const cacheableValue = await resolveCm(params, context)
    cache?.setEx(key, ttl, JSON.stringify(cacheableValue))
    return cacheableValue
  }
}

module.exports = cmResolver
