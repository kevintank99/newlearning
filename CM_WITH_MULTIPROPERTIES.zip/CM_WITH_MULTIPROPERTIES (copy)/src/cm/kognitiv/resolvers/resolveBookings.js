const {isStringValue} = require('../../../utils/type') 
const { dateFrom, dateIsoFormat, dateTimeFrom, dateTimeIsoFormat } = require('../../../utils/date')
const { fetchXMLBookings } = require('../fetchers')

const setOptions = (params, options) => {
  isStringValue(params.start) && (options.startDate = dateIsoFormat(dateFrom(params.start)))
  isStringValue(params.end) && (options.endDate = dateIsoFormat(dateFrom(params.end)))
  isStringValue(params.id) && (options.reservationId = params.id)
  isStringValue(params.pin) && (options.reservationPin = params.pin)
  return options
}

const resolveBookingDetail = ({ResStatus, CreateDateTime, LastModifyDateTime}) => {
  return { 
    status: ResStatus.toLowerCase(),
    created: dateTimeIsoFormat(dateTimeFrom(CreateDateTime)),
    modified: dateTimeIsoFormat(dateTimeFrom(LastModifyDateTime))
  }
}

const resolveBookingPeriod = ({Start, End}) => {
  return {
    arrival: dateIsoFormat(dateFrom(Start)),
    departure: dateIsoFormat(dateFrom(End))
  }
}

const resolveBookingReservation = ({ResID_Value, ResID_PIN}) => {
  return {
    id: ResID_Value,
    pin: ResID_PIN //Please note only Kognitiv Bookings have a Pin. BookingCom etc. will return null for this property
  }
}

const resolveXMLBookings = (xmlBookings, options) => {
  return xmlBookings.reduce((acc, {$, /* RoomStays, ResGuests,*/ ResGlobalInfo}) => {
     acc.push({
       detail: resolveBookingDetail($),
       period: resolveBookingPeriod({...ResGlobalInfo[0].TimeSpan[0].$}),
       reservation: resolveBookingReservation({...ResGlobalInfo[0].HotelReservationIDs[0].HotelReservationID[0].$})
     })
    return acc
  }, [])
}

const resolveBookings = async({ dataSources }, {}, params) => {
  const options = setOptions(params, {})
  const { data: xmlBookings, error: bookingsError } = await fetchXMLBookings(dataSources, {...params, ...options})
  bookingsError && console.log(`Bookings: ${bookingsError}`)
  return resolveXMLBookings(xmlBookings, options)
}

//resolver for dynamic call
const bookingsResolver = async (parent, params, context) => {
  return resolveBookings(context, parent.params, {...parent.params.options, ...params})
}

module.exports = {
  bookingsResolver,
  resolveBookings
}