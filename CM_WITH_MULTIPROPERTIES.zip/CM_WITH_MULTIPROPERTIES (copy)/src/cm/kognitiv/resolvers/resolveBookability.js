const generateCacheKey = require('../../../cache/L1Cache/generateCacheKey')

//resolver for internal calls
const resolveBookability = async ({ db }, { property, token }, params) =>
  db.findOne('bookability', { userId: params.userId, hotelCode: params.hotelId })

//resolver for dynamic call
const bookabilityResolver = async (parent, params, context, info) => {
  const { cache, ttl } = context
  const { userId, provider, language } = parent.params.options
  const key = generateCacheKey('bookability', params, userId, provider, language)
  const cacheHit = await cache?.get(key)
  if (cacheHit) {
    return JSON.parse(cacheHit)
  } else {
    const cacheableValue = await resolveBookability(context, parent.params, { ...parent.params.options, ...params })
    cache?.setEx(key, ttl, JSON.stringify(cacheableValue))
    return cacheableValue
  }
}

module.exports = {
  bookabilityResolver, //dynamic call
  resolveBookability, //internal call
}
