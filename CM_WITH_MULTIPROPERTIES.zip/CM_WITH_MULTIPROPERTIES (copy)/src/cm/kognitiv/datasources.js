const { RESTDataSource } = require('@apollo/datasource-rest')
const { defaults } = require('./constants')
const { defaults: sBDefault } = require('./smartBooking/constants')
const { readBookingsXML, readRatesXML } = require('./requests')
const {dateToday, dateIsoFormat, dateFrom} = require('../../utils/date')
const { queue } = require('../../utils/logger')


  //---------------------------- SMARTBOOKING ------------------------------

  const sBcreateChildrenAgesObj = (childrenAges) =>
  childrenAges.reduce((acc, age) => {
    return acc[age] ? { ...acc, [age]: parseInt(acc[age] + 1) } : { ...acc, [age]: 1 }
  }, {})

const sBcreateChildrenAgesString = (ages, roomNo) =>
  Object.keys(ages).reduce((acc, age) => {
    return `${acc}&child_room${roomNo}_age${age}=${ages[age]}`
  }, '')

/**
 * Generate adult_ and children_ - Parameters for offers fetching. Takes rooms array containing adults and childAges
 * @param {*} rooms
 */
const sBoccupancyQueryParams = (rooms) => {
  var params = rooms.reduce((acc, room, i) => {
    const ages = room.childAges ? sBcreateChildrenAgesObj(room.childAges) : []
    const children = room?.childAges?.length || 0
    return `${acc}&adult_room${i + 1}=${room.adults}${
      children > 0 ? `&child_room${i + 1}=${children}${sBcreateChildrenAgesString(ages, i + 1)}` : ``
    }`
  }, '')
  return params
}





/**
 * Generate adult_ and children_ - Parameters for offers fetching. Takes rooms array containing adults, children and childAges
 * @param {*} rooms
 */
const occupancyQueryParams = (rooms) => {
  var params = rooms.reduce((acc, room, i) => {
    const ages = room.children?.length ? sBcreateChildrenAgesObj(room.children) : []
    const children = room?.children?.length || 0
    return `${acc}&adult_room${i + 1}=${room.adults}${
      children > 0 ? `&child_room${i + 1}=${children}${sBcreateChildrenAgesString(ages, i + 1)}` : ``
    }`
  }, '')
  return params
}

const generateLoggerKey = (apiKey) =>
  `${apiKey},${new Date().toISOString().slice(0, 10)}@${new Date().toISOString().slice(11, 16)}`
  

class KognitivAPI extends RESTDataSource {
  /** API Key to Token Service https://connectivity.seekda.com/json/token_service
     Many of the json services require an additional identification by token: The tokens can be generated with your API-KEY
     and are valid for 60 minutes after generation.
   *
   * @param {Object} options
   * @param {string} [options.hotelId]  hotel code	CHNL_TEST
   * @param {string} [options.apiKey]   api key	b5b03bb0-b9ce-0132-b0ad-0050568825b4
   */
  async fetchToken({ hotelId, apiKey }) {
    return this.get(`https://cloud.seekda.com/w/w-dynamic-shop/hotel:${hotelId}/${apiKey}.json`)
  }

  /** Services https://connectivity.seekda.com/json/services
   * N.B: services have now different prices for different dates. The json API does not provide this information.
   * Information about from-to-dates and prices is in the XML only. The result of the json data depends on the
   * "start" and "end" parameters. For overlapping periods, the most expensive price is taken.

   * @param {Object} options
   * @param {string} options.hotelId  	  hotel code | HOTELID
   * @param {string} options.language     language code |	EN
   * @param {string} options.accessToken  authentication token
   * @param {string} options.startDate    start of time period to query	| 2020-06-13
   * @param {string} options.endDate      end of time period to query	| 2020-06-20
   * @param {string} [options.meta]       undocumented | categories
   * @param {string} options.currency 	  currency code | EUR
   */
  async fetchServices({ hotelId, language, accessToken, startDate, endDate, currency, meta }) {
    return this.get(`https://switch.seekda.com/switch/latest/json/services.json\
?skd-property-code=${hotelId}\
&skd-start-date=${startDate}\
&skd-end-date=${endDate}\
&skd-language-code=${language.toUpperCase()}\
${currency ? `&skd-currency-code=${currency}` : ``}\
${meta ? `&skd-metadata=${meta}` : ``}\
&token=${accessToken}`)
  }

  /** Bookability https://connectivity.seekda.com/json/bookability

     A service returning general info about the property setup (e.g. languages, currency etc.).

     In addition it has an array per occupancy that indicates if there are availabilities or not in a certain
     time period (useful for generating a calendar)
   *
   * @param {Object} options
   * @param {string} options.hotelId      hotel code | CHNL_MTS
   * @param {string} options.accessToken  authentication token
   * @param {string} options.startDate 	  start of time period | 2020-06-13
   * @param {string} options.numberOfDays number of days | 8
   */
  async fetchBookability({ hotelId, accessToken, startDate, numberOfDays }) {
    return this.get(`https://switch.seekda.com/switch/api/properties/${hotelId}/bookability.json\
?startDate=${startDate}\
&numberOfDays=${numberOfDays}\
&token=${accessToken}`)
  }

  /** Property Information https://connectivity.seekda.com/json/property_info

    A Service to query for available images, marketing description etc.

   *
   * @param {Object} options
   * @param {string} options.hotelId      hotel code	CHNL_MTS
   * @param {string} options.language     ISO-639-1 language-code	EN
   * @param {string} options.accessToken
   * @param {string} options.type         type of result | hotelsearch (additional documentation missing)
   */
  async fetchProperty({ hotelId, language, accessToken, type }) {
    return this.get(`https://switch.seekda.com/properties/${hotelId}/hotelinfo.json\
?language=${language.toUpperCase()}\
${type ? `&type=${type}` : ``}\
&token=${accessToken}`)
  }

  /** Rates Average https://connectivity.seekda.com/json/rates_average

    A Service to query for meta data of available rate plans plus the average prices for each month in the queried period

   *
   * @param {Object} options
   * @param {string} options.hotelId       	hotel code	CHNL_MTS
   * @param {string} options.language       language code	| EN
   * @param {string} options.accessToken    authentication token
   * @param {string} options.packages       load also packages, defaults to false |	true
   * @param {string} options.startDate      the start date, default to today |  2021-12-01
   * @param {string} options.months         the number of month to return, defaults to 6 | 12
   * @param {string} options.promotionCode  comma separated list of promotion codes (to show rates that are not public) |	ABC
   * @param {string} options.filterByPrice  whether rates / packages without prices should be ommited, defaults to true |	true
   * @param {string} options.channelId      channel for which the prices are valid; defaults to "ibe"	| ibe
   */
  async fetchRatesAverage({
    hotelId,
    language,
    accessToken,
    packages,
    startDate,
    months,
    promotionCode,
    filterByPrice,
    channelId,
  }) {
    return this.get(`https://switch.seekda.com/switch/latest/json/ratesAverage.json\
?skd-property-code=${hotelId}\
&skd-language-code=${language.toUpperCase()}\
&skd-channel-id=${channelId}\
${packages ? `&skd-packages=${packages}` : ``}\
${startDate ? `&skd-start=${startDate}` : ``}\
${months ? `&skd-months=${months}` : ``}\
${promotionCode ? `&skd-promotion-code=${promotionCode}` : ``}\
${filterByPrice ? `&skd-filter-by-price=${filterByPrice}` : ``}\
&token=${accessToken}`)
  }

  /** Offer Overview https://connectivity.seekda.com/json/offer_overview

    A service to retrieve an explanation when no offers are found for a certain period/occupancy, why that was and if there are any alternatives

   * @param {Object} options
   * @param {string} options.hotelId          hotel code | CHNL_MTS
   * @param {string} options.language         language code	| EN
   * @param {string} options.accessToken      authentication | token
   * @param {string} options.startDate        start of time period to query	| 2021-06-13
   * @param {string} options.checkin          checkin date | 2022-06-15
   * @param {string} options.lengthOfStay     length of stay | 8
   * @param {string} options.occupancy        occupancy |	2
   * @param {string} options.overviewLength   overview length |	112
   * @param {string} options.roomCodes        comma separated list (limits the response to only contain offers matching this room codes) | ROOM_1,ROOM_2
   * @param {string} options.rateCodes        comma separated list (limits the response to only contain offers matching this rate codes) | RATE_1,RATE_2
   * @param {string} options.promotionCode    comma separated list (adds corresponding offers to the response) | CODE_1,CODE_2
   * @param {string} options.overviewType     room or rate (defaults to room) |	rate
   * @param {string} options.channelId        identifies the channel (e.g. a portal) that requires the data, defaults to IBE | IBE
   */
  async fetchOffersOverview({
    hotelId,
    language,
    accessToken,
    startDate,
    checkin,
    lengthOfStay,
    occupancy,
    overviewLength,
    roomCodes,
    rateCodes,
    promotionCode,
    overviewType,
    channelId,
  }) {
    return this.get(`https://switch.seekda.com/switch/latest/json/offersOverview.json\
?skd-property-code=${hotelId}\
&skd-language-code=${language.toUpperCase()}\
&skd-start-date=${startDate}\
&skd-overview-length=${overviewLength}\
${checkin ? `&skd-checkin=${checkin}` : ``}\
${lengthOfStay ? `&skd-length-of-stay=${lengthOfStay}` : ``}\
${occupancy ? `&skd-occupancy=${occupancy}` : ``}\
${roomCodes ? `&skd-room-codes=${roomCodes}` : ``}\
${rateCodes ? `&skd-rate-codes=${rateCodes}` : ``}\
${promotionCode ? `&skd-promotion-code=${promotionCode}` : ``}\
${overviewType ? `&skd-overview-type=${overviewType}` : ``}\
${channelId ? `&skd-channel-id=${channelId}` : ``}\
&token=${accessToken}`)
  }

  /** Image Meta Data https://connectivity.seekda.com/json/images
     A Service to retrieve meta data for multimedia objects associated with a property

   * @param {Object} options
   * @param {string} options.hotelId  hotel code	| CHNL_MTS
  */
  async fetchImageMetaData({ hotelId }) {
    return this.get(`https://images.seekda.com/${hotelId}?list=all`)
  }

  /** Offers https://connectivity.seekda.com/json/offers

    A Service to query one hotel with a lot of details for available offers (only with specific dates).

   * @param {Object} options
   * @param {string} options.hotelId                     	hotel code	CHNL_MTS
   * @param {string} options.language                     language for metadata (falls back to the hotelier's default if not specified)	EN
   * @param {string} options.accessToken                  access token returned by the delivery app on initialisation
   * @param {string} options.checkin                      checkin date of the stay	2020-06-13
   * @param {string} options.checkout                     checkout date of the stay	2020-06-20
   * @param {string} options.rooms                        custom room occupancy object. will be converted to adult_room#, child_room# and child_room#_age# - parameters
   * @param {string} options.currency                     if not specified amounts are returned in hotel currency, if specified values are converted to the currency specified, supported: EUR, CHF, USD, GBP, THB, MYR, HKD, AUD, BGN, BRL, CAD, CNY, CZK, DKK, HRK, HUF, IDR, ILS, INR, JPY, KRW, LTL, LVL, MXN, NOK, NZD, PHP, PLN, RON, RUB, SEK, SGD, TRY, ZAR	EUR
   * @param {string} options.promotionCode                a rate protected by a promotion code is only returned if the code matches the value of this parameter	ABCDEF
   * @param {string} options.channelId                    id of the requesting channel. required to receive offers and prices valid for a specific channel
   * @param {string} options.rateplan                     search for offers with the given rateplan code	STANDARD_M
   * @param {string} options.metaRates                    if not specified, all rate metadata is returned (multiple entries allowed)
   * @param {string} options.metaRooms                    if not specified, all room metadata is returned (multiple entries allowed)
   * @param {string} options.metaChannels                 returns data related to the specified channels if enabled (none returned if not present)	TrustYou
   * @param {string} options.metaAmenities                returns the hotel amenities if specified (none otherwise)	true
   * @param {string} options.perDayPriceType              Controls which taxes and fees are included in the pricing_details and original_pricing_details arrays in each item of an offer. Supported values: excludingTaxesAndFees, withTaxesAndFees, withInformativeTaxesAndFees, withInformativeTaxesAndFeesExclCityTax. If not specified or invalid value, the prices are as in price list.	excludingTaxesAndFees
   * @param {string} options.includePerDayRates           When set the result contains the average daily price, defaults to false.	true
   * @param {string} options.includePerPersonPerDayRates  When set the result contains the average daily price per person, defaults to false.	true
   * @param {string} options.timePriceBase                When set to auto, the prices in the result are indicated according to the ibe time price base attribute for the guest's country, if set, or the default attribute as fallback, if set. The field auto_time_price_base in the result reports which setting was actually used or if no setting was found.
   */
  async fetchOffers({
    hotelId,
    language,
    accessToken,
    checkin,
    checkout,
    rooms,
    currency,
    promotionCode,
    channelId,
    rateplan,
    metaRates,
    metaRooms,
    metaChannels,
    metaAmenities,
    perDayPriceType,
    includePerDayRates,
    includePerPersonPerDayRates,
    timePriceBase,
    priceType,
  }) {

    return this.get(`https://switch.seekda.com/switch/api/offers.json\
?property_code=${hotelId}\
&checkin=${checkin}\
&checkout=${checkout}\
${occupancyQueryParams(rooms)}\
&language_code=${language.toUpperCase()}\
${channelId ? `&channel-id=${channelId}` : ``}\
${rateplan ? `&rateplan=${rateplan}` : ``}\
${metaRates ? `&meta_rates=${metaRates}` : ``}\
${metaRooms ? `&meta_rooms=${metaRooms}` : ``}\
${metaChannels ? `&meta_channels=${metaChannels}` : ``}\
${metaAmenities ? `&meta_amenities=${metaAmenities}` : ``}\
${currency ? `&currency_code=${currency}` : ``}\
${promotionCode ? `&promotion_code=${promotionCode}` : ``}\
${priceType ? `&price_type=${priceType}` : ``}\
${perDayPriceType ? `&per_day_price_type=${perDayPriceType}` : ``}\
${includePerPersonPerDayRates ? `&include_per_person_per_day_rates=${includePerPersonPerDayRates}` : ``}\
${timePriceBase ? `&time_price_base=${timePriceBase}` : ``}\
&token=${accessToken}`)
  }

  // /**
  //  *
  //  * @param {Object}  options
  //  * @param {string} options.hotelId    hotel code
  //  * @param {string}  options.apiUser    default api user is info@mts-italia.it, can only be changed in the protected user config
  //  * @param {string}  options.apiToken   api password for accessing data
  //  *
  //  */

  /**
   *
   * @param {Object}  options
   * @param {string}  options.hotelId    hotel code
   * @param {string}  options.apiUser    default api user is info@mts-italia.it, can only be changed in the protected user config
   * @param {string}  options.apiToken   api password for accessing data
   *
   */
  async fetchXMLRates(options) {
    // console.log("RATES XML...................", readRatesXML(options))
    const result = this.post('https://switch.seekda.com/switch/latest/ChannelConnect', {
      body: readRatesXML(options),
      headers: {
        'Content-Type': 'application/xml',
      },
    })
    return result
  }

  /**
   *
   * @param {Object}  options
   * @param {string}  options.hotelId    hotel code
   * @param {string}  options.apiUser    default api user is info@mts-italia.it, can only be changed in the protected user config
   * @param {string}  options.apiToken   api password for accessing data
   *
   */
  async fetchXMLHotelInfo({ hotelId, apiUser, apiToken }) {
    const auth = `Basic ${Buffer.from(`${apiUser}:${apiToken}`).toString('base64')}`
    return this.get(`https://switch.seekda.com/switch/1.009/rest/${hotelId}?skd-channel-id=${defaults.channelId}`, {
      headers: {
        'Content-Type': 'application/xml',
        Authorization: auth,
      },
    })
  }

  /**
   *
   * @param {Object}  options
   * @param {strring} options.hotelId    hotel code
   * @param {string}  options.apiUser    default api user is info@mts-italia.it, can only be changed in the protected user config
   * @param {string}  options.apiToken   api password for accessing data
   *
   */
  async fetchXMLServices({ hotelId, apiUser, apiToken }) {
    
    const auth = `Basic ${Buffer.from(`${apiUser}:${apiToken}`).toString('base64')}`
    console.log("auth..............",auth)
    return this.get(
      `https://switch.seekda.com/switch/1.009/rest/${hotelId}/services?skd-channel-id=${defaults.channelId}`,
      {
        headers: {
          'Content-Type': 'application/xml',
          Authorization: auth,
        },
      },
    )
  }

  /**
   *
   * @param {Object}  options
   * @param {strring} options.hotelId    hotel code
   * @param {string}  options.apiUser    default api user is info@mts-italia.it, can only be changed in the protected user config
   * @param {string}  options.apiToken   api password for accessing data
   *
   */
  async fetchXMLBookings(options) {
    const result = this.post('https://switch.seekda.com/switch/1.009/ChannelConnect', {
      body: readBookingsXML(options),
      headers: {
        'Content-Type': 'application/xml',
      },
    })
    return result
  }

  async fetchSmartBookingOffers({
    hotelId,
    language,
    accessToken,
    checkin,
    checkout,
    rooms,
    currency,
    promotionCode,
    channelId,
    rateplan,
    metaRates,
    metaRooms,
    metaChannels,
    metaAmenities,
    priceType,
    perDayPriceType,
    includePerDayRates,
    includePerPersonPerDayRates,
    timePriceBase,
  }) {
    return this.get(`https://switch.seekda.com/switch/api/offers.json\
?property_code=${hotelId}\
&checkin=${checkin}\
&checkout=${checkout}\
${rooms ? sBoccupancyQueryParams(rooms) : ``}\
&language_code=${language.toUpperCase()}\
${channelId ? `&channel-id=${channelId}` : ``}\
${rateplan ? `&rateplan=${rateplan}` : ``}\
${metaRates ? `&meta_rates=${metaRates}` : ``}\
${metaRooms ? `&meta_rooms=${metaRooms}` : ``}\
${metaChannels ? `&meta_channels=${metaChannels}` : ``}\
${metaAmenities ? `&meta_amenities=${metaAmenities}` : ``}\
${currency ? `&currency_code=${currency}` : ``}\
${promotionCode ? `&promotion_code=${promotionCode}` : ``}\
${priceType ? `&price_type=${priceType}` : ``}\
${perDayPriceType ? `&per_day_price_type=${perDayPriceType}` : ``}\
${includePerPersonPerDayRates ? `&include_per_person_per_day_rates=${includePerPersonPerDayRates}` : ``}\
${timePriceBase ? `&time_price_base=${timePriceBase}` : ``}\
&token=${accessToken}`)
  }

  async fetchSmartBookingProperty({ hotelId, language, accessToken, type }) {
    return this.get(`https://switch.seekda.com/properties/${hotelId}/hotelinfo.json\
?language=${language.toUpperCase()}\
&token=${accessToken}\
${type ? `&type=${type}` : ``}\
`)
  }

  async fetchSmartBookingServices({ hotelId, language, accessToken, startDate, endDate, currency, meta }) {
    return this.get(`https://switch.seekda.com/switch/latest/json/services.json?skd-property-code=${hotelId}\
&skd-start-date=${startDate}&skd-end-date=${endDate}&skd-language-code=${language.toUpperCase()}\
&skd-currency-code=${currency}&skd-metadata=categories&token=${accessToken}`)
  }

  async fetchSmartBookingToken({ hotelId, apiKey }) {
    return this.get(`https://cloud.seekda.com/w/w-dynamic-shop/hotel:${hotelId}/${apiKey}.json`)
  }

  async fetchSmartBookingXMLRates({ hotelId, apiUser, apiToken }) {
    const auth = `Basic ${Buffer.from(`${apiUser}:${apiToken}`).toString('base64')}`
    return this.get(
      `https://switch.seekda.com/switch/1.009/rest/${hotelId}/rates?skd-channel-id=${defaults.channelId}`,
      {
        headers: {
          'Content-Type': 'application/xml',
          Authorization: auth,
        },
      },
    )
  }
}

module.exports = KognitivAPI
