//all providers resolvers
const resolvers = {
  kognitiv: require('./kognitiv/resolvers'),
  alpinebits: require('./alpinebits/resolvers')
}

const cachers = {
  kognitiv: require('./kognitiv/cachers') 
}
//const casablanca = require('./casablanca/resolvers')

module.exports = {
  resolvers,
  cachers
}
