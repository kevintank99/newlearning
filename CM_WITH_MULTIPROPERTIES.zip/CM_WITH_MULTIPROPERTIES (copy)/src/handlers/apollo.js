const { ApolloServer } = require('@apollo/server')
const resolvers = require('../resolvers')
const schema = require('../schema')

const createServer = new ApolloServer({
  typeDefs: schema,
  resolvers,
  introspection: true,
})

module.exports = { apollo: createServer }
