const KognitivAPI = require('../cm/kognitiv/datasources')
const AlpinebitsAPI = require('../cm/alpinebits/datasources')
const db = require('../cache/L2Cache/mongoDB')
const cache = require('../cache/L1Cache/redis')

const DEFAULT_TTL = 86400 //24 hours

const context = ({ req }) => {
  const ttl =
    req?.headers?.['cache-control']?.match(/max-age+/g) && Number(req?.headers?.['cache-control']?.match(/[0-9]+/g))
  return {
    dataSources: {
      kognitiv: new KognitivAPI(),
      alpinebits: new AlpinebitsAPI()
    },
    db: new db(),
    // ...(req?.headers?.['cache-control'] === 'no-cache' ? {} : { cache, ttl: isNaN(ttl) ? DEFAULT_TTL : ttl }),
  }
}

module.exports = context
