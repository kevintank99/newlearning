const convertToDaysStringAlpinebits = async (stringsFromXML) => {
  const days = []
  const minstaythru = []
  const arrival = []
  const departure = []
  const availability = []

  // check availability
  for (let index in stringsFromXML?.minstay) {
    days[index] = stringsFromXML.minstay[index] === '-' ? '1' : stringsFromXML.minstay[index]
    availability[index] = stringsFromXML.availability[index]
    if(parseInt(availability[index]) < 1 || stringsFromXML.master[index] == '0') {
      days[index] = '0'
    }
  }
  
  for (let index in stringsFromXML?.minstay) {
    minstaythru[index] = stringsFromXML.minstaythru[index]
    arrival[index] = stringsFromXML.arrival[index]
    departure[index] = stringsFromXML.departure[index]

    //When current alphabet of string denotes the current date to be closed to arrival and previous date has no room available
    //then the current date value will be no room available as well
    if ((arrival[index] === '0' && days[parseInt(index) - 1] === '0') || (index == 0 && arrival[index] === '0')) {
      days[index] = '0'
    }

    //When current alphabet is open for arrival and departure and contains minimum stay
    else if (days[index] !== '0') { // && arrival[index] === '1' && departure[index] === '1'
      //For some clients minstay through is less than minstay
      //in that case we need to consider minstay through value
      if (minstaythru[index] !== '-' && parseInt(days[index]) < parseInt(minstaythru[index])) {
        days[index] = minstaythru[index]
      }
      //Iterate 'j' to check whether any no rooms available for next minimum stay amount of days
      for (let j = 0; j < parseInt(days[index]); j++) {
        //Validation to check the no rooms available for current 'j' of iteration based on minimum stay amount
        //if true replace the minimum stay amount with closed to arrival
        if (days[parseInt(index) + parseInt(j)] === '0') {
          //Check whether the previous index of closed to arrival from current index is available
          //if not then replace it with no room available else keep closed to arrival
          days[index] = days[parseInt(index) - 1] === '0' || index === '0' ? '0' : '$'
          break
        }
      }
    }
  }
  return days
}

module.exports = convertToDaysStringAlpinebits

