const fetch = require('node-fetch')
const fs = require('fs')
const url = require("url");
const path = require("path");

const downloadFile = (async (sourceUrl, destinationPath) => {
  const res = await fetch(sourceUrl);
  const parsedUrl = url.parse(sourceUrl)
  const urlFileName = path.posix.basename(sourceUrl)

  const fileStream = fs.createWriteStream(destinationPath + decodeURIComponent(urlFileName));
  console.log('download', sourceUrl, destinationPath, urlFileName)
  await new Promise((resolve, reject) => {
      res.body.pipe(fileStream);
      res.body.on("error", (err) => {
        console.log('pipe error', err)
        reject(err);
      });
      fileStream.on("finish", function() {
        console.log('filestream finished')
        resolve();
      });
    });
});

module.exports = downloadFile
