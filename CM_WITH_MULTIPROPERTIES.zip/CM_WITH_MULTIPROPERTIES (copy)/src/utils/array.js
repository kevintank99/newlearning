const arrayJoin = (s, a) => a.join(s) //join an array to string with separator (s)
const arrayJoinFn = (fn, a) => a.join(fn(a))
const arrayMap = (f, a) => a.map(f) // map function f over array a
const arrayFilter = (f, a) => a.filter(f);
const arrayFilterOne = (f, a) => arrayFilter(f, a)[0]
const arrayPush = (v, a) => [].concat(a, v) //https://vincent.billey.me/pure-javascript-immutable-array/
const arrayFirst = (a) => a.slice(1) //return first element of array (shift)
const arrayLast = (a) => a.slice(0, -1) //return last element of array (pop)
const asArray = (l) => Array.from(l)
const arrayReduce = (f, a) => (v) => a.reduce(f, v)
const arrayReduceRight = (f, a) => (v) => a.reduceRight(f, v)
const arrayClone = (a) => [].concat(a)
const arrayContains = (s, a) => a.indexOf(s) > -1
const arrayIntersect = (a,b) => a.filter(value => b.includes(value))
/* impure */
const arrayMutatePush = (v, a) => a.push(v)

module.exports = {
  arrayJoin,
  arrayJoinFn,
  arrayMap,
  arrayFilter,
  arrayFilterOne,
  arrayPush,
  arrayFirst,
  arrayLast,
  asArray,
  arrayReduce,
  arrayReduceRight,
  arrayClone,
  arrayContains,
  arrayMutatePush,
  arrayIntersect
}