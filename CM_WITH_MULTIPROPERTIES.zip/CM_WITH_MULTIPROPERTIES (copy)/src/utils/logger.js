const fs = require('fs')

const queue = []

const logger = async () => {
  if (!queue.length) {
    return
  }
  const q = [...queue]
  q.forEach((key) => {
    const [apiKey, date] = key.split(',')
    if (fs.existsSync('./apiLogCount.json')) {
      const data = fs.readFileSync('./apiLogCount.json')
      const json = data.length ? JSON.parse(data) : {}
      if (!json[apiKey]) {
        json[apiKey] = {}
      }
      if (json[apiKey][date]) {
        json[apiKey][date] = json[apiKey][date] + 1
      } else {
        json[apiKey][date] = 1
      }
      fs.writeFileSync('./apiLogCount.json', JSON.stringify(json))
    } else {
      const json = {
        [apiKey]: {
          [date]: 1,
        },
      }
      fs.writeFileSync('./apiLogCount.json', JSON.stringify(json))
    }
    queue.shift()
  })
}

const apiLoggerInit = () => {
  setInterval(logger, 10 * 60 * 1000)
}

module.exports = {
  apiLoggerInit,
  queue,
}
