const parseString = require('xml2js').parseString

const parseXML = (xml) =>
  new Promise((resolve, reject) => {
    parseString(xml, (err, result) => {
      if (err) {
        reject(err)
      } else {
        resolve(result)
      }
    })
  })

// remove namespacing and sanitize the xml
const cleanKognitivXML = (XML) =>
  [
    {
      match: /ota:| xmlns:ota="http:\/\/www.opentravel\.org\/OTA\/2003\/05"| xmlns="http:\/\/www.opentravel.org\/OTA\/2003\/05"|seekda:| xmlns:seekda="http:\/\/connect.seekda.com\/2009\/04"/g,
      replaceWith: '',
    },
    { match: /[\x00-\x08\x0B\x0C\x0E-\x1F\x80-\x9F]/u, replaceWith: '' }, // remove non visible control characters
    { match: /[\xA0]/u, replaceWith: ' ' }, // replace utf8 non breaking space
    { match: /\r?\n/m, replaceWith: ' ' }, // remove newlines
    { match: /[\t\s]+/m, replaceWith: ' ' }, // replace tabs and spaces with one space
    { match: /s*&euro;s*/, replaceWith: '&nbsp;€&nbsp;' }, // avoid € breaking to the next line
  ].reduce((acc, rule) => acc.replace(rule.match, rule.replaceWith), XML)


module.exports = {
  parseXML,
  cleanKognitivXML
}