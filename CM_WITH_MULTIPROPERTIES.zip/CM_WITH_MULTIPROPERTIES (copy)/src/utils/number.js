const {strSub} = require('./string')
const {isNumber} = require('./type')

const twoDigits = (n) => strSub('00' + n, -2) //return two digits 0 prefixed string for number n
const isPositiveNumber = (n) => isNumber(n) && n > 0

module.exports = {
  twoDigits,
  isPositiveNumber
}