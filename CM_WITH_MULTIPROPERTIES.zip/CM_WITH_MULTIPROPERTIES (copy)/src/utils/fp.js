const { isValue } = require("./type");
const { arrayReduce, arrayReduceRight } = require("./array");

const fnId = (x) => x 
const fnReturn = (f) => fnId //helper when inside arrow function a single statement has to be executed and another value has to be returned
const fnCompose = (...fns) => (x) => arrayReduceRight((res, fn) => fn(res), fns)(x); //function composition (rtl)
const fnPipe = (...fns) => (x) => arrayReduce((res, fn) => fn(res), fns)(x); //function composition (ltr)
const fnTap = (f) => (x) => fnReturn(f(x))(x)  //way to invoke a function like console.log within Pipe or Compose
const fnTrace = (label) => fnTap(console.log.bind(console, label + ':'));
const fnIfElse = (fnCheck, fnTrue, fnFalse) => (x) => fnCheck(x) ? fnTrue(x) : fnFalse(x)
const fnIfValue = (f) => (x) => fnIfElse(isValue, f, fnId)(x)
const fnIf = (fnCheck, fnOk) => (x) => fnIfElse(fnCheck, fnOk, fnId)(x)
const fnGt = (v) => (x) => x > v
const fpConst = (c) => () => c //constant combinator, always returns c
const fnAlways = () => true //helper function to return always true

module.exports = {
 fnId,
 fnReturn,
 fnCompose,
 fnPipe,
 fnTap,
 fnTrace,
 fnIfElse,
 fnIfValue,
 fnIf,
 fnGt,
 fpConst,
 fnAlways,
}