/* type checks */
const typeOf = (v) => typeof v //generic typeof with all odds (null = object, NaN = number, [] = object, etc.)
const isDefined = (v) => typeOf(v)!== 'undefined' //is (v) defined
const isObjectLike = (o) => typeOf(o) === 'object' //is o an object or array
const isNull = (v) => isDefined(v) && v === null //is v null but defined
const isNotNull = (v) => !isNull(v) //is v not null or undefined
const isValue = (v) => isDefined(v) && !isNull(v) && isNaN(v) //is v defined an has a value not null or NaN
const isNoValue = (v) => !isValue(v)  //is v undefined or null or NaN
const isLength = (v) => !!v.length //does (v) have a length <> 0
const isString = (s) => typeOf(s) === 'string' //is (s) of type "string"
const isStringValue = (s) => isString(s) && isLength(s) //is (s) a non empty string
const isArray = (v) => isObjectLike(v) && isNotNull(v) && Array.isArray(v); //is (v) an array
const isArrayValue = (a) => isArray(a) && isLength(a); //is (a) a non empty array
const isObject = (o) => isObjectLike(o) && isNotNull(o) && !isArray(o); //is (v) an object (but NOT an array and not null - n.B. typeof null = object)
const isObjectEmpty = (o) => !isLength(Object.entries(o)) //is the object (o) with no properties (n.B. no type check is performed on "o")
// const isEmptyObject = (o) => isObject(o) && isObjectEmpty(o);
const isObjectValue = (o) => isObject(o) && !isObjectEmpty(o); //check if (o) is an object with properties
const isNumber = (n) => typeOf(n) === 'number' && isFinite(n); //check for valid finite number (note: this excludes NaN - if check for NaN is wanted use isNaN())
const isFunction = (f) => typeOf(f) === 'function' //is (f) of type function
const isDate = (d) => isObjectLike(d) && d instanceof Date //is (d) of type date

module.exports = {
  typeOf,
  isDefined,
  isObjectLike,
  isNull,
  isNotNull,
  isValue,
  isNoValue,
  isLength,
  isString,
  isStringValue,
  isArray,
  isArrayValue,
  isObject,
  isObjectEmpty,
  isObjectValue,
  isNumber,
  isFunction,
  isDate
}
