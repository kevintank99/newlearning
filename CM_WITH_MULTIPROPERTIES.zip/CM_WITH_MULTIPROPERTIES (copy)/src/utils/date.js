const {isStringValue} = require('../utils/type')

const dateDate = (d) => d.getDate()
const dateYear = (d) => d.getFullYear()
const dateMonth = (d) => d.getMonth()
const dateDay = (d) => d.getDay()

const dateCreate = (yyyy, mm, dd) => new Date(Date.UTC(yyyy, mm, dd, 0, 0, 0, 0, 0)) //time value is always reset to 00:00
const dateFrom = (s) => new Date(isStringValue(s) ? s + 'T00:00:00.000Z' : s) 
const dateTimeFrom = (s) => new Date(isStringValue(s) ? s : s)
const dateClone = (d) => dateCreate(dateYear(d), dateMonth(d), dateDate(d)) 
const dateFirstOfMonth = (d) => dateCreate(dateYear(d), dateMonth(d), 1);
const dateLastOfMonth = (d) => dateCreate(dateYear(d), dateMonth(d) + 1, 0)
const dateDiffDays = (d1, d2) => Math.floor((dateClone(d2) - dateClone(d1)) / 86400000) //get the difference in days between two dates. 0 = equal | <0 = d1 > d2 | >0 = d2 > d1
const dateSameDate = (d1, d2) => dateDiffDays(d1, d2) === 0
const dateBefore = (d1, d2) => d1 < d2 ? d1 : d2
const dateAfter = (d1, d2) => d2 > d1 ? d2 : d1
const dateBetween = (d1, d2) => (d) => dateDiffDays(dateBefore(d1, d2), d) >= 0 && dateDiffDays(dateAfter(d1, d2), d) <= 0
const dateBetweenEx = (d1, d2) => (d) => dateDiffDays(dateBefore(d1, d2), d) > 0 && dateDiffDays(dateAfter(d1, d2), d) < 0
const dateMonthLength = (d) => dateLastOfMonth(d).getDate()
const dateAddMonths = (n, d) => dateCreate(dateYear(d), dateMonth(d) + n, dateDate(d))
const dateAddDays = (n, d) => dateCreate(dateYear(d), dateMonth(d), dateDate(d) + n)
const dateToday = () => dateClone(new Date) //impure - result depends on current date
const dateIsoFormat = (d) => d.toISOString().substr(0, 10)
const dateTimeIsoFormat = (d) => d.toISOString()
const timeWithTimeZone = (timeZone, d, hour, minute, second) => {
  let date = new Date(Date.UTC(dateYear(d), dateMonth(d), dateDate(d), hour, minute, second));

  let utcDate = new Date(date.toLocaleString('en-US', { timeZone: "UTC" }));
  let tzDate = new Date(date.toLocaleString('en-US', { timeZone: timeZone }));
  let offset = utcDate.getTime() - tzDate.getTime();

  date.setTime( date.getTime() + offset );

  return dateTimeIsoFormat(date).substr(10);
};
const dateAfterTimeRange = (t) => {
  let years = 0, months = 0, days = 0
  const indexOfYear = t.indexOf("year")
  if(indexOfYear > 0){
    years = t.slice(0,indexOfYear).split(' ')[0]
    t = t.replace(/year /,'').replace(/years /,'').slice(indexOfYear)
  }
  const indexOfMonth = t.indexOf("month")
  if(indexOfMonth > 0){
    months = t.slice(0,indexOfMonth).split(' ')[0]
    t = t.replace(/month /,'').replace(/months /,'').slice(indexOfMonth)
  }
  const indexOfDay = t.indexOf("day")
  if(indexOfDay > 0){
    days = t.slice(0,indexOfDay).split(' ')[0]
    t = t.replace(/day /,'').replace(/days /,'').slice(indexOfDay)
  }
  const succeedingDate = dateToday()
  succeedingDate.setFullYear(succeedingDate.getFullYear() + Number(years))
  succeedingDate.setMonth(succeedingDate.getMonth() + Number(months))
  succeedingDate.setDate(succeedingDate.getDate() + Number(days))
  return succeedingDate
}
const dateDiffDaysAfterTimeRange = (t) => {
  return dateDiffDays(dateToday(), dateAfterTimeRange(t))
}


module.exports = {
  dateFrom,
  dateDate,
  dateYear,
  dateMonth,
  dateDay,
  dateCreate,
  dateToday,
  dateIsoFormat,
  dateDiffDays,
  dateAddDays,
  dateTimeFrom,
  dateTimeIsoFormat,
  dateAfterTimeRange,
  dateDiffDaysAfterTimeRange,
  timeWithTimeZone
}
//date manipulation
