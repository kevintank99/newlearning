const { resolvers, cachers } = require('./cm')
const smartBookingResolver = require('./cm/kognitiv/smartBooking/resolveSmartBooking')
const { evictUserCache, evictAllCache } = require('./cache/L1Cache/cacheEviction')
const updateConfig = require('./cache/L2Cache/updateConfig')
const revalidateUsers = require('./cache/L2Cache/revalidateUsers')

module.exports = {
  Query: {
    //cm: all the calls which require token and property data
    cm: async (parent, params, context, info) => {
      return resolvers[params.provider].resolveCm(parent, params, context, info)
    },
    smartBooking: async (parent, params, context, info) => {
      switch (params.provider) {
        case 'kognitiv':
          return await smartBookingResolver(parent, params, context, info)
        default:
          return {}
      }
    },
  },
  Cm: {
    params: async (parent, params, context, info) => {
      return {} //hide the params from being viewed
    },
    childAges: async (parent, params, context, info) => {
      return resolvers[parent.params.options.provider].resolveChildAges(parent, params, context, info)
    },
    seasons: async (parent, params, context, info) => {
      return resolvers[parent.params.options.provider].resolveSeasons(parent, params, context, info)
    },
    services: async (parent, params, context, info) => {
      return resolvers[parent.params.options.provider].resolveServices(parent, params, context, info)
    },
    categories: async (parent, params, context, info) => {
      return resolvers[parent.params.options.provider].resolveCategories(parent, params, context, info)
    },
    rooms: async (parent, params, context, info) => {
      return resolvers[parent.params.options.provider].resolveRooms(parent, params, context, info)
    },
    roomCategories: async (parent, params, context, info) => {
      return resolvers[parent.params.options.provider].resolveRoomCategories(parent, params, context, info)
    },
    rates: async (parent, params, context, info) => {
      return resolvers[parent.params.options.provider].resolveRates(parent, params, context, info)
    },
    priceList: async (parent, params, context, info) => {
      return resolvers[parent.params.options.provider].resolvePriceList(parent, params, context, info)
    },
    pictures: async (parent, params, context, info) => {
      return resolvers[parent.params.options.provider].resolvePictures(parent, params, context, info)
    },
    bookings: async (parent, params, context, info) => {
      return resolvers[parent.params.options.provider].resolveBookings(parent, params, context, info)
    },
    offers: async (parent, params, context, info) => {
      return resolvers[parent.params.options.provider].resolveOffers(parent, params, context, info)
    },
    calendar: async (parent, params, context, info) => {
      return resolvers[parent.params.options.provider].resolveCalendar(parent, params, context, info)
    },
    firstBookableRange: async (parent, params, context, info) => {
      return resolvers[parent.params.options.provider].resolveFirstBookableRange(parent, params, context, info)
    },
    lastAvailableRooms: async (parent, params, context, info) => {
      return resolvers[parent.params.options.provider].resolveLastAvailableRooms(parent, params, context, info)
    },
    roomOffers: async (parent, params, context, info) => {
      return resolvers[parent.params.options.provider].resolveRoomOffers(parent, params, context, info)
    },
    overview: async (parent, params, context, info) => {
      return resolvers[parent.params.options.provider].resolveOverview(parent, params, context, info)
    },
    mealplans: async (parent, params, context, info) => {
      return resolvers[parent.params.options.provider].resolveMealplans(parent, params, context, info)
    },
    offersForAutoReply: async (parent, params, context, info) => {
      return resolvers[parent.params.options.provider].resolveOffersForAutoReply(parent, params, context, info)
    },
    bookability: async (parent, params, context, info) => {
      return resolvers[parent.params.options.provider].resolveBookability(parent, params, context, info)
    },
    hotels: async(parent, params, context, info) => {
      return resolvers[parent.params.options.provider].resolveHotels(parent, params, context, info)
    }
  },
  Mutation: {
    evictUserCache: async (parent, params, context, info) => {
      return evictUserCache(parent, params, context, info)
    },
    evictAllCache: async (parent, params, context, info) => {
      return evictAllCache(parent, params, context, info)
    },
    cache: async (parent, params, context, info) => {
      return cachers[params.provider].cacheCm(parent, params, context, info)
    },
    updateConfig: async (parent, params, context, info) => {
      return updateConfig(parent, params, context, info)
    },
    revalidateUsers: async (parent, params, context, info) => {
      return revalidateUsers(parent, params, context, info)
    },
  },
  CmCache: {
    ratesXML: async (parent, params, context, info) => {
      return cachers[parent.params.options.provider].cacheRatesXML(parent, params, context, info)
    },
    servicesXML: async (parent, params, context, info) => {
      return cachers[parent.params.options.provider].cacheServicesXML(parent, params, context, info)
    },
    hotelInfoXML: async (parent, params, context, info) => {
      return cachers[parent.params.options.provider].cacheHotelInfoXML(parent, params, context, info)
    },
    servicesJSON: async (parent, params, context, info) => {
      return cachers[parent.params.options.provider].cacheServicesJSON(parent, params, context, info)
    },
    hotelInfoJSON: async (parent, params, context, info) => {
      return cachers[parent.params.options.provider].cacheHotelInfoJSON(parent, params, context, info)
    },
    bookabilityJSON: async (parent, params, context, info) => {
      return cachers[parent.params.options.provider].cacheBookabilityJSON(parent, params, context, info)
    },
    ratesAverageJSON: async (parent, params, context, info) => {
      return cachers[parent.params.options.provider].cacheRatesAverageJSON(parent, params, context, info)
    },
    offersOverviewJSON: async (parent, params, context, info) => {
      return cachers[parent.params.options.provider].cacheOffersOverviewJSON(parent, params, context, info)
    },
  },
}