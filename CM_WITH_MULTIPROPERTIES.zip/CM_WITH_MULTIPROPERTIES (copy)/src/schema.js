module.exports = `
  scalar JSON

  # ======================= Seasons =======================

  type Season {
    code: String
    title: String
    periods: [Period]
    years: String
  }

  type Period {
    from: Int
    to: Int
    start: String
    end: String
    priceList: [PriceList]
  }

  # ======================= Categories =======================

  type PictureTopic {
    code: String
    title: String
  }

  type Picture {
    topic: PictureTopic
    width: Int
    height: Int
    size: Int
    title: String
    url: String
  }

  type Image {
    title: String
    url: String
    fileName: String
    description: String
    width: Int
    height: Int
    alternativeSizes: [ImageAlternatives]
  }

  type ImageAlternatives {
    title: String
    url: String
    description: String
    width: Int
    height: Int
    category: String
    size: String
  }

  type Category {
    code: String
    title: String
    description: String
    images: [Image]
  }

  type RoomCategory {
    code: String
    title: String
    description: String
    images: [Image]
    rooms: [String]
  }

  # ======================= Services =======================

  type Price {
    amount: Float
    currency: String
  }

  type ServiceDates {
    start: String
    end: String
  }

  type ServiceAvailability {
    minlos: String
    maxlos: String
    prices: String
    dates: [ServiceDates]
  }

  type Service {
    code: String
    title: String
    description: String
    categories: [String]
    images: [Image]
    price: Price
    sort: Int
    packageConditionsCode: String
    teaser: String
    unit_price: Float
    priceBase: String
    limitType: String
    priceBaseDescription: String
    limitTypeDescription: String
    availability: ServiceAvailability
  }

  # ======================= Rooms =======================

  type RoomOccupancy {
    std: Int
    min: Int
    max: Int
    range: String
    minChildren: Int
    maxChildren: Int
    minAdults: Int
    maxAdults: Int
  }

  type RoomBedsType {
    code: Int
    name: String
  }

  type RoomType {
    code: Int
    name: String
    camping: Boolean
  }

  type RoomBeds {
    stdNum: Int
    maxRollaways: Int
    type: RoomBedsType
  }

  type RoomAmenity {
    code: String
    title: String
    quantity: Int
  }

  type Room {
    code: String
    title: String
    description: String
    size: String
    occupancy: RoomOccupancy
    nonSmoking: Boolean
    quantity: Int
    beds: RoomBeds
    categories: [RoomCategory]
    type: RoomType
    amenities: [RoomAmenity]
    custom_amenities: [RoomAmenity]
    images: [Image]
    floorplans: [Image]
    maxChildAge: Int
  }

  # ======================= Rates =======================

  # ======================= ChildAges =======================

  type ChildAge {
    code: String
    fromAge: Int
    toAge: Int
    ageRange: String
    ratePercent: Float
    rateAmount: Float
    freeOfCharge: Boolean
    priceType: String
    title: String
  }

  # ======================= Full Overview =======================

  #type Overview {
  #  startDate: String
  #  days: Int
  #  seasons: [Season]
  #  years: String
  #  rooms: [Room]
  #  offers: [Offer]
  #  prices: [Prices]
  #  children: [Children]
  #  mealplans: [Mealplan]
  #}

  # ======================= Bookings =======================

  type BookingPeriod {
    arrival: String
    departure: String
  }

  type BookingReservation {
    id: String
    pin: String
  }

  type BookingDetail {
    created: String
    modified: String
    status: String
  }

  type Booking {
    detail: BookingDetail
    period: BookingPeriod
    reservation: BookingReservation
  }

  type SmartBookingRoom {
    available: Boolean
    code: String
    title: String
    prices: SmartBookingRoomPrice
    description: String
    category: SmartBookingRoomCategory
    occupancy: SmartBookingOccupancy
    size: Int
    nonSmoking: Boolean
    beds: SmartBookingBeds
    images: SmartBookingImages
    amenities: [SmartBookingAmenity]
  }

  type SmartBookingRoomPrice {
    basePrice: Int
    breakfastPrice: Int
    halfBoardPrice: Int
  }

  type SmartBookingRoomCategory {
    code: String
    title: String
  }

  type SmartBookingOccupancy {
    min: Int
    max: Int
    std: Int
    range: String
  }

  type SmartBookingBeds {
    std_num: Int
    max_rollaways: Int
    type: SmartBookingBedType
  }

  type SmartBookingBedType {
    code: Int
    name: String
  }

  type SmartBookingImages {
    internal: [SmartBookingImage]
    plan: [SmartBookingImage]
  }

  type SmartBookingImage {
    url: String
    XSmall: SmartBookingImage
    Small: SmartBookingImage
    Medium: SmartBookingImage
    Large: SmartBookingImage
    XLarge: SmartBookingImage
    description: String
    title: String
    width: Int
    height: Int
    size: String
    category: String
  }

  type SmartBookingAmenity {
    code: String
    detail: String
    title: String
    quantity: Int
  }

  enum MergeType {
    RATEPLANS
    OFFERS
    RATEPLANS_AND_OFFERS
  }

  type CalendarPrices {
    mealplans: JSON
    min: String
    max: String
  }

  type Calendar {
    days: String
    maxstay: String
    blacklistedStays: String
    meal_plans: JSON
    prices: CalendarPrices
    closedto: String
    currency_code: String
    timezone: String
  }

  enum FirstBookablePriceType {
    DEFAULT
    PER_NIGHT
    PER_PERSON
    PER_NIGHT_PER_PERSON
  }

  input calendarRoomOccupancy {
    adults: Int
    children: [Int]
  }

  type PricingOfOffer {
    code: String
    price: Float
    start: String
    end: String
    pricing_details: JSON
    original_pricing_details: JSON
  }

  type OfferPromotion {
    expires: String
    freeNights: String
    freeChildren: String
    lastMinute: Boolean
  }

  type CalendarPriceOfOffer {
    startIndex: Int,
    nights: Int,
    prices: [Float]
  }

  type OfferDetails {
    checkin: String
    checkout: String
    on_hold_duration: String
    discount_percent: String
    total: Float
    prepayment_amount: Float
    refundable: String
    currency_code: String
    original_total: Float
    original_per_day_price: Float
    original_per_person_per_day_price: Float
    room_code: String
    primary_item_code: String
    quantity: Int
    items: [PricingOfOffer]
    promotion: [OfferPromotion]
    meal_plan_code: String
    calendar: CalendarPriceOfOffer
  }

  type Offers {
    rateplans: [OfferDetails]
    offers: [OfferDetails]
    allRateplans: [OfferDetails]
    allOffers: [OfferDetails]
    alternativeRooms: [String]
    alternativeOffers: [String]
  }

  enum PriceTypes {
    SINGLE
    STD
  }

  type RoomOfferPrices {
    min: Float
    max: Float
    mealplans: JSON
  }

  type RoomOffers {
    code: String
    roomCode: String
    title: String
    teaser: String
    description: String
    images: [Image]
    minStay: String
    price: RoomOfferPrices
    availabilityPeriod: JSON
    mealPlanInfo: JSON
    minimumOccupancy: Int
    standardOccupancy: Int
    maximumOccupancy: Int
  }

  type Overview {
    roomCode: String
    rateplans: [RateplanOrOffer]
    offers: [RateplanOrOffer]
  }

  type RateplanOrOffer {
    room_code: String
    rate_code: String
    title: String
    description: String
    meal_plan_code: String
    availabilities: String
    days: String
    min_los: String
    min_stay_thru: String
    max_los: String
    max_stay_thru: String
    closed_to: String
    prices: String
  }

  type Bookability {
    maxRoomsPerBooking: Int
    availabilities: [String]
    minLengthOfStay: Int
    maxLengthOfStay: Int
    defaultLengthOfStay: Int
    globalMinOccupancy: Int
    globalMaxOccupancy: Int
    defaultOccupancy: Int
    availableRoomTypes: [String]
    maxChildAge: Int
    minChildAge: Int
    childAgeRanges: [String]
  }

  type CacheLogs {
    success: Boolean
    error: Boolean
    message: String
    reason: JSON
  }

  type RateSummary {
    amount: String,
    single: String,
    std: String,
    guests: String,
    rate: JSON
  }

  type AdultRateSummary {
    min: RateSummary
    max: RateSummary
  }

  type ChildrenRateSummary {
    min: JSON
    max: JSON
  }

  type PriceSummary {
    type: String
    adults: AdultRateSummary
    children: ChildrenRateSummary
  }

  type RateDetails {
    code: String!
    title: String
    description: String
    ratePlanType: String
    price: PriceSummary
    onSale: Boolean
  }

  type PriceList {
    roomcode: String!
    rateplans: [RateDetails]
    offers: [RateDetails]
    price: PriceSummary
  }

  type HotelAmenities {
    code: String
    detail: String
    title: String
  }

  type HotelName {
    shortName: String
    content: String
  }

  type Hoteldescription {
    detail_code : String
    language : String
    title : String
    descriptions : [JSON]
    plain_descriptions : [String]
  }

  type Hoteldescriptions{
    image_items : [Picture]
    text_items : [Hoteldescription]
  }

  type HotelInfo {
    amenities : [HotelAmenities]
    name : [HotelName]
    descriptions : Hoteldescriptions
    mealPlan: [String]
  }

  type HotelContacts {
    addresslines : String
    city : String
    country : String
  }

  type HotelExt {
    children : [ChildAge]
  }
  type HotelRoom{
    types : [String]
  }
  type HotelFacility{
    rooms : HotelRoom
  }
  type HotelData {
    hotelCode: String
    info: HotelInfo
    facility: HotelFacility
    contacts : [HotelContacts]
    ext : HotelExt
    price : JSON
  }
  
  type filterData{
    amenities : JSON
    destination : [String]
    priceRang : JSON
    roomTypes : [String]
    mealPlan : [String]
    childrenRange: JSON
  }

  type Hotel {
    hotelInfo: [HotelData]
    filterInfo: filterData
  }

  type Cm {
    params: JSON #all the shared data objects will reside here
    seasons(codes: String, start: String, length: Int, pricetype: PriceTypes, promotionCodes: String): [Season]
    rooms(codes: String, categories: String): [Room]
    roomCategories: [Category]
    categories(codes: String): [Category]
    services(categories: String, services: String): [Service]
    pictures(topics: String): [Picture]
    rates(startDate: String, length: Int): JSON
    availability(startDate: String, length: Int): JSON
    priceList(pricetype: PriceTypes, mergeType: MergeType, promotionCodes: String, startDate: String, endDate: String, useConfig: Boolean): [PriceList]
    childAges: [ChildAge]
    bookings(id: String, start: String, end: String): [Booking]
    smartBooking: [SmartBookingRoom]
    offers(roomCode: String, offerCode: String, start: String!, end: String!, adults: Int, children: [Int], promotionCode: String): Offers
    calendar(
      roomCode: String
      offerCode: String
      mergeType: MergeType
      rooms: [calendarRoomOccupancy]
      skipPriceOfRooms: String
      allDaysAvailable: Boolean
      promotionCodes: String
    ): Calendar
    firstBookableRange(
      minstay: Int
      maxstay: Int
      lengthofdays: Int
      skipRooms: String
      priceType: FirstBookablePriceType
      promotionCodes: String
    ): JSON
    lastAvailableRooms(
      roomCode: String
      staticStartDate: String
      staticEndDate: String
      dynamicStart: Int
      dynamicEnd: Int
      adults: Int
      children: [Int]
      promotionCodes: String
    ): JSON
    roomOffers(roomCode: String, priceType: PriceTypes, offerCode: String): [RoomOffers]
    overview(roomCode: String, priceType: PriceTypes, promotionCodes: String): [Overview]
    mealplans(roomCode: String, includeOffers: Boolean, promotionCodes: String): JSON
    offersForAutoReply(roomCode: String, start: String!, end: String!, rooms: [calendarRoomOccupancy], promotionCode: String): JSON
    bookability: Bookability
    hotels(roomCode: String, offerCode: String, start: String!, end: String!, adults: Int, children: [Int], promotionCode: String):Hotel

    # =============== Main ======================

    # overview: [Overview]

    # =============== Debug =====================

    debug: JSON
  }

  type CmCache {
    ratesXML: CacheLogs
    servicesXML: CacheLogs
    hotelInfoXML: CacheLogs
    servicesJSON: CacheLogs
    hotelInfoJSON: CacheLogs
    bookabilityJSON: CacheLogs
    ratesAverageJSON: CacheLogs
    offersOverviewJSON: CacheLogs
  }

  type SmartBooking {
    offersDebug: JSON
    servicesDebug: JSON
    propertyDebug: JSON
    rooms: [SmartBookingRoom]
  }

  # ======================= cm query =======================

  type Query {
    cm(userId: String!, provider: String!, language: String!): Cm
    smartBooking(
      provider: String!
      language: String!
      config: JSON!
      rooms: JSON
      checkin: String
      checkout: String
      exclude: JSON
    ): SmartBooking
  }

  # ======================= cm cache mutation =======================
  enum ActionType {
    RATEPLAN_UPDATE,
    AVAILABILITY_UPDATE
    HOTEL_CONTENT_UPDATE
  }

  type Mutation {
    evictUserCache(userId: String!): String
    evictAllCache: String
    cache(userId: String!, provider: String!, languages: [String!]!): CmCache
    updateConfig(userId: String!): String
    revalidateUsers (userId: String!, action: ActionType): JSON
  }
`
