const evictUserCache = async (parent, params, context, info) => {
  const { cache } = context
  let cacheFound = 0

  if (cache) {
    for await (const key of cache.scanIterator({
      MATCH: `*${params.userId}*`,
    })) {
      await cache.del(key)
      cacheFound += 1
    }
  }

  return cacheFound
    ? `Cleared ${cacheFound} key-value pairs for user: ${params.userId}`
    : `No cache found for user ${params.userId}`
}

const evictAllCache = async (parent, params, context, info) => {
  const { cache } = context
  const { length: cacheLength } = await cache.sendCommand(['KEYS', '*'])
  if (cacheLength) {
    await cache.sendCommand(['FLUSHALL'])
  }
  return cacheLength ? `Cleared ${cacheLength} key-value pairs` : `No cache found`
}

module.exports = {
    evictUserCache,
    evictAllCache
}
