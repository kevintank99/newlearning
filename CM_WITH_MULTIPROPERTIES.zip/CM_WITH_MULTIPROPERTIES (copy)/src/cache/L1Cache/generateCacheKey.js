const { createHash } = require('@apollo/utils.createhash')

const sha = (s) => createHash('sha256').update(s).digest('hex')

const generateCacheKey = (resolverName, params, userId, provider, language) =>
  `${resolverName}${userId ? `_${userId}` : ``}${provider ? `_${provider}` : ``}${
    language ? `_${language}` : ``
  }_${sha(JSON.stringify(params))}`

module.exports = generateCacheKey
