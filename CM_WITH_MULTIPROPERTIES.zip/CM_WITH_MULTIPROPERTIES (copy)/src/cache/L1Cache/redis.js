const Redis = require("redis")

const client = Redis.createClient()

;(async() => {
  // await client.connect()
})()

client.on("error", (err) => {
  console.log("Redis client error", err)
})

module.exports = client