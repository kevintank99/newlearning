const revalidateUsers = async (parent, params, context, info) => {
	try {
		const { db } = context
		const {userId, action} = params
		const userExist = await db.find('cacheableUsers',{userId,[`action.${action}`]:true});
		if (userExist.length === 0) {
			await db.updateOne('cacheableUsers',{userId},{[`action.${action}`]:true,currentTimeStamp: Date.now()} )
			return `${userId} user added succesfully in Cacheable Users`;
		}
		return `${userId} user already have ${action}`;
	} catch (errorMsg) {
		return `${errorMsg}`;
	}
}
module.exports = revalidateUsers