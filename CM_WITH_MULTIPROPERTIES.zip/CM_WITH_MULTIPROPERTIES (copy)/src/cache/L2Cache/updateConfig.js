const fetch = require('node-fetch')

const updateConfig = async (parent, params, context, info) => {
  try {
    const { db } = context
    const { userId } = params
    const userConfig = await fetch(`https://s.mts-online.com/${userId}/user/config.json`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    }).then((res) => res.json())
    await db.replaceOne('smts', { user_id: userId }, userConfig, { upsert: true })
    return `SMTS config updated of ${userId}`
  } catch (e) {
      const errMsg = `SMTS config update failed ${JSON.stringify(e)}`
      console.log(errMsg)
      return errMsg
  }
}

module.exports = updateConfig
