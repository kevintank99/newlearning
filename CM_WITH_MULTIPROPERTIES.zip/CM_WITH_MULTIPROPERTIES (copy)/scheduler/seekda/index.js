const { evictUserCache } = require('../../src/cache/L1Cache/cacheEviction')
const db = new (require('../../src/cache/L2Cache/mongoDB'))()
const {
  cacheCm,
  cacheHotelInfoJSON,
  cacheServicesJSON,
  cacheBookabilityJSON,
  cacheRatesAverageJSON,
  cacheOffersOverviewJSON,
  cacheRatesXML,
  cacheServicesXML,
  cacheHotelInfoXML,
} = require('../../src/cm/kognitiv/cachers')
const KognitivAPI = require('../../src/cm/kognitiv/datasources')
const cache = require('../../src/cache/L1Cache/redis')
const { dateToday, dateDiffDays, dateIsoFormat, dateFrom } = require('../../src/utils/date')

const revalidateCache = async (user) => {
  console.log('='.repeat(20), user.seekda.hotelid, '='.repeat(20))
  const params = {
    userId: user.user_id,
    provider: 'kognitiv',
    languages: ['de', 'en', 'it'],
  }
  const context = {
    dataSources: {
      kognitiv: new KognitivAPI(),
    },
    db,
    cache,
  }
  const errorObj = {
    userId: user.user_id,
    provider: 'kognitiv',
    languages: ['de', 'en', 'it'],
    errors: [],
  }

  try {
    const parentResolve = await cacheCm(null, params, context)

    const cache = await Promise.all([
      cacheServicesJSON(parentResolve, {}, context, {}),
      cacheHotelInfoJSON(parentResolve, {}, context, {}),
      cacheBookabilityJSON(parentResolve, {}, context, {}),
      cacheRatesAverageJSON(parentResolve, {}, context, {}),
      cacheOffersOverviewJSON(parentResolve, {}, context, {}),
      cacheRatesXML(parentResolve, {}, context, {}),
      cacheServicesXML(parentResolve, {}, context, {}),
      cacheHotelInfoXML(parentResolve, {}, context, {}),
    ])

    await evictUserCache(null, { userId: user.user_id }, context)

    if (cache) {
      for (let resolver in cache) {
        const { success, message, error, reason } = cache[resolver]
        if (!success || error) {
          errorObj.errors.push({
            success,
            message,
            error,
            reason,
          })
        }
      }
    }
    if (errorObj.errors.length) throw errorObj
  } catch (err) {
    throw err
  }
}

const seekda = async () => {
  console.log('='.repeat(20), 'Schedule Jobs Started In CM', '='.repeat(20))
  // const nextJob = await db.findOne('scheduler')
  const cacheableUsersData = await db.find('cacheableUsers');
  // const performTask = nextJob?.lastExecutionDate
  //   ? dateDiffDays(dateFrom(dateIsoFormat(dateFrom(nextJob.lastExecutionDate))), dateToday()) >= 1
  //     ? true
  //     : false
  //   : true
  const performTask = cacheableUsersData.length ? true : false
  const usersFacingErrors = [];
  const notCachedUsers = [];
  const cachedUsers = [];
  if (performTask) {
    // const cacheFailedUsers = nextJob?.usersFacingErrors?.map((u) => u.userId)
    const cacheUsers = cacheableUsersData.map((u) => u.userId);
    try {
      // const users = performTask ? await db.find('smts') : await db.find('smts', { user_id: { $in: cacheFailedUsers } })
      const users = await db.find('smts', { user_id: { $in: cacheUsers } })
      console.log("total users to cache....................",users)
      for (let user of users) {
        try {
          if (!user?.skiprefresh || user.skiprefresh !== 1) {
            await revalidateCache(user)
            cachedUsers.push(user.user_id)
          }
        } catch (e) {
          console.log(e)
          notCachedUsers.push(user.user_id);
          usersFacingErrors.push(JSON.parse(JSON.stringify(e)))
        }
      }

      // if (!performTask && usersFacingErrors.every((user) => cacheFailedUsers.includes(user.userId))) {
      //   usersFacingErrors.splice(0, usersFacingErrors.length)
      // }
      console.log("users having errors....................",notCachedUsers);
      console.log("users data changed......................",cachedUsers)
      console.log("errors:::::::::::",usersFacingErrors.length, usersFacingErrors)
      // db.replaceOne(
      //   'scheduler',
      //   { lastExecutionDate: nextJob?.lastExecutionDate },
      //   { lastExecutionDate: Date.now(), ...(usersFacingErrors.length ? { usersFacingErrors } : {}) },
      // )
      if (cachedUsers.length) {
        await db.delete('cacheableUsers',{ userId: { $in: cachedUsers } })
      }
      if (notCachedUsers.length && usersFacingErrors.length) {
        console.log("updatng users.............................",notCachedUsers)
        await db.update('cacheableUsers',{ userId: { $in: notCachedUsers } },{usersFacingErrors,lastExecutionDate: Date.now()})
      }
    } catch (e) {
      console.log('ERROR', e)
    }
  }
  console.log('='.repeat(20), 'Schedule Jobs Ended In CM', '='.repeat(20))
}

module.exports = seekda
