const childProcess = require('child_process')

const scheduler = () => {
  console.log("Scheduling tasks...")
  const providers = childProcess
    .spawnSync('ls', ['./scheduler'])
    .stdout.toString()
    .replace(/\n.*\.js/g, '')
    .replace(/\n|\s|\t/g, ' ')
    .trim()
    .split(' ')

  for (let provider of providers) {
    setInterval(require(`./${provider}`), 1000 * 60 * 30)
  }
}

scheduler()

